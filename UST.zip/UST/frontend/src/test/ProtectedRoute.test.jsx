import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { MemoryRouter } from "react-router";
import { ProtectedRoute } from "../app/components/shared/ProtectedRoute";

// Mock the AuthContext
vi.mock("../app/context/AuthContext", () => ({
  useAuth: vi.fn(),
}));

import { useAuth } from "../app/context/AuthContext";

describe("ProtectedRoute", () => {
  it("redirects to /login when not authenticated", () => {
    useAuth.mockReturnValue({ currentUser: null, isAuthenticated: false });

    render(
      <MemoryRouter initialEntries={["/student"]}>
        <ProtectedRoute roles={["student"]}>
          <div>Secret Content</div>
        </ProtectedRoute>
      </MemoryRouter>,
    );

    expect(screen.queryByText("Secret Content")).not.toBeInTheDocument();
  });

  it("renders children when authenticated with correct role", () => {
    useAuth.mockReturnValue({
      currentUser: { id: 1, role: "student" },
      isAuthenticated: true,
    });

    render(
      <MemoryRouter>
        <ProtectedRoute roles={["student"]}>
          <div>Student Content</div>
        </ProtectedRoute>
      </MemoryRouter>,
    );

    expect(screen.getByText("Student Content")).toBeInTheDocument();
  });

  it("redirects admin to /admin when role not allowed", () => {
    useAuth.mockReturnValue({
      currentUser: { id: 1, role: "admin" },
      isAuthenticated: true,
    });

    render(
      <MemoryRouter>
        <ProtectedRoute roles={["student"]}>
          <div>Student Only</div>
        </ProtectedRoute>
      </MemoryRouter>,
    );

    expect(screen.queryByText("Student Only")).not.toBeInTheDocument();
  });

  it("redirects teacher to /teacher when role not allowed", () => {
    useAuth.mockReturnValue({
      currentUser: { id: 1, role: "teacher" },
      isAuthenticated: true,
    });

    render(
      <MemoryRouter>
        <ProtectedRoute roles={["admin"]}>
          <div>Admin Only</div>
        </ProtectedRoute>
      </MemoryRouter>,
    );

    expect(screen.queryByText("Admin Only")).not.toBeInTheDocument();
  });

  it("renders children when no roles specified and authenticated", () => {
    useAuth.mockReturnValue({
      currentUser: { id: 1, role: "student" },
      isAuthenticated: true,
    });

    render(
      <MemoryRouter>
        <ProtectedRoute>
          <div>Any Role Content</div>
        </ProtectedRoute>
      </MemoryRouter>,
    );

    expect(screen.getByText("Any Role Content")).toBeInTheDocument();
  });
});
