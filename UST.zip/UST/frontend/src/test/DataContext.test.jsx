import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { DataProvider, useData } from "../app/context/DataContext";

// Mock all API modules
vi.mock("../lib/api", () => ({
  userApi: { getAllUsers: vi.fn() },
  courseApi: { getAllCourses: vi.fn() },
  lectureApi: { getAllLectures: vi.fn() },
  assignmentApi: { getAllAssignments: vi.fn() },
  attendanceApi: { getAllAttendance: vi.fn() },
  eventApi: { getAllEvents: vi.fn() },
  roadmapApi: { getAllRoadmap: vi.fn() },
  timetableApi: { getAllTimetable: vi.fn() },
  announcementApi: { getAllAnnouncements: vi.fn() },
  enrollmentApi: { getAll: vi.fn() },
  submissionApi: { getAll: vi.fn() },
}));

import {
  userApi,
  courseApi,
  lectureApi,
  assignmentApi,
  attendanceApi,
  eventApi,
  roadmapApi,
  timetableApi,
  announcementApi,
  enrollmentApi,
  submissionApi,
} from "../lib/api";

function DataConsumer() {
  const { users, courses, assignments, attendanceRecords, roadmap, isLoading } =
    useData();
  if (isLoading) return <div data-testid="loading">Loading</div>;
  return (
    <div>
      <div data-testid="user-count">{users.length}</div>
      <div data-testid="course-count">{courses.length}</div>
      <div data-testid="assignment-count">{assignments.length}</div>
      <div data-testid="attendance-count">{attendanceRecords.length}</div>
      <div data-testid="roadmap-count">{roadmap.length}</div>
      {users.map((u) => (
        <div key={u.id} data-testid={`user-${u.id}-enrolled`}>
          {JSON.stringify(u.enrolledCourses)}
        </div>
      ))}
      {courses.map((c) => (
        <div key={c.id} data-testid={`course-${c.id}-students`}>
          {JSON.stringify(c.enrolledStudents)}
        </div>
      ))}
      {assignments.map((a) => (
        <div key={a.id} data-testid={`assignment-${a.id}-submissions`}>
          {a.submissions.length}
        </div>
      ))}
      {attendanceRecords.map((r, i) => (
        <div key={i} data-testid={`attendance-${i}-records`}>
          {r.records.length}
        </div>
      ))}
      {roadmap.map((r) => (
        <div key={r.id}>
          <span data-testid={`roadmap-${r.id}-courses`}>
            {JSON.stringify(r.courses)}
          </span>
          <span data-testid={`roadmap-${r.id}-outcomes`}>
            {JSON.stringify(r.outcomes)}
          </span>
        </div>
      ))}
    </div>
  );
}

function setupMocks({
  users = [],
  courses = [],
  lectures = [],
  assignments = [],
  attendance = [],
  events = [],
  roadmapItems = [],
  timetableItems = [],
  announcements = [],
  enrollments = [],
  submissions = [],
} = {}) {
  userApi.getAllUsers.mockResolvedValue({ data: users });
  courseApi.getAllCourses.mockResolvedValue({ data: courses });
  lectureApi.getAllLectures.mockResolvedValue({ data: lectures });
  assignmentApi.getAllAssignments.mockResolvedValue({ data: assignments });
  attendanceApi.getAllAttendance.mockResolvedValue({ data: attendance });
  eventApi.getAllEvents.mockResolvedValue({ data: events });
  roadmapApi.getAllRoadmap.mockResolvedValue({ data: roadmapItems });
  timetableApi.getAllTimetable.mockResolvedValue({ data: timetableItems });
  announcementApi.getAllAnnouncements.mockResolvedValue({
    data: announcements,
  });
  enrollmentApi.getAll.mockResolvedValue({ data: enrollments });
  submissionApi.getAll.mockResolvedValue({ data: submissions });
}

describe("DataContext", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("enriches users with enrolledCourses from enrollments", async () => {
    setupMocks({
      users: [
        { id: 1, name: "Alice", role: "student" },
        { id: 2, name: "Bob", role: "student" },
      ],
      enrollments: [
        { id: 1, courseId: "CS101", studentId: 1 },
        { id: 2, courseId: "CS102", studentId: 1 },
        { id: 3, courseId: "CS101", studentId: 2 },
      ],
    });

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("user-count").textContent).toBe("2");
    });

    expect(screen.getByTestId("user-1-enrolled").textContent).toBe(
      JSON.stringify(["CS101", "CS102"]),
    );
    expect(screen.getByTestId("user-2-enrolled").textContent).toBe(
      JSON.stringify(["CS101"]),
    );
  });

  it("enriches courses with enrolledStudents", async () => {
    setupMocks({
      courses: [
        { id: "CS101", name: "Intro to CS" },
        { id: "CS102", name: "Data Structures" },
      ],
      enrollments: [
        { id: 1, courseId: "CS101", studentId: 1 },
        { id: 2, courseId: "CS101", studentId: 2 },
        { id: 3, courseId: "CS102", studentId: 1 },
      ],
    });

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("course-count").textContent).toBe("2");
    });

    expect(screen.getByTestId("course-CS101-students").textContent).toBe(
      JSON.stringify([1, 2]),
    );
    expect(screen.getByTestId("course-CS102-students").textContent).toBe(
      JSON.stringify([1]),
    );
  });

  it("enriches assignments with submissions", async () => {
    setupMocks({
      assignments: [{ id: 1, title: "HW1", courseId: "CS101" }],
      submissions: [
        { id: 1, assignmentId: 1, studentId: 1, status: "submitted" },
        { id: 2, assignmentId: 1, studentId: 2, status: "graded" },
      ],
    });

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("assignment-count").textContent).toBe("1");
    });

    expect(screen.getByTestId("assignment-1-submissions").textContent).toBe(
      "2",
    );
  });

  it("groups flat attendance records into {courseId, date, records}", async () => {
    setupMocks({
      attendance: [
        {
          id: 1,
          courseId: "CS101",
          date: "2024-01-10",
          studentId: 1,
          status: "present",
        },
        {
          id: 2,
          courseId: "CS101",
          date: "2024-01-10",
          studentId: 2,
          status: "absent",
        },
        {
          id: 3,
          courseId: "CS101",
          date: "2024-01-11",
          studentId: 1,
          status: "present",
        },
      ],
    });

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      // 2 unique (courseId, date) combos → 2 grouped records
      expect(screen.getByTestId("attendance-count").textContent).toBe("2");
    });

    // First group has 2 student records, second has 1
    expect(screen.getByTestId("attendance-0-records").textContent).toBe("2");
    expect(screen.getByTestId("attendance-1-records").textContent).toBe("1");
  });

  it("parses roadmap skills/resources into courses/outcomes arrays", async () => {
    setupMocks({
      roadmapItems: [
        {
          id: 1,
          title: "Semester 1",
          skills: "Python, Java, SQL",
          resources: "Build apps, Analyze data",
        },
        {
          id: 2,
          title: "Semester 2",
          skills: "",
          resources: "Advanced topics",
        },
      ],
    });

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("roadmap-count").textContent).toBe("2");
    });

    expect(screen.getByTestId("roadmap-1-courses").textContent).toBe(
      JSON.stringify(["Python", "Java", "SQL"]),
    );
    expect(screen.getByTestId("roadmap-1-outcomes").textContent).toBe(
      JSON.stringify(["Build apps", "Analyze data"]),
    );
    expect(screen.getByTestId("roadmap-2-courses").textContent).toBe(
      JSON.stringify([]),
    );
    expect(screen.getByTestId("roadmap-2-outcomes").textContent).toBe(
      JSON.stringify(["Advanced topics"]),
    );
  });

  it("handles API failures gracefully with empty arrays", async () => {
    // All APIs reject
    userApi.getAllUsers.mockRejectedValue(new Error("Network error"));
    courseApi.getAllCourses.mockRejectedValue(new Error("fail"));
    lectureApi.getAllLectures.mockRejectedValue(new Error("fail"));
    assignmentApi.getAllAssignments.mockRejectedValue(new Error("fail"));
    attendanceApi.getAllAttendance.mockRejectedValue(new Error("fail"));
    eventApi.getAllEvents.mockRejectedValue(new Error("fail"));
    roadmapApi.getAllRoadmap.mockRejectedValue(new Error("fail"));
    timetableApi.getAllTimetable.mockRejectedValue(new Error("fail"));
    announcementApi.getAllAnnouncements.mockRejectedValue(new Error("fail"));
    enrollmentApi.getAll.mockRejectedValue(new Error("fail"));
    submissionApi.getAll.mockRejectedValue(new Error("fail"));

    const spy = vi.spyOn(console, "error").mockImplementation(() => {});

    render(
      <DataProvider>
        <DataConsumer />
      </DataProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("user-count").textContent).toBe("0");
      expect(screen.getByTestId("course-count").textContent).toBe("0");
    });

    spy.mockRestore();
  });
});
