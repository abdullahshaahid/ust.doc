import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { MemoryRouter } from "react-router";
import LoginPage from "../app/pages/auth/LoginPage";

const mockNavigate = vi.fn();
const mockLogin = vi.fn();

vi.mock("react-router", async () => {
  const actual = await vi.importActual("react-router");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

vi.mock("../app/context/AuthContext", () => ({
  useAuth: () => ({
    login: mockLogin,
  }),
}));

// Mock framer-motion to avoid animation issues in tests
vi.mock("motion/react", () => ({
  motion: {
    h2: (props) => <h2 {...props} />,
    div: (props) => <div {...props} />,
  },
}));

describe("LoginPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it("renders login form with email and password fields", () => {
    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    expect(screen.getByPlaceholderText(/email/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/password/i)).toBeInTheDocument();
  });

  it("renders demo account buttons", () => {
    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    expect(screen.getByText("Admin")).toBeInTheDocument();
    expect(screen.getByText("Teacher")).toBeInTheDocument();
    expect(screen.getByText("Student")).toBeInTheDocument();
  });

  it("fills demo credentials when demo button is clicked", async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    await user.click(screen.getByText("Student"));

    expect(screen.getByPlaceholderText(/email/i)).toHaveValue(
      "alice@student.edu",
    );
    expect(screen.getByPlaceholderText(/password/i)).toHaveValue("student123");
  });

  it("calls login and navigates on successful student login", async () => {
    const user = userEvent.setup();
    mockLogin.mockResolvedValue({ success: true });
    localStorage.setItem("current_user", JSON.stringify({ role: "student" }));

    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    await user.type(screen.getByPlaceholderText(/email/i), "alice@student.edu");
    await user.type(screen.getByPlaceholderText(/password/i), "student123");
    await user.click(screen.getByRole("button", { name: /sign in/i }));

    await waitFor(() => {
      expect(mockLogin).toHaveBeenCalledWith("alice@student.edu", "student123");
      expect(mockNavigate).toHaveBeenCalledWith("/student");
    });
  });

  it("shows error message on failed login", async () => {
    const user = userEvent.setup();
    mockLogin.mockResolvedValue({
      success: false,
      message: "Invalid credentials",
    });

    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    await user.type(screen.getByPlaceholderText(/email/i), "bad@test.com");
    await user.type(screen.getByPlaceholderText(/password/i), "wrong");
    await user.click(screen.getByRole("button", { name: /sign in/i }));

    await waitFor(() => {
      expect(screen.getByText("Invalid credentials")).toBeInTheDocument();
    });
  });

  it("navigates admin to /admin", async () => {
    const user = userEvent.setup();
    mockLogin.mockResolvedValue({ success: true });
    localStorage.setItem("current_user", JSON.stringify({ role: "admin" }));

    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    await user.type(
      screen.getByPlaceholderText(/email/i),
      "admin@university.edu",
    );
    await user.type(screen.getByPlaceholderText(/password/i), "admin123");
    await user.click(screen.getByRole("button", { name: /sign in/i }));

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith("/admin");
    });
  });

  it("navigates teacher to /teacher", async () => {
    const user = userEvent.setup();
    mockLogin.mockResolvedValue({ success: true });
    localStorage.setItem("current_user", JSON.stringify({ role: "teacher" }));

    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    );

    await user.type(
      screen.getByPlaceholderText(/email/i),
      "john@university.edu",
    );
    await user.type(screen.getByPlaceholderText(/password/i), "teacher123");
    await user.click(screen.getByRole("button", { name: /sign in/i }));

    await waitFor(() => {
      expect(mockNavigate).toHaveBeenCalledWith("/teacher");
    });
  });
});
