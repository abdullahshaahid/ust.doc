import { render, screen, act, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { AuthProvider, useAuth } from "../app/context/AuthContext";

// Mock the api module
vi.mock("../lib/api", () => ({
  authApi: {
    login: vi.fn(),
  },
}));

import { authApi } from "../lib/api";

function AuthConsumer() {
  const { currentUser, isAuthenticated, isLoading, login, logout } = useAuth();
  return (
    <div>
      <span data-testid="authenticated">{String(isAuthenticated)}</span>
      <span data-testid="loading">{String(isLoading)}</span>
      <span data-testid="user">{currentUser ? currentUser.name : "none"}</span>
      <span data-testid="role">{currentUser ? currentUser.role : "none"}</span>
      <button onClick={() => login("test@test.com", "pass123")}>Login</button>
      <button onClick={() => logout()}>Logout</button>
    </div>
  );
}

describe("AuthContext", () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  afterEach(() => {
    localStorage.clear();
  });

  it("starts unauthenticated with no stored session", () => {
    render(
      <AuthProvider>
        <AuthConsumer />
      </AuthProvider>,
    );
    expect(screen.getByTestId("authenticated").textContent).toBe("false");
    expect(screen.getByTestId("user").textContent).toBe("none");
  });

  it("restores session from localStorage", async () => {
    localStorage.setItem("auth_token", "test-token");
    localStorage.setItem(
      "current_user",
      JSON.stringify({ id: 1, name: "Alice", role: "student" }),
    );

    render(
      <AuthProvider>
        <AuthConsumer />
      </AuthProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("authenticated").textContent).toBe("true");
      expect(screen.getByTestId("user").textContent).toBe("Alice");
      expect(screen.getByTestId("role").textContent).toBe("student");
    });
  });

  it("logs in successfully and stores token", async () => {
    const user = userEvent.setup();
    authApi.login.mockResolvedValue({
      data: {
        token: "jwt-token-123",
        user: { id: 1, name: "John", role: "teacher" },
      },
    });

    render(
      <AuthProvider>
        <AuthConsumer />
      </AuthProvider>,
    );

    await user.click(screen.getByText("Login"));

    await waitFor(() => {
      expect(screen.getByTestId("authenticated").textContent).toBe("true");
      expect(screen.getByTestId("user").textContent).toBe("John");
    });

    expect(localStorage.getItem("auth_token")).toBe("jwt-token-123");
    expect(JSON.parse(localStorage.getItem("current_user")).name).toBe("John");
  });

  it("handles login failure", async () => {
    const user = userEvent.setup();
    authApi.login.mockRejectedValue({
      response: { data: { error: "Invalid credentials" } },
    });

    let loginResult;
    function LoginTester() {
      const { login } = useAuth();
      return (
        <button
          onClick={async () => {
            loginResult = await login("bad@test.com", "wrong");
          }}
        >
          Login
        </button>
      );
    }

    render(
      <AuthProvider>
        <LoginTester />
      </AuthProvider>,
    );

    await user.click(screen.getByText("Login"));

    await waitFor(() => {
      expect(loginResult).toEqual({
        success: false,
        message: "Invalid credentials",
      });
    });
  });

  it("logs out and clears storage", async () => {
    const user = userEvent.setup();
    localStorage.setItem("auth_token", "test-token");
    localStorage.setItem(
      "current_user",
      JSON.stringify({ id: 1, name: "Alice", role: "student" }),
    );

    render(
      <AuthProvider>
        <AuthConsumer />
      </AuthProvider>,
    );

    await waitFor(() => {
      expect(screen.getByTestId("authenticated").textContent).toBe("true");
    });

    await user.click(screen.getByText("Logout"));

    expect(screen.getByTestId("authenticated").textContent).toBe("false");
    expect(screen.getByTestId("user").textContent).toBe("none");
    expect(localStorage.getItem("auth_token")).toBeNull();
    expect(localStorage.getItem("current_user")).toBeNull();
  });

  it("throws error when useAuth is used outside provider", () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<AuthConsumer />)).toThrow(
      "useAuth must be used within AuthProvider",
    );
    spy.mockRestore();
  });
});
