import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { MemoryRouter } from "react-router";
import StudentDashboard from "../app/pages/student/StudentDashboard";

const mockNavigate = vi.fn();

vi.mock("react-router", async () => {
  const actual = await vi.importActual("react-router");
  return { ...actual, useNavigate: () => mockNavigate };
});

vi.mock("../app/context/AuthContext", () => ({
  useAuth: () => ({
    currentUser: { id: 1, name: "Alice Johnson", role: "student" },
  }),
}));

vi.mock("../app/context/DataContext", () => ({
  useData: () => ({
    users: [
      {
        id: 1,
        name: "Alice Johnson",
        role: "student",
        enrolledCourses: ["CS101", "CS102"],
      },
    ],
    courses: [
      {
        id: "CS101",
        name: "Intro to CS",
        code: "CS101",
        enrolledStudents: [1],
      },
      {
        id: "CS102",
        name: "Data Structures",
        code: "CS102",
        enrolledStudents: [1],
      },
    ],
    lectures: [
      {
        id: 1,
        courseId: "CS101",
        title: "Lecture 1",
        type: "pdf",
        uploadedAt: "2024-01-10",
      },
    ],
    assignments: [
      {
        id: 1,
        courseId: "CS101",
        title: "HW1",
        dueDate: "2099-12-31",
        priority: "high",
        submissions: [],
      },
      {
        id: 2,
        courseId: "CS102",
        title: "HW2",
        dueDate: "2099-12-31",
        priority: "medium",
        submissions: [{ studentId: 1, status: "graded", marks: 85 }],
      },
    ],
    attendanceRecords: [
      {
        courseId: "CS101",
        date: "2024-01-10",
        records: [{ studentId: 1, status: "present" }],
      },
      {
        courseId: "CS101",
        date: "2024-01-11",
        records: [{ studentId: 1, status: "absent" }],
      },
    ],
    announcements: [
      {
        id: 1,
        title: "Welcome",
        message: "Welcome to the semester",
        isActive: true,
        targetRole: "all",
      },
    ],
  }),
}));

// Mock recharts to avoid rendering issues
vi.mock("recharts", () => ({
  ResponsiveContainer: ({ children }) => <div>{children}</div>,
  RadialBarChart: ({ children }) => <div>{children}</div>,
  RadialBar: () => <div />,
  Tooltip: () => <div />,
}));

describe("StudentDashboard", () => {
  it("renders student name in header", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    expect(screen.getByText("Alice Johnson")).toBeInTheDocument();
  });

  it("shows enrolled course count", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    // Should show 2 courses
    expect(screen.getByText("2")).toBeInTheDocument();
  });

  it("shows pending assignment (HW1 not submitted)", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    expect(screen.getByText("HW1")).toBeInTheDocument();
  });

  it("shows lecture material", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    expect(screen.getByText("Lecture 1")).toBeInTheDocument();
  });

  it("displays announcements", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    expect(screen.getByText("Welcome")).toBeInTheDocument();
  });

  it("calculates attendance percentage correctly", () => {
    render(
      <MemoryRouter>
        <StudentDashboard />
      </MemoryRouter>,
    );

    // 1 out of 2 present = 50% — shown in multiple places on dashboard
    const matches = screen.getAllByText(/50\s*%/);
    expect(matches.length).toBeGreaterThanOrEqual(1);
  });
});
