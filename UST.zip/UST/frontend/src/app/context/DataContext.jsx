import React, { createContext, useContext, useState, useEffect } from "react";
import {
  userApi,
  courseApi,
  lectureApi,
  assignmentApi,
  announcementApi,
  eventApi,
  attendanceApi,
  timetableApi,
  roadmapApi,
  enrollmentApi,
  submissionApi,
} from "../../lib/api";

// ─── TypeScript Interfaces ───────────────────────────────────────────────────

// ─── Context Type ────────────────────────────────────────────────────────────

const DataContext = createContext(undefined);

// ─── Provider ────────────────────────────────────────────────────────────────

export function DataProvider({ children }) {
  const [users, setUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [lectures, setLectures] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [events, setEvents] = useState([]);
  const [roadmap, setRoadmap] = useState([]);
  const [timetable, setTimetable] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [enrollments, setEnrollments] = useState([]);

  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  // Helper: group flat attendance rows into {courseId, date, records: [{studentId, status}]}
  const groupAttendance = (flatRecords) => {
    const map = {};
    flatRecords.forEach((r) => {
      const key = `${r.courseId}__${r.date}`;
      if (!map[key]) {
        map[key] = {
          id: r.id,
          courseId: r.courseId,
          date: r.date,
          records: [],
        };
      }
      map[key].records.push({ studentId: r.studentId, status: r.status });
    });
    return Object.values(map);
  };

  // Fetch all data from backend
  const refetchAll = async () => {
    try {
      setIsLoading(true);
      const [
        usersRes,
        coursesRes,
        lecturesRes,
        assignmentsRes,
        attendanceRes,
        eventsRes,
        roadmapRes,
        timetableRes,
        announcementsRes,
        enrollmentsRes,
        submissionsRes,
      ] = await Promise.all([
        userApi.getAllUsers().catch(() => ({ data: [] })),
        courseApi.getAllCourses().catch(() => ({ data: [] })),
        lectureApi.getAllLectures().catch(() => ({ data: [] })),
        assignmentApi.getAllAssignments().catch(() => ({ data: [] })),
        attendanceApi.getAllAttendance().catch(() => ({ data: [] })),
        eventApi.getAllEvents().catch(() => ({ data: [] })),
        roadmapApi.getAllRoadmap().catch(() => ({ data: [] })),
        timetableApi.getAllTimetable().catch(() => ({ data: [] })),
        announcementApi.getAllAnnouncements().catch(() => ({ data: [] })),
        enrollmentApi.getAll().catch(() => ({ data: [] })),
        submissionApi.getAll().catch(() => ({ data: [] })),
      ]);

      const rawUsers = Array.isArray(usersRes.data) ? usersRes.data : [];
      const rawCourses = Array.isArray(coursesRes.data) ? coursesRes.data : [];
      const rawAssignments = Array.isArray(assignmentsRes.data)
        ? assignmentsRes.data
        : [];
      const rawAttendance = Array.isArray(attendanceRes.data)
        ? attendanceRes.data
        : [];
      const rawRoadmap = Array.isArray(roadmapRes.data) ? roadmapRes.data : [];
      const rawEnrollments = Array.isArray(enrollmentsRes.data)
        ? enrollmentsRes.data
        : [];
      const rawSubmissions = Array.isArray(submissionsRes.data)
        ? submissionsRes.data
        : [];

      // Enrich users with enrolledCourses
      const enrichedUsers = rawUsers.map((u) => ({
        ...u,
        enrolledCourses: rawEnrollments
          .filter((e) => e.studentId === u.id)
          .map((e) => e.courseId),
      }));

      // Enrich courses with enrolledStudents
      const enrichedCourses = rawCourses.map((c) => ({
        ...c,
        enrolledStudents: rawEnrollments
          .filter((e) => e.courseId === c.id)
          .map((e) => e.studentId),
      }));

      // Enrich assignments with submissions
      const enrichedAssignments = rawAssignments.map((a) => ({
        ...a,
        submissions: rawSubmissions.filter((s) => s.assignmentId === a.id),
      }));

      // Group flat attendance into {courseId, date, records: [{studentId, status}]}
      const groupedAttendance = groupAttendance(rawAttendance);

      // Enrich roadmap: parse comma-separated fields into arrays
      const enrichedRoadmap = rawRoadmap.map((r) => ({
        ...r,
        courses: r.skills
          ? r.skills
              .split(",")
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
        outcomes: r.resources
          ? r.resources
              .split(",")
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
      }));

      setUsers(enrichedUsers);
      setCourses(enrichedCourses);
      setLectures(Array.isArray(lecturesRes.data) ? lecturesRes.data : []);
      setAssignments(enrichedAssignments);
      setAttendanceRecords(groupedAttendance);
      setEvents(Array.isArray(eventsRes.data) ? eventsRes.data : []);
      setRoadmap(enrichedRoadmap);
      setTimetable(Array.isArray(timetableRes.data) ? timetableRes.data : []);
      setAnnouncements(
        Array.isArray(announcementsRes.data) ? announcementsRes.data : [],
      );
      setEnrollments(rawEnrollments);
    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    refetchAll();
  }, []);

  // ── Users ──
  const addUser = async (user) => {
    try {
      setIsSyncing(true);
      await userApi.createUser(user);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateUser = async (id, user) => {
    try {
      setIsSyncing(true);
      await userApi.updateUser(id, user);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteUser = async (id) => {
    try {
      setIsSyncing(true);
      await userApi.deleteUser(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Courses ──
  const addCourse = async (course) => {
    try {
      setIsSyncing(true);
      await courseApi.createCourse(course);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateCourse = async (id, course) => {
    try {
      setIsSyncing(true);
      await courseApi.updateCourse(id, course);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteCourse = async (id) => {
    try {
      setIsSyncing(true);
      await courseApi.deleteCourse(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const enrollStudentInCourse = async (courseId, studentId) => {
    try {
      setIsSyncing(true);
      await courseApi.enrollStudent(courseId, studentId);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const unenrollStudentFromCourse = async (courseId, studentId) => {
    try {
      setIsSyncing(true);
      await courseApi.unenrollStudent(courseId, studentId);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Lectures ──
  const addLecture = async (lecture) => {
    try {
      setIsSyncing(true);
      await lectureApi.createLecture(lecture);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateLecture = async (id, lecture) => {
    try {
      setIsSyncing(true);
      await lectureApi.updateLecture(id, lecture);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteLecture = async (id) => {
    try {
      setIsSyncing(true);
      await lectureApi.deleteLecture(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Assignments ──
  const addAssignment = async (assignment) => {
    try {
      setIsSyncing(true);
      await assignmentApi.createAssignment(assignment);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateAssignment = async (id, assignment) => {
    try {
      setIsSyncing(true);
      await assignmentApi.updateAssignment(id, assignment);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteAssignment = async (id) => {
    try {
      setIsSyncing(true);
      await assignmentApi.deleteAssignment(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const submitAssignment = async (assignmentId, submission) => {
    try {
      setIsSyncing(true);
      await assignmentApi.submitAssignment(assignmentId, submission);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const gradeSubmission = async (assignmentId, studentId, gradeData) => {
    try {
      setIsSyncing(true);
      // Support both gradeSubmission(id, studentId, {marks, feedback}) and gradeSubmission(id, studentId, marks, feedback)
      const data =
        typeof gradeData === "object"
          ? gradeData
          : { marks: gradeData, feedback: arguments[3] || "" };
      await assignmentApi.gradeSubmission(assignmentId, studentId, data);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Attendance ──
  const addAttendance = async (attendance) => {
    try {
      setIsSyncing(true);
      // attendance may have a records array [{studentId, status}] from the UI
      // Backend expects individual records: {courseId, studentId, date, status, markedBy}
      if (attendance.records && Array.isArray(attendance.records)) {
        for (const rec of attendance.records) {
          await attendanceApi
            .markAttendance({
              courseId: attendance.courseId,
              studentId: rec.studentId,
              date: attendance.date,
              status: rec.status,
              markedBy: attendance.markedBy || "unknown",
            })
            .catch(() => {});
        }
      } else {
        await attendanceApi.markAttendance(attendance);
      }
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateAttendance = async (id, attendance) => {
    try {
      setIsSyncing(true);
      await attendanceApi.updateAttendance(id, attendance);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteAttendance = async (id) => {
    try {
      setIsSyncing(true);
      await attendanceApi.deleteAttendance(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Events ──
  const addEvent = async (event) => {
    try {
      setIsSyncing(true);
      await eventApi.createEvent(event);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateEvent = async (id, event) => {
    try {
      setIsSyncing(true);
      await eventApi.updateEvent(id, event);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteEvent = async (id) => {
    try {
      setIsSyncing(true);
      await eventApi.deleteEvent(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const registerForEvent = async (eventId, studentId) => {
    try {
      setIsSyncing(true);
      await eventApi.registerForEvent(eventId, studentId);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const unregisterFromEvent = async (eventId, studentId) => {
    try {
      setIsSyncing(true);
      await eventApi.unregisterFromEvent(eventId, studentId);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Roadmap ──
  const addRoadmapItem = async (item) => {
    try {
      setIsSyncing(true);
      await roadmapApi.createRoadmapItem(item);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateRoadmapItem = async (id, item) => {
    try {
      setIsSyncing(true);
      await roadmapApi.updateRoadmapItem(id, item);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteRoadmapItem = async (id) => {
    try {
      setIsSyncing(true);
      await roadmapApi.deleteRoadmapItem(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Timetable ──
  const addTimetableEntry = async (entry) => {
    try {
      setIsSyncing(true);
      await timetableApi.createTimetableEntry(entry);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateTimetableEntry = async (id, entry) => {
    try {
      setIsSyncing(true);
      await timetableApi.updateTimetableEntry(id, entry);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteTimetableEntry = async (id) => {
    try {
      setIsSyncing(true);
      await timetableApi.deleteTimetableEntry(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  // ── Announcements ──
  const addAnnouncement = async (ann) => {
    try {
      setIsSyncing(true);
      await announcementApi.createAnnouncement(ann);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const updateAnnouncement = async (id, ann) => {
    try {
      setIsSyncing(true);
      await announcementApi.updateAnnouncement(id, ann);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  const deleteAnnouncement = async (id) => {
    try {
      setIsSyncing(true);
      await announcementApi.deleteAnnouncement(id);
      await refetchAll();
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <DataContext.Provider
      value={{
        users,
        courses,
        lectures,
        assignments,
        attendanceRecords,
        events,
        roadmap,
        timetable,
        announcements,
        enrollments,
        isLoading,
        isSyncing,
        addUser,
        updateUser,
        deleteUser,
        addCourse,
        updateCourse,
        deleteCourse,
        enrollStudentInCourse,
        unenrollStudentFromCourse,
        addLecture,
        updateLecture,
        deleteLecture,
        addAssignment,
        updateAssignment,
        deleteAssignment,
        submitAssignment,
        gradeSubmission,
        addAttendance,
        updateAttendance,
        deleteAttendance,
        addEvent,
        updateEvent,
        deleteEvent,
        registerForEvent,
        unregisterFromEvent,
        addRoadmapItem,
        updateRoadmapItem,
        deleteRoadmapItem,
        addTimetableEntry,
        updateTimetableEntry,
        deleteTimetableEntry,
        addAnnouncement,
        updateAnnouncement,
        deleteAnnouncement,
        refetchAll,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
}
