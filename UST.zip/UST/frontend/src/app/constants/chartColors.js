export const CHART_COLORS = [
  "#4f46e5",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ef4444",
  "#06b6d4",
];
