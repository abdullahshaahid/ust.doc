import { useState } from "react";
import { useNavigate, Link } from "react-router";
import {
  GraduationCap,
  Mail,
  Lock,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowLeft,
  Shield,
  BookOpen,
  Users,
  Zap,
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { motion } from "motion/react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent } from "../../components/ui/card";
import { Alert, AlertDescription } from "../../components/ui/alert";

const DEMO_ACCOUNTS = [
  {
    role: "Admin",
    email: "admin@university.edu",
    password: "admin123",
    color: "bg-rose-50 border-rose-200 hover:bg-rose-100",
    textColor: "text-rose-700",
    icon: <Shield size={15} />,
    desc: "Full system control",
  },
  {
    role: "Teacher",
    email: "john.smith@university.edu",
    password: "teacher123",
    color: "bg-emerald-50 border-emerald-200 hover:bg-emerald-100",
    textColor: "text-emerald-700",
    icon: <BookOpen size={15} />,
    desc: "Lecture & grade management",
  },
  {
    role: "Student",
    email: "alice@student.edu",
    password: "student123",
    color: "bg-indigo-50 border-indigo-200 hover:bg-indigo-100",
    textColor: "text-indigo-700",
    icon: <Users size={15} />,
    desc: "Academic tracking & resources",
  },
];

const bgImage =
  "https://images.unsplash.com/photo-1664273891579-22f28332f3c4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1080";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await login(email, password);
      if (result.success) {
        const user = JSON.parse(localStorage.getItem("current_user") || "{}");
        if (user.role === "admin") navigate("/admin");
        else if (user.role === "teacher") navigate("/teacher");
        else navigate("/student");
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (demoEmail, pwd) => {
    setEmail(demoEmail);
    setPassword(pwd);
    setError("");
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel – Background Image */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <img
          src={bgImage}
          alt="Campus"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/90 via-indigo-900/85 to-indigo-800/75" />
        <div className="absolute inset-0 flex flex-col justify-between p-12">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center border border-white/30">
              <GraduationCap size={28} className="text-white" />
            </div>
            <div>
              <p className="text-white font-bold text-2xl leading-none">
                UniLearn
              </p>
              <p className="text-indigo-200 text-sm">University LMS Platform</p>
            </div>
          </div>

          {/* Center Content */}
          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-white font-bold mb-4 leading-tight"
              style={{ fontSize: "clamp(2rem, 3vw, 2.75rem)" }}
            >
              Your Complete
              <br />
              Academic World,
              <br />
              <span className="text-amber-400">In One Place.</span>
            </motion.h2>
            <p className="text-indigo-200 text-base mb-8 leading-relaxed">
              Access lectures, track attendance, submit assignments, calculate
              CGPA — everything you need for academic success.
            </p>
            {[
              {
                icon: <Zap size={16} />,
                text: "Real-time grades and CGPA tracking",
              },
              {
                icon: <BookOpen size={16} />,
                text: "Digital lectures and course materials",
              },
              {
                icon: <Shield size={16} />,
                text: "Role-based secure access portal",
              },
            ].map((f) => (
              <div key={f.text} className="flex items-center gap-3 mb-3">
                <div className="w-7 h-7 bg-amber-500/20 text-amber-400 rounded-lg flex items-center justify-center flex-shrink-0">
                  {f.icon}
                </div>
                <span className="text-indigo-100 text-sm">{f.text}</span>
              </div>
            ))}
          </div>

          {/* Bottom Quote */}
          <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-5">
            <p className="text-indigo-100 text-sm italic leading-relaxed">
              "UniLearn transformed my learning experience. Everything I need is
              just a click away — from lecture notes to my CGPA tracker."
            </p>
            <p className="text-white font-medium text-sm mt-3">
              — Alice Johnson, CS Student 2024
            </p>
          </div>
        </div>
      </div>

      {/* Right Panel – Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-gray-50 p-6">
        <div className="w-full max-w-md">
          {/* Back Link */}
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-500 hover:text-indigo-700 transition-colors text-sm mb-8"
          >
            <ArrowLeft size={16} /> Back to Homepage
          </Link>

          {/* Mobile Logo */}
          <div className="flex items-center gap-3 mb-8 lg:hidden">
            <div className="w-10 h-10 bg-indigo-700 rounded-xl flex items-center justify-center">
              <GraduationCap size={22} className="text-white" />
            </div>
            <div>
              <p className="text-indigo-700 font-bold text-lg">UniLearn LMS</p>
              <p className="text-gray-400 text-xs">University Portal</p>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1
              className="text-gray-900 font-bold mb-1"
              style={{ fontSize: "1.75rem" }}
            >
              Welcome Back
            </h1>
            <p className="text-gray-500 mb-8">
              Sign in to access your personalized dashboard
            </p>

            {/* Login Card */}
            <Card className="rounded-3xl shadow-sm border-gray-100">
              <CardContent className="p-7">
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Alert
                      variant="destructive"
                      className="mb-5 rounded-xl border-red-200 bg-red-50 text-red-700"
                    >
                      <AlertCircle size={16} />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  </motion.div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label className="text-gray-700 mb-1.5">
                      Email Address
                    </Label>
                    <div className="relative">
                      <Mail
                        size={16}
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                      />
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.edu"
                        required
                        className="pl-10 pr-4 py-3 rounded-xl bg-gray-50"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <Label className="text-gray-700">Password</Label>
                      <Button
                        type="button"
                        variant="link"
                        className="text-indigo-700 text-xs h-auto p-0"
                      >
                        Forgot password?
                      </Button>
                    </div>
                    <div className="relative">
                      <Lock
                        size={16}
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                      />
                      <Input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        required
                        className="pl-10 pr-10 py-3 rounded-xl bg-gray-50"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? (
                          <EyeOff size={16} />
                        ) : (
                          <Eye size={16} />
                        )}
                      </Button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    size="lg"
                    className="w-full bg-gradient-to-r from-indigo-700 to-indigo-800 hover:from-indigo-600 hover:to-indigo-700 text-white py-3.5 rounded-xl shadow-lg shadow-indigo-200 mt-2 h-auto"
                  >
                    {loading ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />{" "}
                        Signing in...
                      </>
                    ) : (
                      "Sign In to Portal"
                    )}
                  </Button>
                </form>

                {/* Demo Accounts */}
                <div className="mt-6 pt-6 border-t border-gray-100">
                  <p className="text-gray-400 text-xs text-center mb-3 font-medium">
                    Quick Access — Demo Accounts
                  </p>
                  <div className="space-y-2">
                    {DEMO_ACCOUNTS.map((acc) => (
                      <Button
                        key={acc.role}
                        variant="outline"
                        onClick={() => fillDemo(acc.email, acc.password)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl h-auto text-sm ${acc.color}`}
                      >
                        <span
                          className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${acc.textColor} bg-white/60`}
                        >
                          {acc.icon}
                        </span>
                        <div className="flex-1 text-left">
                          <span
                            className={`font-semibold block text-xs ${acc.textColor}`}
                          >
                            {acc.role}
                          </span>
                          <span className="text-gray-500 text-xs">
                            {acc.desc}
                          </span>
                        </div>
                        <span className="text-xs text-gray-400 font-mono hidden sm:block">
                          {acc.email.split("@")[0]}
                        </span>
                      </Button>
                    ))}
                  </div>
                  <p className="text-gray-400 text-xs text-center mt-3 bg-gray-50 rounded-xl px-3 py-2">
                    Passwords:{" "}
                    <span className="font-mono text-gray-600">admin123</span> ·{" "}
                    <span className="font-mono text-gray-600">teacher123</span>{" "}
                    ·{" "}
                    <span className="font-mono text-gray-600">student123</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
