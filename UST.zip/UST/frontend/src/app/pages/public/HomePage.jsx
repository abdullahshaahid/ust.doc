import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { PublicNavbar } from "../../components/layout/PublicNavbar";
import { useData } from "../../context/DataContext";
import {
  GraduationCap,
  Users,
  BookOpen,
  Award,
  ArrowRight,
  MapPin,
  Calendar,
  Star,
  Globe,
  Microscope,
  Code2,
  Calculator,
  Atom,
  Briefcase,
  Play,
  CheckCircle,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  Mail,
  Phone,
  Twitter,
  Linkedin,
  Youtube,
  Instagram,
  Facebook,
  Quote,
  X,
  ChevronLeft,
  ChevronRight,
  Wifi,
  FlaskConical,
  Trophy,
  BookMarked,
  Target,
  Lightbulb,
} from "lucide-react";
import { motion } from "motion/react";
import hpData from "../../../data/homepage.json";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Dialog, DialogContent } from "../../components/ui/dialog";

// ─── Icon registry – maps JSON string names → Lucide components ──────────────
const iconMap = {
  Users,
  BookOpen,
  Award,
  GraduationCap,
  Code2,
  Calculator,
  Atom,
  Briefcase,
  Microscope,
  Zap,
  Globe,
  TrendingUp,
  Trophy,
  Star,
  Lightbulb,
  BookMarked,
  Target,
  Shield,
  Wifi,
  FlaskConical,
};

function LucideIcon({ name, size = 24 }) {
  const Icon = iconMap[name];
  return Icon ? <Icon size={size} /> : null;
}

// ─── Animated counter ────────────────────────────────────────────────────────
function useCounter(target, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime = null;
    const step = (ts) => {
      if (!startTime) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return count;
}

function AnimatedStat({ value, label, suffix = "", iconName }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  const count = useCounter(value, 1800, visible);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.3 },
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="text-center">
      <div className="flex items-center justify-center gap-2 mb-1">
        <span className="text-amber-400">
          <LucideIcon name={iconName} size={20} />
        </span>
        <span
          className="text-white font-bold"
          style={{ fontSize: "clamp(2rem, 4vw, 3rem)" }}
        >
          {count.toLocaleString()}
          {suffix}
        </span>
      </div>
      <p className="text-indigo-200 text-sm">{label}</p>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function HomePage() {
  const navigate = useNavigate();
  const { events, roadmap } = useData();
  const [activeRoadmapDept, setActiveRoadmapDept] =
    useState("Computer Science");
  const [selectedGalleryImg, setSelectedGalleryImg] = useState(null);
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  const deptRoadmap = (roadmap || [])
    .filter((r) => r.department === activeRoadmapDept)
    .sort((a, b) => a.semester - b.semester);
  const upcomingEvents = (events || [])
    .filter((e) => new Date(e.date) >= new Date())
    .slice(0, 6);

  // Testimonial auto-rotate
  useEffect(() => {
    const interval = setInterval(
      () => setTestimonialIdx((i) => (i + 1) % hpData.testimonials.length),
      5000,
    );
    return () => clearInterval(interval);
  }, []);

  // Gallery bento layout (works for any count):
  // img[0] → col-span-2 row-span-2 (featured hero)
  // img[9] → col-span-2 (wide accent, if exists)
  const gallerySpan = (i) =>
    i === 0
      ? "col-span-2 row-span-2"
      : i === 9 && hpData.gallery.length > 9
        ? "col-span-2"
        : "";

  return (
    <div className="min-h-screen bg-white">
      <PublicNavbar />

      {/* ── HERO ── */}
      <section
        id="home"
        className="relative min-h-screen flex items-center overflow-hidden"
      >
        <div className="absolute inset-0">
          <img
            src={hpData.hero.image}
            alt="University Campus"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-950/95 via-indigo-900/85 to-indigo-800/50" />
          <div className="absolute top-32 right-32 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-32 right-64 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-32">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white border border-white/20 rounded-full px-4 py-1.5 text-sm mb-6">
                <Star size={14} className="text-amber-400 fill-amber-400" />
                {hpData.hero.badge}
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-white font-bold leading-tight mb-6"
              style={{ fontSize: "clamp(2.5rem, 5.5vw, 4.5rem)" }}
            >
              {hpData.hero.title.split("UniLearn")[0]}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-300">
                UniLearn
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-indigo-100 text-lg mb-8 leading-relaxed max-w-xl"
            >
              {hpData.hero.subtitle}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                onClick={() => navigate("/login")}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-white px-8 py-4 rounded-2xl transition-all font-medium shadow-xl shadow-amber-500/30 text-base h-auto"
              >
                {hpData.hero.ctaPrimary} <ArrowRight size={18} />
              </Button>
              <Button
                variant="ghost"
                onClick={() =>
                  document
                    .querySelector("#about")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
                className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur text-white border border-white/30 px-8 py-4 rounded-2xl transition-colors text-base h-auto"
              >
                <Play size={16} className="fill-white" />{" "}
                {hpData.hero.ctaSecondary}
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.5 }}
              className="flex flex-wrap items-center gap-6 mt-10"
            >
              {hpData.hero.checkpoints.map((text) => (
                <span
                  key={text}
                  className="flex items-center gap-2 text-indigo-200 text-sm"
                >
                  <CheckCircle size={15} className="text-emerald-400" /> {text}
                </span>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Animated stats banner */}
        <div className="absolute bottom-0 left-0 right-0 bg-black/30 backdrop-blur-sm border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {hpData.stats.map((s) => (
                <AnimatedStat
                  key={s.label}
                  value={s.value}
                  label={s.label}
                  suffix={s.suffix}
                  iconName={s.icon}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-flex items-center gap-2 text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
                <Star size={12} className="fill-indigo-600" />{" "}
                {hpData.about.badge}
              </span>
              <h2
                className="text-gray-900 font-bold mt-4 mb-6"
                style={{ fontSize: "clamp(1.8rem, 3vw, 2.75rem)" }}
              >
                {hpData.about.title.split(hpData.about.titleHighlight)[0]}
                <span className="text-indigo-700">
                  {hpData.about.titleHighlight}
                </span>
              </h2>
              {hpData.about.paragraphs.map((p, i) => (
                <p
                  key={i}
                  className={`text-gray-600 leading-relaxed ${i < hpData.about.paragraphs.length - 1 ? "mb-5" : "mb-8"}`}
                >
                  {p}
                </p>
              ))}
              <div className="flex flex-wrap gap-4">
                {hpData.about.quickStats.map((s) => (
                  <div
                    key={s.label}
                    className="bg-white rounded-2xl px-5 py-4 border border-gray-100 shadow-sm text-center min-w-24"
                  >
                    <p className="text-indigo-700 font-bold text-xl">
                      {s.value}
                    </p>
                    <p className="text-gray-500 text-xs mt-0.5">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src={hpData.about.images.main}
                alt="University Campus"
                className="rounded-2xl w-full h-52 object-cover col-span-2 shadow-lg"
              />
              <img
                src={hpData.about.images.lab}
                alt="Science Lab"
                className="rounded-2xl w-full h-44 object-cover shadow-md"
              />
              <img
                src={hpData.about.images.teacher}
                alt="Teaching"
                className="rounded-2xl w-full h-44 object-cover shadow-md"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE US ── */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              Why UniLearn?
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Everything You Need to Succeed
            </h2>
            <p className="text-gray-500 mt-3 max-w-2xl mx-auto">
              From cutting-edge digital tools to world-class faculty, UniLearn
              provides a comprehensive ecosystem for academic excellence.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {hpData.features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                viewport={{ once: true }}
                className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md hover:-translate-y-1 transition-all group"
              >
                <div
                  className={`w-12 h-12 ${f.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                >
                  <LucideIcon name={f.icon} size={22} />
                </div>
                <h3 className="text-gray-900 font-semibold mb-2 text-sm">
                  {f.title}
                </h3>
                <p className="text-gray-500 text-xs leading-relaxed">
                  {f.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── DEPARTMENTS ── */}
      <section
        id="departments"
        className="py-24 bg-gradient-to-b from-gray-50 to-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              Academic Departments
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Explore Our Departments
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {hpData.departments.map((dept, i) => (
              <motion.div
                key={dept.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: i * 0.07 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all group cursor-pointer"
              >
                <div
                  className={`w-14 h-14 bg-gradient-to-br ${dept.color} rounded-2xl flex items-center justify-center text-white mb-5 shadow-md group-hover:scale-110 transition-transform`}
                >
                  <LucideIcon name={dept.icon} size={26} />
                </div>
                <h3 className="text-gray-900 font-semibold text-base mb-1">
                  {dept.name}
                </h3>
                <p className="text-gray-400 text-xs mb-4">{dept.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                  <span className="flex items-center gap-1.5 text-xs text-gray-500">
                    <Users size={13} className="text-gray-400" />
                    {dept.students} students
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-gray-500">
                    <BookOpen size={13} className="text-gray-400" />
                    {dept.courses} courses
                  </span>
                  <span
                    className={`text-xs font-medium ${dept.text} ${dept.bg} px-2.5 py-1 rounded-full`}
                  >
                    Enroll →
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── EVENTS ── */}
      <section id="events" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              University Events
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Upcoming Events & Activities
            </h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">
              Stay connected with campus life through our exciting lineup of
              academic, cultural, sports, and professional events.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingEvents.map((event, i) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition-all group"
              >
                <div className="relative overflow-hidden h-52">
                  <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize border ${hpData.eventTypeColors[event.type] || "bg-gray-100 text-gray-700"}`}
                    >
                      {event.type}
                    </span>
                    {event.registrationOpen && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700 border border-emerald-200">
                        Open
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-3 left-3 text-white">
                    <p className="text-xs opacity-80 flex items-center gap-1">
                      <MapPin size={11} />
                      {event.location}
                    </p>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-gray-900 font-semibold mb-2 line-clamp-1">
                    {event.title}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed line-clamp-2 mb-4">
                    {event.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-gray-400 text-xs">
                      <Calendar size={13} />
                      {new Date(event.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                    <Button
                      variant="link"
                      onClick={() => navigate("/login")}
                      className="text-indigo-700 text-xs font-medium hover:underline flex items-center gap-1 h-auto p-0"
                    >
                      Register <ArrowRight size={12} />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── ACHIEVEMENTS ── */}
      <section className="py-16 bg-gradient-to-b from-indigo-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2
              className="text-gray-900 font-bold"
              style={{ fontSize: "clamp(1.5rem, 2.5vw, 2rem)" }}
            >
              Awards & Recognition
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
            {hpData.achievements.map((a, i) => (
              <motion.div
                key={a.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                viewport={{ once: true }}
                className={`bg-gradient-to-br ${a.color} rounded-2xl p-5 text-white`}
              >
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center mb-3">
                  <LucideIcon name={a.icon} size={22} />
                </div>
                <p className="text-white/70 text-xs font-medium uppercase tracking-wide">
                  {a.year}
                </p>
                <p className="font-bold text-sm mt-1 leading-tight">
                  {a.title}
                </p>
                <p className="text-white/70 text-xs mt-1 leading-relaxed">
                  {a.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── GALLERY ── */}
      <section id="gallery" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              Photo Gallery
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Campus Life & Memories
            </h2>
            <p className="text-gray-500 mt-2">
              Click any photo to view full size
            </p>
          </div>

          <div
            className="grid grid-cols-2 md:grid-cols-4 gap-3"
            style={{ gridAutoRows: "220px" }}
          >
            {hpData.gallery.map((img, i) => (
              <div
                key={i}
                onClick={() => setSelectedGalleryImg(i)}
                className={`relative overflow-hidden rounded-2xl group cursor-pointer ${gallerySpan(i)}`}
              >
                <img
                  src={img.src}
                  alt={img.label}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-1 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <p className="text-white font-medium text-sm drop-shadow-sm">
                    {img.label}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Modal */}
      <Dialog
        open={selectedGalleryImg !== null}
        onOpenChange={(open) => {
          if (!open) setSelectedGalleryImg(null);
        }}
      >
        <DialogContent className="max-w-5xl bg-black/95 border-none p-0 gap-0 [&>button]:text-white [&>button]:hover:bg-white/20">
          {selectedGalleryImg !== null && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 -translate-y-1/2 text-white bg-white/10 hover:bg-white/20 rounded-full z-10"
                onClick={() =>
                  setSelectedGalleryImg((i) =>
                    i !== null
                      ? (i - 1 + hpData.gallery.length) % hpData.gallery.length
                      : 0,
                  )
                }
              >
                <ChevronLeft size={24} />
              </Button>
              <img
                src={hpData.gallery[selectedGalleryImg].src}
                alt={hpData.gallery[selectedGalleryImg].label}
                className="max-h-[85vh] w-full object-contain rounded-2xl"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white bg-white/10 hover:bg-white/20 rounded-full z-10"
                onClick={() =>
                  setSelectedGalleryImg((i) =>
                    i !== null ? (i + 1) % hpData.gallery.length : 0,
                  )
                }
              >
                <ChevronRight size={24} />
              </Button>
              <p className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/70 text-sm bg-black/30 px-4 py-1.5 rounded-full">
                {hpData.gallery[selectedGalleryImg].label} ·{" "}
                {selectedGalleryImg + 1} / {hpData.gallery.length}
              </p>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ── FACULTY SPOTLIGHT ── */}
      <section id="faculty" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              Our Faculty
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Meet Our Expert Faculty
            </h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">
              Learn from the best — internationally recognized researchers,
              industry veterans, and passionate educators.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {hpData.faculty.map((f, i) => (
              <motion.div
                key={f.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all group"
              >
                <div className="relative overflow-hidden h-64">
                  <img
                    src={f.image}
                    alt={f.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-indigo-950/80 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white font-bold text-lg leading-tight">
                      {f.name}
                    </p>
                    <p className="text-indigo-200 text-sm">{f.dept}</p>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-gray-700 text-sm font-medium mb-1">
                    {f.title}
                  </p>
                  <p className="text-gray-400 text-xs mb-1">
                    Specialization: {f.specialization}
                  </p>
                  <p className="text-gray-400 text-xs mb-4 italic">{f.bio}</p>
                  <div className="flex items-center gap-3 text-center">
                    <div className="flex-1 bg-gray-50 rounded-xl p-3">
                      <p className="text-indigo-700 font-bold">{f.papers}</p>
                      <p className="text-gray-400 text-xs">Papers</p>
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-xl p-3">
                      <p className="text-amber-600 font-bold">{f.awards}</p>
                      <p className="text-gray-400 text-xs">Awards</p>
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-xl p-3">
                      <p className="text-emerald-600 font-bold">{f.rating}</p>
                      <p className="text-gray-400 text-xs">Rating</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 bg-gradient-to-br from-indigo-950 via-indigo-900 to-indigo-800">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-amber-400 font-medium text-sm uppercase tracking-wider">
              Student Testimonials
            </span>
            <h2
              className="text-white font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              What Our Students Say
            </h2>
          </div>
          <div className="relative">
            <div className="bg-white/10 backdrop-blur border border-white/10 rounded-3xl p-8 md:p-10">
              <Quote size={40} className="text-amber-400/50 mb-4" />
              <p className="text-indigo-100 text-lg leading-relaxed mb-8 min-h-20">
                {hpData.testimonials[testimonialIdx].text}
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center text-white font-bold">
                  {hpData.testimonials[testimonialIdx].avatar}
                </div>
                <div>
                  <p className="text-white font-semibold">
                    {hpData.testimonials[testimonialIdx].name}
                  </p>
                  <p className="text-indigo-300 text-sm">
                    {hpData.testimonials[testimonialIdx].role} ·{" "}
                    {hpData.testimonials[testimonialIdx].dept}
                  </p>
                </div>
                <div className="ml-auto flex gap-1">
                  {Array.from({
                    length: hpData.testimonials[testimonialIdx].rating,
                  }).map((_, si) => (
                    <Star
                      key={si}
                      size={16}
                      className="text-amber-400 fill-amber-400"
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-center gap-2 mt-6">
              {hpData.testimonials.map((_, i) => (
                <Button
                  key={i}
                  variant="ghost"
                  onClick={() => setTestimonialIdx(i)}
                  className={`h-2 rounded-full transition-all p-0 min-w-0 ${i === testimonialIdx ? "bg-amber-400 w-8" : "bg-white/30 w-2"}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── ACADEMIC ROADMAP ── */}
      <section id="roadmap" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
              Academic Roadmap
            </span>
            <h2
              className="text-gray-900 font-bold mt-4"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              Your Journey to Success
            </h2>
            <p className="text-gray-500 mt-3 max-w-xl mx-auto">
              Explore the structured academic pathway for each department, from
              foundational courses to advanced specializations.
            </p>
          </div>

          {/* Department tabs — generated from hpData.departments */}
          <div className="flex flex-wrap gap-2 justify-center mb-10">
            {hpData.departments.map((dept) => (
              <Button
                key={dept.name}
                variant={
                  activeRoadmapDept === dept.name ? "default" : "outline"
                }
                onClick={() => setActiveRoadmapDept(dept.name)}
                className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all h-auto ${
                  activeRoadmapDept === dept.name
                    ? "bg-indigo-700 text-white shadow-lg shadow-indigo-200 hover:bg-indigo-800"
                    : "bg-white text-gray-600 hover:bg-indigo-50 hover:text-indigo-700 border-gray-200"
                }`}
              >
                {dept.name}
              </Button>
            ))}
          </div>

          {/* Timeline */}
          <div className="relative">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-indigo-100 md:-translate-x-px" />
            <div className="space-y-6">
              {deptRoadmap.map((item, idx) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  className={`relative flex ${idx % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"} flex-col gap-8 items-start md:items-center pl-12 md:pl-0`}
                >
                  <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-lg shadow-indigo-200 z-10 top-0 md:top-auto">
                    {item.semester}
                  </div>
                  <div
                    className={`w-full md:w-5/12 ${idx % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}
                  >
                    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-1 rounded-full text-xs font-medium">
                          Semester {item.semester}
                        </span>
                      </div>
                      <h3 className="text-gray-900 font-semibold mb-2">
                        {item.title}
                      </h3>
                      <p className="text-gray-500 text-sm mb-3">
                        {item.description}
                      </p>
                      <div className="space-y-1.5">
                        {(item.courses || []).slice(0, 4).map((c, ci) => (
                          <div
                            key={ci}
                            className="flex items-center gap-2 text-xs text-gray-600"
                          >
                            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full flex-shrink-0" />
                            {c}
                          </div>
                        ))}
                      </div>
                      <div className="mt-3 pt-3 border-t border-gray-50">
                        <p className="text-xs text-gray-400 font-medium mb-1">
                          Learning Outcomes:
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {(item.outcomes || []).map((o, oi) => (
                            <span
                              key={oi}
                              className="bg-emerald-50 text-emerald-700 text-xs px-2 py-0.5 rounded-full"
                            >
                              {o}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="hidden md:block w-5/12" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 bg-gradient-to-r from-indigo-700 via-indigo-800 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <span className="inline-flex items-center gap-2 bg-white/10 text-white border border-white/20 rounded-full px-4 py-1.5 text-sm mb-6">
            <Zap size={14} className="text-amber-400" /> Start Your Journey
            Today
          </span>
          <h2
            className="text-white font-bold mb-4"
            style={{ fontSize: "clamp(1.8rem, 3.5vw, 3rem)" }}
          >
            Ready to Begin Your Academic Journey?
          </h2>
          <p className="text-indigo-200 mb-10 text-lg max-w-2xl mx-auto">
            Join over {hpData.stats[0].value.toLocaleString()}+ students already
            learning on our platform. Access your personalized dashboard, manage
            your courses, and achieve your academic goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => navigate("/login")}
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-white px-10 py-4 rounded-2xl transition-all font-medium shadow-xl shadow-amber-500/30 text-lg h-auto"
            >
              Login to Portal <ArrowRight size={20} />
            </Button>
            <Button
              variant="ghost"
              onClick={() =>
                document
                  .querySelector("#departments")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/30 text-white px-10 py-4 rounded-2xl transition-colors text-lg h-auto"
            >
              Explore Departments
            </Button>
          </div>
        </div>
      </section>

      {/* ── CONTACT ── */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-indigo-700 font-medium text-sm uppercase tracking-wider bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
                Contact Us
              </span>
              <h2
                className="text-gray-900 font-bold mt-4 mb-5"
                style={{ fontSize: "clamp(1.8rem, 2.5vw, 2.25rem)" }}
              >
                Get in Touch
              </h2>
              <p className="text-gray-500 mb-8">
                Have questions about admissions, courses, or campus life? Our
                team is here to help you every step of the way.
              </p>
              <div className="space-y-4">
                {[
                  {
                    icon: <MapPin size={18} />,
                    label: "Campus Address",
                    value: hpData.contact.address,
                    color: "text-indigo-600 bg-indigo-50",
                  },
                  {
                    icon: <Phone size={18} />,
                    label: "Phone",
                    value: hpData.contact.phone,
                    color: "text-emerald-600 bg-emerald-50",
                  },
                  {
                    icon: <Mail size={18} />,
                    label: "Email",
                    value: hpData.contact.email,
                    color: "text-amber-600 bg-amber-50",
                  },
                  {
                    icon: <Clock size={18} />,
                    label: "Office Hours",
                    value: hpData.contact.hours,
                    color: "text-purple-600 bg-purple-50",
                  },
                ].map((item) => (
                  <div key={item.label} className="flex items-start gap-4">
                    <div
                      className={`w-10 h-10 ${item.color} rounded-xl flex items-center justify-center flex-shrink-0`}
                    >
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-gray-900 font-medium text-sm">
                        {item.label}
                      </p>
                      <p className="text-gray-500 text-sm">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
              <h3 className="text-gray-900 font-semibold mb-6">
                Send Us a Message
              </h3>
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label className="block text-sm text-gray-600 mb-1.5">
                      Full Name
                    </Label>
                    <Input
                      placeholder="Your full name"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-gray-50 h-auto"
                    />
                  </div>
                  <div>
                    <Label className="block text-sm text-gray-600 mb-1.5">
                      Email
                    </Label>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-gray-50 h-auto"
                    />
                  </div>
                </div>
                <div>
                  <Label className="block text-sm text-gray-600 mb-1.5">
                    Subject
                  </Label>
                  <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-gray-50">
                    <option>Admissions Inquiry</option>
                    <option>Course Information</option>
                    <option>Scholarship Programs</option>
                    <option>General Question</option>
                  </select>
                </div>
                <div>
                  <Label className="block text-sm text-gray-600 mb-1.5">
                    Message
                  </Label>
                  <Textarea
                    rows={4}
                    placeholder="Write your message here..."
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-gray-50 resize-none"
                  />
                </div>
                <Button className="w-full bg-indigo-700 hover:bg-indigo-800 text-white py-3.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 h-auto">
                  Send Message <ArrowRight size={16} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="bg-gray-950 text-gray-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">
            <div className="lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-indigo-700 rounded-xl flex items-center justify-center">
                  <GraduationCap size={20} className="text-white" />
                </div>
                <div>
                  <span className="text-white font-bold text-lg leading-none block">
                    UniLearn
                  </span>
                  <span className="text-gray-500 text-xs">University LMS</span>
                </div>
              </div>
              <p className="text-sm leading-relaxed mb-5">
                Empowering students and educators through world-class technology
                and academic excellence since 1960.
              </p>
              <div className="flex gap-3">
                {[Facebook, Twitter, Linkedin, Youtube, Instagram].map(
                  (Icon, i) => (
                    <Button
                      key={i}
                      variant="ghost"
                      size="icon"
                      className="w-9 h-9 bg-gray-800 hover:bg-indigo-700 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Icon size={16} />
                    </Button>
                  ),
                )}
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2.5">
                {hpData.footerLinks.quickLinks.map((l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="text-sm hover:text-white transition-colors hover:underline"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">
                Student Services
              </h4>
              <ul className="space-y-2.5">
                {hpData.footerLinks.studentServices.map((l) => (
                  <li key={l}>
                    <a
                      href="/login"
                      className="text-sm hover:text-white transition-colors hover:underline"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm">
                  <MapPin
                    size={15}
                    className="text-indigo-400 flex-shrink-0 mt-0.5"
                  />{" "}
                  {hpData.contact.address}
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Phone size={15} className="text-indigo-400 flex-shrink-0" />{" "}
                  +1 (800) UNI-LEARN
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Mail size={15} className="text-indigo-400 flex-shrink-0" />{" "}
                  info@unilearn.edu
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm">
              © {new Date().getFullYear()} UniLearn University. All rights
              reserved.
            </p>
            <div className="flex gap-6 text-sm">
              {[
                "Privacy Policy",
                "Terms of Service",
                "Cookie Policy",
                "Accessibility",
              ].map((l) => (
                <a
                  key={l}
                  href="#"
                  className="hover:text-white transition-colors"
                >
                  {l}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
