import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  Plus,
  Trash2,
  X,
  FileText,
  Video,
  Presentation,
  Link2,
  Search,
  Upload,
  Download,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import { Textarea } from "../../components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

const typeIcons = {
  pdf: <FileText size={18} className="text-red-500" />,
  video: <Video size={18} className="text-blue-500" />,
  slides: <Presentation size={18} className="text-amber-500" />,
  link: <Link2 size={18} className="text-emerald-500" />,
  document: <FileText size={18} className="text-indigo-500" />,
};
const typeBadge = {
  pdf: "bg-red-100 text-red-700",
  video: "bg-blue-100 text-blue-700",
  slides: "bg-amber-100 text-amber-700",
  link: "bg-emerald-100 text-emerald-700",
  document: "bg-indigo-100 text-indigo-700",
};

const emptyForm = {
  courseId: "",
  title: "",
  description: "",
  type: "pdf",
  url: "#",
  size: "",
};

export default function UploadLectures() {
  const { currentUser } = useAuth();
  const { courses, lectures, addLecture, deleteLecture } = useData();
  const [search, setSearch] = useState("");
  const [courseFilter, setCourseFilter] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const myCourses = courses.filter((c) => c.teacherId === currentUser?.id);
  const myLectures = lectures.filter((l) =>
    myCourses.some((c) => c.id === l.courseId),
  );
  const filtered = myLectures.filter((l) => {
    const matchSearch = l.title.toLowerCase().includes(search.toLowerCase());
    const matchCourse = courseFilter === "all" || l.courseId === courseFilter;
    return matchSearch && matchCourse;
  });

  const handleSave = () => {
    if (!form.courseId || !form.title) return;
    addLecture({
      id: `lec_${Date.now()}`,
      courseId: form.courseId,
      title: form.title,
      description: form.description,
      type: form.type,
      url: form.url || "#",
      uploadedAt: new Date().toISOString().split("T")[0],
      uploadedBy: currentUser?.id || "",
      size: form.size,
    });
    setShowModal(false);
    setForm(emptyForm);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Lectures</h1>
          <p className="text-gray-500 mt-1">
            Upload and manage course lectures and materials
          </p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
        >
          <Upload size={18} /> Upload Lecture
        </Button>
      </div>

      {/* Filters */}
      <Card className="rounded-2xl p-4 shadow-sm border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search lectures..."
            className="pl-9 rounded-xl bg-gray-50"
          />
        </div>
        <select
          value={courseFilter}
          onChange={(e) => setCourseFilter(e.target.value)}
          className="px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
        >
          <option value="all">All Courses ({myLectures.length})</option>
          {myCourses.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code} - {c.name}
            </option>
          ))}
        </select>
      </Card>

      {/* Course Groups */}
      {myCourses.map((course) => {
        const courseLectures = filtered.filter((l) => l.courseId === course.id);
        if (courseFilter !== "all" && courseFilter !== course.id) return null;
        if (courseLectures.length === 0 && courseFilter !== "all") return null;
        return (
          <Card
            key={course.id}
            className="rounded-2xl shadow-sm border-gray-100 overflow-hidden"
          >
            <div className="flex items-center justify-between px-5 py-4 bg-gray-50 border-b border-gray-100">
              <div>
                <span className="font-semibold text-gray-900">
                  {course.name}
                </span>
                <span className="ml-2 text-sm text-gray-400">
                  {course.code}
                </span>
              </div>
              <Badge className="bg-emerald-100 text-emerald-700 rounded-full">
                {courseLectures.length} lectures
              </Badge>
            </div>
            {courseLectures.length === 0 ? (
              <div className="py-8 text-center text-gray-400 text-sm">
                No lectures for this course yet
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {courseLectures.map((lec) => (
                  <div
                    key={lec.id}
                    className="flex items-center gap-4 px-5 py-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      {typeIcons[lec.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm">
                        {lec.title}
                      </p>
                      <p className="text-gray-400 text-xs">{lec.description}</p>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <Badge
                        className={`capitalize rounded-full ${typeBadge[lec.type]}`}
                      >
                        {lec.type}
                      </Badge>
                      {lec.size && (
                        <span className="text-xs text-gray-400 hidden sm:block">
                          {lec.size}
                        </span>
                      )}
                      <span className="text-xs text-gray-400 hidden md:block">
                        {new Date(lec.uploadedAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50"
                      >
                        <Download size={14} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteLecture(lec.id)}
                        className="h-7 w-7 text-gray-400 hover:text-red-600 hover:bg-red-50"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        );
      })}

      {filtered.length === 0 && courseFilter !== "all" && (
        <Card className="text-center py-16 rounded-2xl border-gray-100">
          <FileText size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400">No lectures found</p>
        </Card>
      )}

      {/* Upload Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload Lecture</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5">Course *</Label>
              <select
                value={form.courseId}
                onChange={(e) =>
                  setForm((f) => ({ ...f, courseId: e.target.value }))
                }
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
              >
                <option value="">Select course...</option>
                {myCourses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label className="mb-1.5">Lecture Title *</Label>
              <Input
                value={form.title}
                onChange={(e) =>
                  setForm((f) => ({ ...f, title: e.target.value }))
                }
                placeholder="e.g., Introduction to Arrays"
                className="rounded-xl"
              />
            </div>
            <div>
              <Label className="mb-1.5">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) =>
                  setForm((f) => ({ ...f, description: e.target.value }))
                }
                rows={2}
                placeholder="Brief description of what this lecture covers..."
                className="rounded-xl resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="mb-1.5">Material Type</Label>
                <select
                  value={form.type}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, type: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
                >
                  <option value="pdf">PDF Document</option>
                  <option value="video">Video</option>
                  <option value="slides">Slides</option>
                  <option value="link">External Link</option>
                  <option value="document">Document</option>
                </select>
              </div>
              <div>
                <Label className="mb-1.5">File Size / Duration</Label>
                <Input
                  value={form.size}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, size: e.target.value }))
                  }
                  placeholder="e.g., 2.4 MB / 45 min"
                  className="rounded-xl"
                />
              </div>
            </div>
            <div>
              <Label className="mb-1.5">URL / Link</Label>
              <Input
                value={form.url}
                onChange={(e) =>
                  setForm((f) => ({ ...f, url: e.target.value }))
                }
                placeholder="https://..."
                className="rounded-xl"
              />
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-sm text-emerald-700 flex items-start gap-2">
              <Upload size={16} className="flex-shrink-0 mt-0.5" />
              <span>
                In a production system, files would be uploaded directly here.
                For this demo, use a URL or leave as '#'.
              </span>
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
            >
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
