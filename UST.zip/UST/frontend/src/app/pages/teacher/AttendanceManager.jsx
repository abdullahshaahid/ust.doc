import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  UserCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Save,
  ChevronDown,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../components/ui/table";

export default function AttendanceManager() {
  const { currentUser } = useAuth();
  const { courses, users, attendanceRecords, addAttendance } = useData();

  const myCourses = courses.filter((c) => c.teacherId === currentUser?.id);
  const [selectedCourse, setSelectedCourse] = useState(myCourses[0]?.id || "");
  const [attendanceDate, setAttendanceDate] = useState(
    new Date().toISOString().split("T")[0],
  );
  const [records, setRecords] = useState({});
  const [saved, setSaved] = useState(false);

  const courseStudents = users.filter(
    (u) =>
      u.role === "student" &&
      (u.enrolledCourses || []).includes(selectedCourse),
  );
  const course = courses.find((c) => c.id === selectedCourse);

  // Load existing attendance for selected date/course
  const existingRecord = attendanceRecords.find(
    (r) => r.courseId === selectedCourse && r.date === attendanceDate,
  );

  const initRecords = () => {
    if (existingRecord) {
      const map = {};
      existingRecord.records.forEach((r) => {
        map[r.studentId] = r.status;
      });
      setRecords(map);
    } else {
      const map = {};
      courseStudents.forEach((s) => {
        map[s.id] = "present";
      });
      setRecords(map);
    }
  };

  const handleMarkAll = (status) => {
    const map = {};
    courseStudents.forEach((s) => {
      map[s.id] = status;
    });
    setRecords(map);
  };

  const handleSave = () => {
    const recordList = courseStudents.map((s) => ({
      studentId: s.id,
      status: records[s.id] || "absent",
    }));
    addAttendance({
      id: `att_${Date.now()}`,
      courseId: selectedCourse,
      date: attendanceDate,
      markedBy: currentUser?.id || "unknown",
      records: recordList,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  // Attendance history
  const courseHistory = attendanceRecords
    .filter((r) => r.courseId === selectedCourse)
    .sort((a, b) => b.date.localeCompare(a.date));

  const getInitials = (name) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">
          Attendance Management
        </h1>
        <p className="text-gray-500 mt-1">
          Mark and track student attendance for your courses
        </p>
      </div>

      {/* Controls */}
      <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
        <div className="grid sm:grid-cols-3 gap-4 mb-4">
          <div>
            <Label className="mb-1.5">Course</Label>
            <select
              value={selectedCourse}
              onChange={(e) => {
                setSelectedCourse(e.target.value);
                setRecords({});
                setSaved(false);
              }}
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
            >
              {myCourses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} - {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label className="mb-1.5">Date</Label>
            <Input
              type="date"
              value={attendanceDate}
              onChange={(e) => {
                setAttendanceDate(e.target.value);
                setRecords({});
                setSaved(false);
              }}
              className="rounded-xl"
            />
          </div>
          <div className="flex items-end">
            <Button
              onClick={initRecords}
              className="w-full bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl hover:bg-emerald-100"
            >
              Load Students
            </Button>
          </div>
        </div>

        {Object.keys(records).length > 0 && (
          <div className="flex flex-wrap gap-2">
            <span className="text-sm text-gray-500 font-medium self-center mr-2">
              Mark all:
            </span>
            <Button
              onClick={() => handleMarkAll("present")}
              className="flex items-center gap-1.5 bg-emerald-100 text-emerald-700 rounded-lg hover:bg-emerald-200"
            >
              <CheckCircle2 size={14} /> Present
            </Button>
            <Button
              onClick={() => handleMarkAll("absent")}
              className="flex items-center gap-1.5 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
            >
              <XCircle size={14} /> Absent
            </Button>
            <Button
              onClick={() => handleMarkAll("late")}
              className="flex items-center gap-1.5 bg-amber-100 text-amber-700 rounded-lg hover:bg-amber-200"
            >
              <Clock size={14} /> Late
            </Button>
          </div>
        )}
      </Card>

      {/* Student List */}
      {Object.keys(records).length > 0 ? (
        <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
          <div className="px-5 py-4 bg-gray-50 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">
                {course?.name} —{" "}
                {new Date(attendanceDate).toLocaleDateString("en-US", {
                  weekday: "long",
                  month: "long",
                  day: "numeric",
                })}
              </h3>
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-500">
                  {Object.values(records).filter((v) => v === "present").length}{" "}
                  present / {courseStudents.length}
                </span>
                <Button
                  onClick={handleSave}
                  className={`flex items-center gap-2 rounded-xl ${saved ? "bg-emerald-100 text-emerald-700" : "bg-emerald-600 text-white hover:bg-emerald-700"}`}
                >
                  <Save size={14} /> {saved ? "Saved!" : "Save Attendance"}
                </Button>
              </div>
            </div>
          </div>
          <div className="divide-y divide-gray-50">
            {courseStudents.map((student, idx) => {
              const status = records[student.id] || "absent";
              return (
                <div
                  key={student.id}
                  className="flex items-center gap-4 px-5 py-3.5"
                >
                  <span className="text-gray-300 text-sm w-6 text-right flex-shrink-0">
                    {idx + 1}
                  </span>
                  <div className="w-9 h-9 bg-indigo-600 rounded-full flex items-center justify-center text-white font-medium text-sm flex-shrink-0">
                    {getInitials(student.name)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm">
                      {student.name}
                    </p>
                    <p className="text-gray-400 text-xs">{student.studentId}</p>
                  </div>
                  <div className="flex gap-2">
                    {["present", "absent", "late"].map((s) => (
                      <Button
                        key={s}
                        onClick={() =>
                          setRecords((prev) => ({ ...prev, [student.id]: s }))
                        }
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${status === s ? (s === "present" ? "bg-emerald-500 text-white" : s === "absent" ? "bg-red-500 text-white" : "bg-amber-500 text-white") : "bg-gray-100 text-gray-400 hover:bg-gray-200"}`}
                      >
                        {s === "present" ? "✓" : s === "absent" ? "✗" : "~"} {s}
                      </Button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      ) : (
        <Card className="text-center py-12 rounded-2xl border-gray-100">
          <UserCheck size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400 text-sm">
            Select a course and date, then click "Load Students"
          </p>
        </Card>
      )}

      {/* Attendance History */}
      {courseHistory.length > 0 && (
        <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h3 className="font-semibold text-gray-900">
              Attendance History — {course?.name}
            </h3>
          </div>
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase">
                  Date
                </TableHead>
                <TableHead className="text-center px-4 py-3 text-xs font-semibold text-emerald-600 uppercase">
                  Present
                </TableHead>
                <TableHead className="text-center px-4 py-3 text-xs font-semibold text-red-500 uppercase">
                  Absent
                </TableHead>
                <TableHead className="text-center px-4 py-3 text-xs font-semibold text-amber-500 uppercase">
                  Late
                </TableHead>
                <TableHead className="text-center px-4 py-3 text-xs font-semibold text-gray-500 uppercase">
                  Rate
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-gray-50">
              {courseHistory.slice(0, 10).map((rec) => {
                const total = rec.records.length;
                const present = rec.records.filter(
                  (r) => r.status === "present",
                ).length;
                const absent = rec.records.filter(
                  (r) => r.status === "absent",
                ).length;
                const late = rec.records.filter(
                  (r) => r.status === "late",
                ).length;
                const rate =
                  total > 0
                    ? Math.round(((present + late * 0.5) / total) * 100)
                    : 0;
                return (
                  <TableRow key={rec.id} className="hover:bg-gray-50">
                    <TableCell className="px-5 py-3 text-sm text-gray-700">
                      {new Date(rec.date).toLocaleDateString("en-US", {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                      })}
                    </TableCell>
                    <TableCell className="px-4 py-3 text-center">
                      <Badge className="bg-emerald-100 text-emerald-700 rounded-full">
                        {present}
                      </Badge>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-center">
                      <Badge className="bg-red-100 text-red-700 rounded-full">
                        {absent}
                      </Badge>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-center">
                      <Badge className="bg-amber-100 text-amber-700 rounded-full">
                        {late}
                      </Badge>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-center">
                      <span
                        className={`text-xs font-semibold ${rate >= 75 ? "text-emerald-600" : "text-red-500"}`}
                      >
                        {rate}%
                      </span>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}
