import { useMemo } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import { StatsCard } from "../../components/shared/StatsCard";
import { useNavigate } from "react-router";
import {
  BookOpen,
  Users,
  ClipboardList,
  UserCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  TrendingUp,
  Bell,
  Plus,
  Award,
  Star,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Alert, AlertTitle } from "../../components/ui/alert";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import { CHART_COLORS as COLORS } from "../../constants/chartColors";

export default function TeacherDashboard() {
  const { currentUser } = useAuth();
  const {
    courses,
    lectures,
    assignments,
    attendanceRecords,
    users,
    announcements,
  } = useData();
  const navigate = useNavigate();

  const myCourses = useMemo(
    () => courses.filter((c) => c.teacherId === currentUser?.id),
    [courses, currentUser],
  );
  const myCourseIds = useMemo(() => myCourses.map((c) => c.id), [myCourses]);
  const myLectures = useMemo(
    () => lectures.filter((l) => myCourseIds.includes(l.courseId)),
    [lectures, myCourseIds],
  );
  const myAssignments = useMemo(
    () => assignments.filter((a) => myCourseIds.includes(a.courseId)),
    [assignments, myCourseIds],
  );

  const { totalStudents, pendingGrades, totalSubmissions } = useMemo(
    () => ({
      totalStudents: new Set(myCourses.flatMap((c) => c.enrolledStudents)).size,
      pendingGrades: myAssignments.reduce(
        (acc, a) =>
          acc + a.submissions.filter((s) => s.status === "submitted").length,
        0,
      ),
      totalSubmissions: myAssignments.reduce(
        (acc, a) => acc + a.submissions.length,
        0,
      ),
    }),
    [myCourses, myAssignments],
  );

  const recentAssignments = useMemo(
    () =>
      [...myAssignments]
        .sort(
          (a, b) =>
            new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime(),
        )
        .slice(0, 5),
    [myAssignments],
  );

  const courseAttendanceData = useMemo(
    () =>
      myCourses.map((c) => {
        const records = attendanceRecords.filter((r) => r.courseId === c.id);
        const totalStudentSlots = records.reduce(
          (acc, r) => acc + r.records.length,
          0,
        );
        const presentSlots = records.reduce(
          (acc, r) =>
            acc + r.records.filter((rec) => rec.status !== "absent").length,
          0,
        );
        const rate =
          totalStudentSlots > 0
            ? Math.round((presentSlots / totalStudentSlots) * 100)
            : 0;
        return { name: c.code, rate, students: c.enrolledStudents.length };
      }),
    [myCourses, attendanceRecords],
  );

  const submissionData = useMemo(
    () =>
      myCourses
        .map((c) => {
          const courseAsgns = myAssignments.filter((a) => a.courseId === c.id);
          const totalSubs = courseAsgns.reduce(
            (acc, a) => acc + a.submissions.length,
            0,
          );
          const graded = courseAsgns.reduce(
            (acc, a) =>
              acc + a.submissions.filter((s) => s.status === "graded").length,
            0,
          );
          return { name: c.code, graded, pending: totalSubs - graded };
        })
        .filter((d) => d.graded + d.pending > 0),
    [myCourses, myAssignments],
  );

  const myAnnouncements = useMemo(
    () =>
      announcements
        .filter(
          (a) =>
            a.isActive &&
            (a.targetRole === "all" || a.targetRole === "teacher"),
        )
        .slice(0, 3),
    [announcements],
  );

  const recentLectures = useMemo(
    () =>
      [...myLectures]
        .sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt))
        .slice(0, 4),
    [myLectures],
  );

  const typeColors = {
    pdf: "bg-red-100 text-red-600",
    video: "bg-blue-100 text-blue-600",
    slides: "bg-amber-100 text-amber-600",
    link: "bg-emerald-100 text-emerald-600",
    document: "bg-purple-100 text-purple-600",
  };

  const priorityColors = {
    high: "bg-red-50 border-red-200 text-red-700",
    medium: "bg-amber-50 border-amber-200 text-amber-700",
    low: "bg-blue-50 border-blue-200 text-blue-700",
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-700 to-emerald-900 rounded-2xl p-6 text-white">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Star size={16} className="text-amber-400 fill-amber-400" />
              <span className="text-emerald-200 text-sm">Teacher Portal</span>
            </div>
            <h1 className="text-white font-bold text-2xl">
              Welcome, {currentUser?.name}!
            </h1>
            <p className="text-emerald-200 mt-0.5 text-sm">
              {currentUser?.department} · ID: {currentUser?.teacherId} ·{" "}
              {myCourses.length} active courses
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => navigate("/teacher/lectures")}
              className="flex items-center gap-2 bg-white/15 hover:bg-white/25 border border-white/20 text-white rounded-xl text-sm"
            >
              <Plus size={15} /> Add Lecture
            </Button>
            <Button
              onClick={() => navigate("/teacher/assignments")}
              className="flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-white rounded-xl text-sm shadow-lg shadow-amber-500/30"
            >
              <ClipboardList size={15} /> Create Assignment
            </Button>
          </div>
        </div>
      </div>

      {/* Pending Grades Alert */}
      {pendingGrades > 0 && (
        <Alert className="bg-amber-50 border-amber-200 rounded-2xl p-4 flex items-start gap-3">
          <AlertCircle
            size={18}
            className="text-amber-600 flex-shrink-0 mt-0.5"
          />
          <div className="flex-1">
            <AlertTitle className="font-semibold text-amber-800">
              Grading Required
            </AlertTitle>
            <p className="text-amber-700 text-sm">
              {pendingGrades} submission(s) are awaiting your grading across all
              courses.
            </p>
          </div>
          <Button
            variant="link"
            onClick={() => navigate("/teacher/assignments")}
            className="text-amber-700 text-xs font-medium flex items-center gap-1 flex-shrink-0"
          >
            Grade Now <ArrowRight size={11} />
          </Button>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="My Courses"
          value={myCourses.length}
          icon={<BookOpen size={22} className="text-white" />}
          color="bg-indigo-600"
          subtitle="Active courses"
        />
        <StatsCard
          title="Total Students"
          value={totalStudents}
          icon={<Users size={22} className="text-white" />}
          color="bg-emerald-600"
          subtitle="Across all courses"
        />
        <StatsCard
          title="Lectures Uploaded"
          value={myLectures.length}
          icon={<ClipboardList size={22} className="text-white" />}
          color="bg-amber-500"
          subtitle="This semester"
        />
        <StatsCard
          title="Pending Grades"
          value={pendingGrades}
          icon={<UserCheck size={22} className="text-white" />}
          color={pendingGrades > 0 ? "bg-red-500" : "bg-gray-400"}
          subtitle="Awaiting review"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Attendance by Course Chart */}
        <Card className="lg:col-span-2 rounded-2xl p-5 shadow-sm border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4">
            Attendance Rate by Course (%)
          </h3>
          {courseAttendanceData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={courseAttendanceData} barSize={36}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v) => `${v}%`} />
                <Bar
                  dataKey="rate"
                  radius={[6, 6, 0, 0]}
                  label={{ position: "top", fontSize: 11, fill: "#6b7280" }}
                >
                  {courseAttendanceData.map((entry, i) => (
                    <Cell
                      key={i}
                      fill={
                        entry.rate >= 75
                          ? "#10b981"
                          : entry.rate >= 60
                            ? "#f59e0b"
                            : "#ef4444"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-gray-400">
              No attendance data yet
            </div>
          )}
        </Card>

        {/* Submission Status */}
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4">
            Submissions Overview
          </h3>
          <div className="space-y-3 mb-4">
            {[
              {
                label: "Total Submissions",
                value: totalSubmissions,
                color: "text-indigo-600",
              },
              {
                label: "Graded",
                value: myAssignments.reduce(
                  (a, b) =>
                    a +
                    b.submissions.filter((s) => s.status === "graded").length,
                  0,
                ),
                color: "text-emerald-600",
              },
              {
                label: "Pending Review",
                value: pendingGrades,
                color: "text-amber-600",
              },
              {
                label: "Assignments Created",
                value: myAssignments.length,
                color: "text-purple-600",
              },
            ].map((s) => (
              <div
                key={s.label}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-xl"
              >
                <span className="text-gray-600 text-sm">{s.label}</span>
                <span className={`font-bold text-lg ${s.color}`}>
                  {s.value}
                </span>
              </div>
            ))}
          </div>
          {submissionData.length > 0 && (
            <ResponsiveContainer width="100%" height={120}>
              <PieChart>
                <Pie
                  data={submissionData.slice(0, 3)}
                  cx="50%"
                  cy="50%"
                  innerRadius={30}
                  outerRadius={50}
                  dataKey="graded"
                  paddingAngle={3}
                >
                  {submissionData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* My Courses */}
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">My Courses</h3>
            <Button
              variant="link"
              onClick={() => navigate("/teacher/attendance")}
              className="text-emerald-700 text-xs flex items-center gap-1"
            >
              Mark Attendance <ArrowRight size={11} />
            </Button>
          </div>
          <div className="space-y-2.5">
            {myCourses.length === 0 && (
              <p className="text-gray-400 text-sm text-center py-8">
                No courses assigned yet
              </p>
            )}
            {myCourses.map((course) => {
              const courseStudents = users.filter(
                (u) =>
                  u.role === "student" &&
                  (u.enrolledCourses || []).includes(course.id),
              );
              const courseLectures = lectures.filter(
                (l) => l.courseId === course.id,
              );
              const courseAsgns = assignments.filter(
                (a) => a.courseId === course.id,
              );
              const pendingForCourse = courseAsgns.reduce(
                (acc, a) =>
                  acc +
                  a.submissions.filter((s) => s.status === "submitted").length,
                0,
              );
              return (
                <div
                  key={course.id}
                  className="flex items-center gap-4 p-3.5 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <BookOpen size={18} className="text-emerald-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {course.name}
                    </p>
                    <p className="text-gray-400 text-xs">
                      {course.code} · Sem {course.semester} ·{" "}
                      {courseLectures.length} lectures · {courseAsgns.length}{" "}
                      assignments
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-gray-900">
                      {courseStudents.length || course.enrolledStudents.length}
                    </p>
                    <p className="text-xs text-gray-400">students</p>
                    {pendingForCourse > 0 && (
                      <Badge className="bg-red-100 text-red-600 rounded-full">
                        {pendingForCourse} pending
                      </Badge>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Recent Assignments + Announcements */}
        <div className="space-y-4">
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Assignment Status</h3>
              <Button
                variant="link"
                onClick={() => navigate("/teacher/assignments")}
                className="text-emerald-700 text-xs flex items-center gap-1"
              >
                Manage <ArrowRight size={11} />
              </Button>
            </div>
            <div className="space-y-2.5">
              {recentAssignments.length === 0 && (
                <p className="text-gray-400 text-sm text-center py-4">
                  No assignments yet
                </p>
              )}
              {recentAssignments.slice(0, 3).map((asgn) => {
                const course = courses.find((c) => c.id === asgn.courseId);
                const submitted = asgn.submissions.length;
                const graded = asgn.submissions.filter(
                  (s) => s.status === "graded",
                ).length;
                const pending = submitted - graded;
                const isOverdue = new Date(asgn.dueDate) < new Date();
                return (
                  <div key={asgn.id} className="p-3.5 bg-gray-50 rounded-xl">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-medium text-gray-900 text-sm truncate">
                          {asgn.title}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {course?.code} · {asgn.totalMarks} marks · Due{" "}
                          {new Date(asgn.dueDate).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                      {isOverdue ? (
                        <AlertCircle
                          size={14}
                          className="text-red-400 flex-shrink-0"
                        />
                      ) : (
                        <CheckCircle2
                          size={14}
                          className="text-emerald-400 flex-shrink-0"
                        />
                      )}
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs">
                      <span className="flex items-center gap-1 text-indigo-600">
                        <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full" />
                        {submitted} submitted
                      </span>
                      <span className="flex items-center gap-1 text-emerald-600">
                        <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                        {graded} graded
                      </span>
                      {pending > 0 && (
                        <span className="flex items-center gap-1 text-amber-600">
                          <span className="w-1.5 h-1.5 bg-amber-400 rounded-full" />
                          {pending} pending
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Recent Lectures */}
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-gray-900 text-sm">
                Recent Uploads
              </h3>
              <Button
                variant="link"
                onClick={() => navigate("/teacher/lectures")}
                className="text-emerald-700 text-xs"
              >
                Manage
              </Button>
            </div>
            <div className="space-y-2">
              {recentLectures.map((lec) => {
                const course = courses.find((c) => c.id === lec.courseId);
                return (
                  <div
                    key={lec.id}
                    className="flex items-center gap-2.5 p-2.5 bg-gray-50 rounded-xl"
                  >
                    <Badge
                      className={`rounded uppercase ${typeColors[lec.type] || "bg-gray-100 text-gray-600"}`}
                    >
                      {lec.type}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900 truncate font-medium">
                        {lec.title}
                      </p>
                      <p className="text-xs text-gray-400">{course?.code}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>

      {/* Announcements for Teachers */}
      {myAnnouncements.length > 0 && (
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Bell size={16} className="text-emerald-600" /> Announcements for
            Faculty
          </h3>
          <div className="grid sm:grid-cols-3 gap-3">
            {myAnnouncements.map((ann) => (
              <div
                key={ann.id}
                className={`p-4 rounded-xl border ${priorityColors[ann.priority]}`}
              >
                <p className="font-medium text-sm mb-1">{ann.title}</p>
                <p className="text-xs opacity-75 line-clamp-2">{ann.content}</p>
                <p className="text-xs opacity-50 mt-2">
                  {new Date(ann.createdAt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  })}
                </p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
