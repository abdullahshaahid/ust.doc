import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  Calculator,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";

export default function AttendanceCalculator() {
  const { currentUser } = useAuth();
  const { courses, users, attendanceRecords } = useData();
  const [selectedCourse, setSelectedCourse] = useState("");

  const myCourses = courses.filter((c) => c.teacherId === currentUser?.id);
  const course = courses.find((c) => c.id === selectedCourse);
  const courseStudents = users.filter(
    (u) =>
      u.role === "student" &&
      (u.enrolledCourses || []).includes(selectedCourse),
  );
  const courseAttendance = attendanceRecords.filter(
    (r) => r.courseId === selectedCourse,
  );

  const totalClasses = courseAttendance.length;

  const studentStats = courseStudents.map((student) => {
    const present = courseAttendance.reduce((acc, rec) => {
      const r = rec.records.find((r) => r.studentId === student.id);
      return (
        acc + (r?.status === "present" ? 1 : r?.status === "late" ? 0.5 : 0)
      );
    }, 0);
    const absent = courseAttendance.reduce((acc, rec) => {
      const r = rec.records.find((r) => r.studentId === student.id);
      return acc + (r?.status === "absent" ? 1 : 0);
    }, 0);
    const late = courseAttendance.reduce((acc, rec) => {
      const r = rec.records.find((r) => r.studentId === student.id);
      return acc + (r?.status === "late" ? 1 : 0);
    }, 0);
    const percentage =
      totalClasses > 0 ? Math.round((present / totalClasses) * 100) : 0;
    const requiredClasses = Math.ceil(totalClasses * 0.75);
    const attended = courseAttendance.filter((rec) =>
      rec.records.some(
        (r) => r.studentId === student.id && r.status !== "absent",
      ),
    ).length;
    const canMiss = Math.max(0, Math.floor(totalClasses * 0.25) - absent);
    return {
      student,
      present,
      absent,
      late,
      percentage,
      requiredClasses,
      attended,
      canMiss,
    };
  });

  const getStatus = (pct) => {
    if (pct >= 90)
      return {
        label: "Excellent",
        color: "text-emerald-600",
        bg: "bg-emerald-100",
      };
    if (pct >= 75)
      return { label: "Good", color: "text-blue-600", bg: "bg-blue-100" };
    if (pct >= 60)
      return { label: "Warning", color: "text-amber-600", bg: "bg-amber-100" };
    return { label: "Critical", color: "text-red-600", bg: "bg-red-100" };
  };

  // Manual calculator
  const [manual, setManual] = useState({ attended: "", total: "" });
  const manualPct =
    manual.attended && manual.total
      ? Math.round((parseInt(manual.attended) / parseInt(manual.total)) * 100)
      : null;
  const toAttend75 = manual.total
    ? Math.max(
        0,
        Math.ceil(
          parseInt(manual.total) * 0.75 - (parseInt(manual.attended) || 0),
        ),
      )
    : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">
          Attendance Calculator
        </h1>
        <p className="text-gray-500 mt-1">
          Analyze student attendance and calculate percentages
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Course Selector */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <Label className="mb-2">Select Course</Label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
            >
              <option value="">Choose a course...</option>
              {myCourses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} - {c.name}
                </option>
              ))}
            </select>
          </Card>

          {selectedCourse && (
            <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
              <div className="px-5 py-4 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">
                    {course?.name}
                  </h3>
                  <p className="text-gray-400 text-xs">
                    {totalClasses} classes recorded · 75% minimum required
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-900">
                    {courseStudents.length}
                  </p>
                  <p className="text-gray-400 text-xs">students</p>
                </div>
              </div>

              {studentStats.length === 0 ? (
                <div className="py-12 text-center text-gray-400 text-sm">
                  No students enrolled
                </div>
              ) : (
                <div className="divide-y divide-gray-50">
                  {studentStats.map(
                    ({
                      student,
                      present,
                      absent,
                      late,
                      percentage,
                      canMiss,
                    }) => {
                      const status = getStatus(percentage);
                      return (
                        <div key={student.id} className="px-5 py-4">
                          <div className="flex items-center gap-4">
                            <div className="w-9 h-9 bg-indigo-600 rounded-full flex items-center justify-center text-white font-medium text-sm flex-shrink-0">
                              {student.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .slice(0, 2)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-medium text-gray-900 text-sm">
                                  {student.name}
                                </p>
                                <Badge
                                  className={`rounded-full ${status.bg} ${status.color}`}
                                >
                                  {status.label}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <div className="flex-1 bg-gray-100 rounded-full h-2">
                                  <div
                                    className="h-2 rounded-full transition-all"
                                    style={{
                                      width: `${percentage}%`,
                                      backgroundColor:
                                        percentage >= 75
                                          ? "#10b981"
                                          : percentage >= 60
                                            ? "#f59e0b"
                                            : "#ef4444",
                                    }}
                                  />
                                </div>
                                <span
                                  className={`text-sm font-bold ${status.color}`}
                                >
                                  {percentage}%
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="ml-13 mt-2 flex items-center gap-4 text-xs text-gray-500 ml-[52px]">
                            <span className="text-emerald-600">
                              ✓ {present} present
                            </span>
                            <span className="text-red-500">
                              ✗ {absent} absent
                            </span>
                            <span className="text-amber-500">
                              ~ {late} late
                            </span>
                            {canMiss > 0 && (
                              <span className="text-gray-400">
                                Can miss {canMiss} more
                              </span>
                            )}
                            {canMiss <= 0 && absent > 0 && (
                              <span className="text-red-600 font-medium">
                                ⚠ Cannot miss more classes
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    },
                  )}
                </div>
              )}
            </Card>
          )}
        </div>

        {/* Manual Calculator */}
        <div className="space-y-4">
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Calculator size={18} className="text-emerald-600" /> Quick
              Calculator
            </h3>
            <div className="space-y-3">
              <div>
                <Label className="mb-1.5">Classes Attended</Label>
                <Input
                  type="number"
                  value={manual.attended}
                  onChange={(e) =>
                    setManual((m) => ({ ...m, attended: e.target.value }))
                  }
                  min="0"
                  placeholder="e.g., 18"
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label className="mb-1.5">Total Classes</Label>
                <Input
                  type="number"
                  value={manual.total}
                  onChange={(e) =>
                    setManual((m) => ({ ...m, total: e.target.value }))
                  }
                  min="1"
                  placeholder="e.g., 24"
                  className="rounded-xl"
                />
              </div>
            </div>

            {manualPct !== null && (
              <div className="mt-5 space-y-3">
                <div
                  className={`rounded-2xl p-4 text-center ${manualPct >= 75 ? "bg-emerald-50 border border-emerald-200" : "bg-red-50 border border-red-200"}`}
                >
                  <p
                    className={`text-4xl font-bold ${manualPct >= 75 ? "text-emerald-600" : "text-red-600"}`}
                  >
                    {manualPct}%
                  </p>
                  <p
                    className={`text-sm mt-1 font-medium ${manualPct >= 75 ? "text-emerald-600" : "text-red-600"}`}
                  >
                    {manualPct >= 75
                      ? "✓ Meets requirement"
                      : "✗ Below minimum (75%)"}
                  </p>
                </div>
                {toAttend75 !== null && toAttend75 > 0 && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm text-amber-700">
                    <AlertTriangle size={14} className="inline mr-1" />
                    Needs <strong>{toAttend75} more classes</strong> to reach
                    75%
                  </div>
                )}
                {manualPct >= 75 && (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-sm text-emerald-700">
                    <CheckCircle2 size={14} className="inline mr-1" />
                    Can miss up to{" "}
                    <strong>
                      {Math.floor(parseInt(manual.total) * 0.25) -
                        (parseInt(manual.total) - parseInt(manual.attended))}
                    </strong>{" "}
                    more classes
                  </div>
                )}
              </div>
            )}
          </Card>

          {/* Reference Card */}
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-3 text-sm">
              Attendance Standards
            </h3>
            <div className="space-y-2">
              {[
                { range: "90%+", label: "Excellent", color: "bg-emerald-500" },
                {
                  range: "75–89%",
                  label: "Good Standing",
                  color: "bg-blue-500",
                },
                {
                  range: "60–74%",
                  label: "Warning Zone",
                  color: "bg-amber-500",
                },
                { range: "Below 60%", label: "Critical", color: "bg-red-500" },
              ].map((item) => (
                <div key={item.range} className="flex items-center gap-3">
                  <div
                    className={`w-2.5 h-2.5 rounded-full ${item.color} flex-shrink-0`}
                  />
                  <span className="text-xs text-gray-500 flex-1">
                    {item.label}
                  </span>
                  <span className="text-xs font-medium text-gray-700">
                    {item.range}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-400">
              Minimum 75% attendance required to sit exams
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
