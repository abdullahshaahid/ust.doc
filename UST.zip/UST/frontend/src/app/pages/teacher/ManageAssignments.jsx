import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  Plus,
  X,
  CheckCircle2,
  Clock,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Star,
  Trash2,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import { Textarea } from "../../components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

const emptyForm = {
  courseId: "",
  title: "",
  description: "",
  dueDate: "",
  totalMarks: "20",
};

export default function ManageAssignments() {
  const { currentUser } = useAuth();
  const {
    courses,
    assignments,
    addAssignment,
    deleteAssignment,
    gradeSubmission,
    users,
  } = useData();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [expanded, setExpanded] = useState(null);
  const [grading, setGrading] = useState(null);

  const myCourses = courses.filter((c) => c.teacherId === currentUser?.id);
  const myAssignments = assignments.filter((a) =>
    myCourses.some((c) => c.id === a.courseId),
  );

  const handleSave = () => {
    if (!form.courseId || !form.title || !form.dueDate) return;
    addAssignment({
      id: `asgn_${Date.now()}`,
      courseId: form.courseId,
      title: form.title,
      description: form.description,
      dueDate: form.dueDate,
      totalMarks: parseInt(form.totalMarks),
      createdBy: currentUser?.id || "",
    });
    setShowModal(false);
    setForm(emptyForm);
  };

  const handleGrade = () => {
    if (!grading) return;
    gradeSubmission(grading.assignId, grading.studentId, {
      marks: parseInt(grading.marks),
      feedback: grading.feedback,
      gradedBy: currentUser?.id,
    });
    setGrading(null);
  };

  const getStudent = (id) => users.find((u) => u.id === id);

  const statusBadge = (asgn) => {
    const isOverdue = new Date(asgn.dueDate) < new Date();
    if (isOverdue)
      return (
        <Badge className="flex items-center gap-1 bg-red-100 text-red-700 rounded-full">
          <AlertCircle size={11} /> Overdue
        </Badge>
      );
    return (
      <Badge className="flex items-center gap-1 bg-emerald-100 text-emerald-700 rounded-full">
        <Clock size={11} /> Active
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Assignments</h1>
          <p className="text-gray-500 mt-1">
            Create assignments and grade student submissions
          </p>
        </div>
        <Button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
        >
          <Plus size={18} /> Create Assignment
        </Button>
      </div>

      {/* Assignment List */}
      <div className="space-y-4">
        {myAssignments.length === 0 && (
          <Card className="text-center py-16 rounded-2xl border-gray-100">
            <p className="text-gray-400">No assignments created yet</p>
          </Card>
        )}
        {myAssignments.map((asgn) => {
          const course = courses.find((c) => c.id === asgn.courseId);
          const isOpen = expanded === asgn.id;
          const graded = asgn.submissions.filter(
            (s) => s.status === "graded",
          ).length;
          const pending = asgn.submissions.filter(
            (s) => s.status === "submitted",
          ).length;
          return (
            <Card
              key={asgn.id}
              className="rounded-2xl shadow-sm border-gray-100 overflow-hidden"
            >
              <div
                className="flex items-center gap-4 p-5 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setExpanded(isOpen ? null : asgn.id)}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-gray-900">
                      {asgn.title}
                    </h3>
                    {statusBadge(asgn)}
                  </div>
                  <p className="text-gray-400 text-xs mt-1">
                    {course?.code} · {course?.name} · Due:{" "}
                    {new Date(asgn.dueDate).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}{" "}
                    · {asgn.totalMarks} marks
                  </p>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <div className="text-center hidden sm:block">
                    <p className="font-bold text-gray-900 text-lg">
                      {asgn.submissions.length}
                    </p>
                    <p className="text-gray-400 text-xs">submitted</p>
                  </div>
                  <div className="text-center hidden sm:block">
                    <p className="font-bold text-emerald-600 text-lg">
                      {graded}
                    </p>
                    <p className="text-gray-400 text-xs">graded</p>
                  </div>
                  {pending > 0 && (
                    <div className="text-center hidden sm:block">
                      <p className="font-bold text-amber-500 text-lg">
                        {pending}
                      </p>
                      <p className="text-gray-400 text-xs">pending</p>
                    </div>
                  )}
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteAssignment(asgn.id);
                    }}
                    variant="ghost"
                    size="icon"
                    className="text-gray-400 hover:text-red-600 hover:bg-red-50"
                  >
                    <Trash2 size={15} />
                  </Button>
                  {isOpen ? (
                    <ChevronUp size={18} className="text-gray-400" />
                  ) : (
                    <ChevronDown size={18} className="text-gray-400" />
                  )}
                </div>
              </div>

              {isOpen && (
                <div className="border-t border-gray-100 p-5">
                  <p className="text-gray-600 text-sm mb-4">
                    {asgn.description}
                  </p>
                  {asgn.submissions.length === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-6">
                      No submissions yet
                    </p>
                  ) : (
                    <div className="space-y-3">
                      <p className="font-semibold text-gray-700 text-sm">
                        Submissions ({asgn.submissions.length})
                      </p>
                      {asgn.submissions.map((sub) => {
                        const student = getStudent(sub.studentId);
                        return (
                          <div
                            key={sub.studentId}
                            className="flex items-center gap-4 p-3.5 bg-gray-50 rounded-xl"
                          >
                            <div className="w-9 h-9 bg-indigo-600 rounded-full flex items-center justify-center text-white font-medium text-sm flex-shrink-0">
                              {student?.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")
                                .slice(0, 2)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-gray-900 text-sm">
                                {student?.name}
                              </p>
                              <p className="text-gray-400 text-xs">
                                Submitted:{" "}
                                {new Date(sub.submittedAt).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="flex items-center gap-3">
                              {sub.status === "graded" ? (
                                <div className="text-right">
                                  <p className="font-bold text-emerald-600">
                                    {sub.marks}/{asgn.totalMarks}
                                  </p>
                                  <p className="text-xs text-gray-400 line-clamp-1 max-w-32">
                                    {sub.feedback}
                                  </p>
                                </div>
                              ) : (
                                <Button
                                  onClick={() =>
                                    setGrading({
                                      assignId: asgn.id,
                                      studentId: sub.studentId,
                                      marks: "",
                                      feedback: "",
                                    })
                                  }
                                  className="flex items-center gap-1.5 bg-emerald-600 text-white rounded-lg text-xs hover:bg-emerald-700"
                                >
                                  <Star size={12} /> Grade
                                </Button>
                              )}
                              <Badge
                                className={`capitalize rounded-full ${sub.status === "graded" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}
                              >
                                {sub.status}
                              </Badge>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* Create Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Assignment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5">Course *</Label>
              <select
                value={form.courseId}
                onChange={(e) =>
                  setForm((f) => ({ ...f, courseId: e.target.value }))
                }
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-white"
              >
                <option value="">Select course...</option>
                {myCourses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label className="mb-1.5">Assignment Title *</Label>
              <Input
                value={form.title}
                onChange={(e) =>
                  setForm((f) => ({ ...f, title: e.target.value }))
                }
                placeholder="e.g., Lab Report 1"
                className="rounded-xl"
              />
            </div>
            <div>
              <Label className="mb-1.5">Instructions</Label>
              <Textarea
                value={form.description}
                onChange={(e) =>
                  setForm((f) => ({ ...f, description: e.target.value }))
                }
                rows={3}
                placeholder="Describe the assignment requirements..."
                className="rounded-xl resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="mb-1.5">Due Date *</Label>
                <Input
                  type="date"
                  value={form.dueDate}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, dueDate: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label className="mb-1.5">Total Marks</Label>
                <Input
                  type="number"
                  value={form.totalMarks}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, totalMarks: e.target.value }))
                  }
                  min="1"
                  className="rounded-xl"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
            >
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Grading Modal */}
      <Dialog
        open={!!grading}
        onOpenChange={(open) => !open && setGrading(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm">
          <DialogHeader>
            <DialogTitle>Grade Submission</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5">
                Marks /{" "}
                {
                  assignments.find((a) => a.id === grading?.assignId)
                    ?.totalMarks
                }
              </Label>
              <Input
                type="number"
                value={grading?.marks ?? ""}
                onChange={(e) =>
                  setGrading((g) =>
                    g ? { ...g, marks: Number(e.target.value) } : g,
                  )
                }
                min="0"
                max={
                  assignments.find((a) => a.id === grading?.assignId)
                    ?.totalMarks
                }
                className="rounded-xl"
              />
            </div>
            <div>
              <Label className="mb-1.5">Feedback</Label>
              <Textarea
                value={grading?.feedback ?? ""}
                onChange={(e) =>
                  setGrading((g) =>
                    g ? { ...g, feedback: e.target.value } : g,
                  )
                }
                rows={3}
                placeholder="Write feedback for the student..."
                className="rounded-xl resize-none"
              />
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setGrading(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleGrade}
              className="flex-1 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
            >
              Submit Grade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
