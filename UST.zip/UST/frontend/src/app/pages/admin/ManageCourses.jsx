import { useState } from "react";
import { useData } from "../../context/DataContext";
import { Plus, Edit2, Trash2, X, Search, BookOpen, Users } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card, CardContent } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import { Textarea } from "../../components/ui/textarea";

const DEPARTMENTS = [
  "Computer Science",
  "Mathematics",
  "Physics",
  "Business Administration",
];

const emptyForm = {
  name: "",
  code: "",
  department: "Computer Science",
  teacherId: "",
  credits: "3",
  description: "",
  semester: "1",
};

export default function ManageCourses() {
  const { courses, users, addCourse, updateCourse, deleteCourse } = useData();
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [editCourse, setEditCourse] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const teachers = users.filter((u) => u.role === "teacher");

  const filtered = courses.filter((c) => {
    const matchSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.code.toLowerCase().includes(search.toLowerCase());
    const matchDept = deptFilter === "all" || c.department === deptFilter;
    return matchSearch && matchDept;
  });

  const getTeacher = (id) => teachers.find((t) => t.id === id);
  const getStudentCount = (id) =>
    users.filter(
      (u) => u.role === "student" && (u.enrolledCourses || []).includes(id),
    ).length;

  const openAdd = () => {
    setForm(emptyForm);
    setEditCourse(null);
    setShowModal(true);
  };
  const openEdit = (c) => {
    setForm({
      name: c.name,
      code: c.code,
      department: c.department,
      teacherId: c.teacherId,
      credits: String(c.credits),
      description: c.description,
      semester: String(c.semester),
    });
    setEditCourse(c);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.name || !form.code) return;
    if (editCourse) {
      updateCourse(editCourse.id, {
        ...form,
        credits: parseInt(form.credits),
        semester: parseInt(form.semester),
      });
    } else {
      addCourse({
        id: `course_${Date.now()}`,
        ...form,
        credits: parseInt(form.credits),
        semester: parseInt(form.semester),
      });
    }
    setShowModal(false);
  };

  const deptColors = {
    "Computer Science": "bg-indigo-100 text-indigo-700",
    Mathematics: "bg-amber-100 text-amber-700",
    Physics: "bg-purple-100 text-purple-700",
    "Business Administration": "bg-emerald-100 text-emerald-700",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Manage Courses</h1>
          <p className="text-gray-500 mt-1">
            Create and manage university courses
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
        >
          <Plus size={18} /> Add Course
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search courses..."
            className="pl-9 rounded-xl bg-gray-50"
          />
        </div>
        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          className="px-4 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
        >
          <option value="all">All Departments</option>
          {DEPARTMENTS.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </select>
      </div>

      {/* Courses Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.length === 0 && (
          <div className="col-span-3 text-center py-16 bg-white rounded-2xl border border-gray-100">
            <BookOpen size={32} className="text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400">No courses found</p>
          </div>
        )}
        {filtered.map((course) => {
          const teacher = getTeacher(course.teacherId);
          const studentCount =
            getStudentCount(course.id) || course.enrolledStudents.length;
          return (
            <Card
              key={course.id}
              className="rounded-2xl hover:shadow-md transition-shadow"
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center">
                      <BookOpen size={18} className="text-indigo-700" />
                    </div>
                    <div>
                      <span className="text-xs font-mono text-gray-400">
                        {course.code}
                      </span>
                      <p className="font-semibold text-gray-900 text-sm leading-tight">
                        {course.name}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1.5 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEdit(course)}
                      className="h-7 w-7 text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                    >
                      <Edit2 size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteConfirm(course.id)}
                      className="h-7 w-7 text-gray-400 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
                <p className="text-gray-500 text-xs line-clamp-2 mb-3">
                  {course.description}
                </p>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge
                    variant="secondary"
                    className={`rounded-full ${deptColors[course.department] || "bg-gray-100 text-gray-600"}`}
                  >
                    {course.department}
                  </Badge>
                  <Badge
                    variant="secondary"
                    className="rounded-full bg-gray-100 text-gray-600"
                  >
                    {course.credits} Credits
                  </Badge>
                  <Badge
                    variant="secondary"
                    className="rounded-full bg-gray-100 text-gray-600"
                  >
                    Sem {course.semester}
                  </Badge>
                </div>
                <div className="mt-3 pt-3 border-t border-gray-50 flex items-center justify-between text-xs text-gray-400">
                  <span>👨‍🏫 {teacher?.name || "Unassigned"}</span>
                  <span className="flex items-center gap-1">
                    <Users size={12} /> {studentCount} students
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editCourse ? "Edit Course" : "Add New Course"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Course Name *</Label>
                <Input
                  value={form.name}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, name: e.target.value }))
                  }
                  placeholder="e.g., Introduction to Programming"
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Course Code *</Label>
                <Input
                  value={form.code}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, code: e.target.value }))
                  }
                  placeholder="e.g., CS101"
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Credits</Label>
                <select
                  value={form.credits}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, credits: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {[1, 2, 3, 4, 5].map((c) => (
                    <option key={c} value={c}>
                      {c} Credits
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Department</Label>
                <select
                  value={form.department}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, department: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {DEPARTMENTS.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Semester</Label>
                <select
                  value={form.semester}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, semester: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={s}>
                      Semester {s}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Assign Teacher</Label>
                <select
                  value={form.teacherId}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, teacherId: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  <option value="">Select teacher...</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.department})
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Description</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, description: e.target.value }))
                  }
                  rows={3}
                  placeholder="Course description..."
                  className="rounded-xl resize-none"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editCourse ? "Save Changes" : "Add Course"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trash2 size={20} className="text-red-600" />
          </div>
          <DialogHeader>
            <DialogTitle>Delete Course?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-500 text-sm mb-2">
            All associated data will be affected.
          </p>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteCourse(deleteConfirm);
                setDeleteConfirm(null);
              }}
              className="flex-1 rounded-xl"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
