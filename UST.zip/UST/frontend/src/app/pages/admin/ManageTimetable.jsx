import { useState } from "react";
import { useData } from "../../context/DataContext";
import { Plus, Edit2, Trash2, X, Clock } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card, CardContent } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

const DAYS = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
const TYPES = ["lecture", "lab", "tutorial"];

const emptyForm = {
  courseId: "",
  day: "Monday",
  startTime: "09:00",
  endTime: "10:30",
  room: "",
  type: "lecture",
};

const typeColors = {
  lecture: "bg-indigo-100 text-indigo-700",
  lab: "bg-emerald-100 text-emerald-700",
  tutorial: "bg-amber-100 text-amber-700",
};
const dayColors = {
  Monday: "bg-blue-50 border-blue-100",
  Tuesday: "bg-purple-50 border-purple-100",
  Wednesday: "bg-green-50 border-green-100",
  Thursday: "bg-orange-50 border-orange-100",
  Friday: "bg-pink-50 border-pink-100",
  Saturday: "bg-gray-50 border-gray-200",
};

export default function ManageTimetable() {
  const {
    timetable,
    courses,
    addTimetableEntry,
    updateTimetableEntry,
    deleteTimetableEntry,
  } = useData();
  const [showModal, setShowModal] = useState(false);
  const [editEntry, setEditEntry] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [activeDay, setActiveDay] = useState("Monday");

  const getCourse = (id) => courses.find((c) => c.id === id);
  const dayEntries = timetable
    .filter((t) => t.day === activeDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const openAdd = () => {
    setForm({ ...emptyForm, day: activeDay });
    setEditEntry(null);
    setShowModal(true);
  };
  const openEdit = (e) => {
    setForm({
      courseId: e.courseId,
      day: e.day,
      startTime: e.startTime,
      endTime: e.endTime,
      room: e.room,
      type: e.type,
    });
    setEditEntry(e);
    setShowModal(true);
  };
  const handleSave = () => {
    if (!form.courseId || !form.room) return;
    if (editEntry) {
      updateTimetableEntry(editEntry.id, form);
    } else {
      addTimetableEntry({
        id: `tt_${Date.now()}`,
        ...form,
      });
    }
    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">
            Timetable Management
          </h1>
          <p className="text-gray-500 mt-1">
            Schedule classes and labs for all courses
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
        >
          <Plus size={18} /> Add Schedule
        </Button>
      </div>

      {/* Day Tabs */}
      <div className="flex flex-wrap gap-2">
        {DAYS.map((day) => (
          <Button
            key={day}
            onClick={() => setActiveDay(day)}
            variant={activeDay === day ? "default" : "outline"}
            className={`rounded-xl ${activeDay === day ? "bg-indigo-700 hover:bg-indigo-800" : ""}`}
          >
            {day}
            <span className="ml-1.5 text-xs opacity-70">
              ({timetable.filter((t) => t.day === day).length})
            </span>
          </Button>
        ))}
      </div>

      {/* Weekly Overview Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <h3 className="font-semibold text-gray-900">{activeDay} Schedule</h3>
        </div>
        {dayEntries.length === 0 ? (
          <div className="text-center py-12">
            <Clock size={32} className="text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400">
              No classes scheduled for {activeDay}
            </p>
            <Button
              variant="link"
              onClick={openAdd}
              className="mt-2 text-indigo-700"
            >
              Add schedule
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {dayEntries.map((entry) => {
              const course = getCourse(entry.courseId);
              return (
                <div
                  key={entry.id}
                  className={`flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors`}
                >
                  <div className="flex-shrink-0 text-center w-24">
                    <p className="text-sm font-semibold text-gray-900">
                      {entry.startTime}
                    </p>
                    <p className="text-xs text-gray-400">to {entry.endTime}</p>
                  </div>
                  <div
                    className={`w-1 h-12 rounded-full ${entry.type === "lecture" ? "bg-indigo-500" : entry.type === "lab" ? "bg-emerald-500" : "bg-amber-500"}`}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {course?.name || "Unknown Course"}
                    </p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-gray-500 font-mono">
                        {course?.code}
                      </span>
                      <span className="text-xs text-gray-400">
                        📍 {entry.room}
                      </span>
                    </div>
                  </div>
                  <Badge
                    variant="secondary"
                    className={`rounded-full capitalize ${typeColors[entry.type]}`}
                  >
                    {entry.type}
                  </Badge>
                  <div className="flex gap-1.5 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEdit(entry)}
                      className="h-7 w-7 text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                    >
                      <Edit2 size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteTimetableEntry(entry.id)}
                      className="h-7 w-7 text-gray-400 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Full Week Overview */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5">
        <h3 className="font-semibold text-gray-900 mb-4">Weekly Overview</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {DAYS.map((day) => {
            const entries = timetable
              .filter((t) => t.day === day)
              .sort((a, b) => a.startTime.localeCompare(b.startTime));
            return (
              <div
                key={day}
                className={`rounded-xl p-3 border ${dayColors[day] || "bg-gray-50 border-gray-100"}`}
              >
                <p className="font-semibold text-gray-700 text-sm mb-2">
                  {day.slice(0, 3)}
                </p>
                <div className="space-y-1.5">
                  {entries.length === 0 && (
                    <p className="text-gray-400 text-xs">Free</p>
                  )}
                  {entries.map((e) => {
                    const course = getCourse(e.courseId);
                    return (
                      <div
                        key={e.id}
                        className="bg-white rounded-lg p-1.5 border border-white/50 shadow-sm"
                      >
                        <p className="text-xs font-medium text-gray-700 truncate">
                          {course?.code}
                        </p>
                        <p className="text-xs text-gray-400">{e.startTime}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editEntry ? "Edit Schedule" : "Add Schedule"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-gray-700">Course *</Label>
              <select
                value={form.courseId}
                onChange={(e) =>
                  setForm((f) => ({ ...f, courseId: e.target.value }))
                }
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
              >
                <option value="">Select course...</option>
                {courses.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-gray-700">Day</Label>
                <select
                  value={form.day}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, day: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {DAYS.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Type</Label>
                <select
                  value={form.type}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, type: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {TYPES.map((t) => (
                    <option key={t} className="capitalize">
                      {t.charAt(0).toUpperCase() + t.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Start Time</Label>
                <Input
                  type="time"
                  value={form.startTime}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, startTime: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">End Time</Label>
                <Input
                  type="time"
                  value={form.endTime}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, endTime: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Room *</Label>
                <Input
                  value={form.room}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, room: e.target.value }))
                  }
                  placeholder="e.g., CS-101, Lab-3"
                  className="rounded-xl"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editEntry ? "Save" : "Add"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
