import { useState } from "react";
import { useData } from "../../context/DataContext";
import { Plus, Edit2, Trash2, X, ChevronRight, Map } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card, CardContent } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import { Textarea } from "../../components/ui/textarea";

const DEPARTMENTS = [
  "Computer Science",
  "Mathematics",
  "Physics",
  "Business Administration",
];

const emptyForm = {
  department: "Computer Science",
  semester: "1",
  title: "",
  description: "",
  courses: "",
  outcomes: "",
};

const deptColors = {
  "Computer Science": "border-indigo-300 bg-indigo-50",
  Mathematics: "border-amber-300 bg-amber-50",
  Physics: "border-purple-300 bg-purple-50",
  "Business Administration": "border-emerald-300 bg-emerald-50",
};
const deptBadge = {
  "Computer Science": "bg-indigo-100 text-indigo-700",
  Mathematics: "bg-amber-100 text-amber-700",
  Physics: "bg-purple-100 text-purple-700",
  "Business Administration": "bg-emerald-100 text-emerald-700",
};

export default function ManageRoadmap() {
  const { roadmap, addRoadmapItem, updateRoadmapItem, deleteRoadmapItem } =
    useData();
  const [activeDept, setActiveDept] = useState("Computer Science");
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const deptItems = roadmap
    .filter((r) => r.department === activeDept)
    .sort((a, b) => a.semester - b.semester);

  const openAdd = () => {
    setForm({ ...emptyForm, department: activeDept });
    setEditItem(null);
    setShowModal(true);
  };
  const openEdit = (item) => {
    setForm({
      department: item.department,
      semester: String(item.semester),
      title: item.title,
      description: item.description,
      courses: item.courses.join("\n"),
      outcomes: item.outcomes.join("\n"),
    });
    setEditItem(item);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.title) return;
    const data = {
      department: form.department,
      semester: parseInt(form.semester),
      title: form.title,
      description: form.description,
      skills: form.courses.split("\n").filter(Boolean).join(", "),
      resources: form.outcomes.split("\n").filter(Boolean).join(", "),
    };
    if (editItem) {
      updateRoadmapItem(editItem.id, data);
    } else {
      addRoadmapItem({ id: `rm_${Date.now()}`, ...data });
    }
    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Academic Roadmap</h1>
          <p className="text-gray-500 mt-1">
            Manage academic roadmaps by department
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
        >
          <Plus size={18} /> Add Roadmap Item
        </Button>
      </div>

      {/* Department Tabs */}
      <div className="flex flex-wrap gap-2">
        {DEPARTMENTS.map((dept) => (
          <Button
            key={dept}
            onClick={() => setActiveDept(dept)}
            variant={activeDept === dept ? "default" : "outline"}
            className={`rounded-xl ${activeDept === dept ? "bg-indigo-700 hover:bg-indigo-800 shadow-sm" : ""}`}
          >
            {dept}
          </Button>
        ))}
      </div>

      {/* Roadmap Items */}
      {deptItems.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <Map size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400">
            No roadmap items for this department yet.
          </p>
          <Button
            variant="link"
            onClick={openAdd}
            className="mt-3 text-indigo-700"
          >
            Add first item
          </Button>
        </div>
      ) : (
        <div className="relative">
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-indigo-100" />
          <div className="space-y-4">
            {deptItems.map((item, idx) => (
              <div key={item.id} className="relative flex gap-6 pl-14">
                {/* Dot */}
                <div className="absolute left-3 top-5 w-6 h-6 bg-indigo-700 rounded-full flex items-center justify-center text-white text-xs font-bold z-10 shadow-sm">
                  {item.semester}
                </div>
                {/* Card */}
                <Card
                  className={`flex-1 rounded-2xl ${deptColors[item.department] || "border-gray-200"}`}
                >
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge
                            variant="secondary"
                            className={`rounded-full ${deptBadge[item.department]}`}
                          >
                            Semester {item.semester}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-gray-900 mb-1">
                          {item.title}
                        </h3>
                        <p className="text-gray-500 text-sm mb-3">
                          {item.description}
                        </p>
                        <div className="grid sm:grid-cols-2 gap-3">
                          <div>
                            <p className="text-xs font-semibold text-gray-700 mb-1.5">
                              Courses
                            </p>
                            <div className="space-y-1">
                              {item.courses.map((c, ci) => (
                                <div
                                  key={ci}
                                  className="flex items-center gap-1.5 text-xs text-gray-600"
                                >
                                  <ChevronRight
                                    size={12}
                                    className="text-indigo-500 flex-shrink-0"
                                  />{" "}
                                  {c}
                                </div>
                              ))}
                            </div>
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-gray-700 mb-1.5">
                              Learning Outcomes
                            </p>
                            <div className="space-y-1">
                              {item.outcomes.map((o, oi) => (
                                <div
                                  key={oi}
                                  className="flex items-center gap-1.5 text-xs text-gray-600"
                                >
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0" />{" "}
                                  {o}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-1.5 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEdit(item)}
                          className="text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                        >
                          <Edit2 size={15} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteConfirm(item.id)}
                          className="text-gray-400 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 size={15} />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editItem ? "Edit Roadmap Item" : "Add Roadmap Item"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-gray-700">Department</Label>
                <select
                  value={form.department}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, department: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {DEPARTMENTS.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Semester</Label>
                <select
                  value={form.semester}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, semester: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={s}>
                      Semester {s}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Title *</Label>
                <Input
                  value={form.title}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, title: e.target.value }))
                  }
                  placeholder="e.g., Foundation Semester"
                  className="rounded-xl"
                />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Description</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, description: e.target.value }))
                  }
                  rows={2}
                  placeholder="Brief description of this semester..."
                  className="rounded-xl resize-none"
                />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Courses (one per line)</Label>
                <Textarea
                  value={form.courses}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, courses: e.target.value }))
                  }
                  rows={4}
                  placeholder="CS101 - Introduction to Programming&#10;MATH101 - Calculus I&#10;..."
                  className="rounded-xl resize-none font-mono"
                />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">
                  Learning Outcomes (one per line)
                </Label>
                <Textarea
                  value={form.outcomes}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, outcomes: e.target.value }))
                  }
                  rows={3}
                  placeholder="Basic programming proficiency&#10;Mathematical reasoning&#10;..."
                  className="rounded-xl resize-none"
                />
              </div>
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editItem ? "Save Changes" : "Add Item"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trash2 size={20} className="text-red-600" />
          </div>
          <DialogHeader>
            <DialogTitle>Delete Roadmap Item?</DialogTitle>
          </DialogHeader>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteRoadmapItem(deleteConfirm);
                setDeleteConfirm(null);
              }}
              className="flex-1 rounded-xl"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
