import { useMemo } from "react";
import { useData } from "../../context/DataContext";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
} from "recharts";
import {
  TrendingUp,
  Users,
  BookOpen,
  Award,
  GraduationCap,
  Activity,
} from "lucide-react";
import { Card, CardContent } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Progress } from "../../components/ui/progress";
import { CHART_COLORS as COLORS } from "../../constants/chartColors";

export default function AdminAnalytics() {
  const { users, courses, assignments, attendanceRecords, events } = useData();

  const students = useMemo(
    () => users.filter((u) => u.role === "student"),
    [users],
  );
  const teachers = useMemo(
    () => users.filter((u) => u.role === "teacher"),
    [users],
  );

  const deptData = useMemo(
    () => [
      {
        name: "Computer Science",
        students: students.filter((s) => s.department === "Computer Science")
          .length,
        courses: courses.filter((c) => c.department === "Computer Science")
          .length,
        color: "#4f46e5",
      },
      {
        name: "Mathematics",
        students: students.filter((s) => s.department === "Mathematics").length,
        courses: courses.filter((c) => c.department === "Mathematics").length,
        color: "#f59e0b",
      },
      {
        name: "Physics",
        students: students.filter((s) => s.department === "Physics").length,
        courses: courses.filter((c) => c.department === "Physics").length,
        color: "#8b5cf6",
      },
      {
        name: "Electronics",
        students: students.filter(
          (s) => s.department === "Electronics Engineering",
        ).length,
        courses: courses.filter(
          (c) => c.department === "Electronics Engineering",
        ).length,
        color: "#ef4444",
      },
      {
        name: "Business",
        students: students.filter(
          (s) => s.department === "Business Administration",
        ).length,
        courses: courses.filter(
          (c) => c.department === "Business Administration",
        ).length,
        color: "#10b981",
      },
    ],
    [students, courses],
  );

  const enrollmentTrend = useMemo(
    () => [
      { month: "Aug", students: 180, teachers: 12 },
      { month: "Sep", students: 240, teachers: 15 },
      { month: "Oct", students: 380, teachers: 18 },
      { month: "Nov", students: 420, teachers: 20 },
      { month: "Dec", students: 390, teachers: 21 },
      { month: "Jan", students: 450, teachers: 22 },
      { month: "Feb", students: students.length, teachers: teachers.length },
    ],
    [students, teachers],
  );

  const attendanceOverview = [
    { dept: "CS", rate: 87 },
    { dept: "Math", rate: 79 },
    { dept: "Physics", rate: 82 },
    { dept: "EECS", rate: 91 },
    { dept: "Business", rate: 74 },
  ];

  const submissionStats = useMemo(
    () =>
      assignments.map((a) => ({
        name: a.title.slice(0, 15) + "...",
        submitted: a.submissions.length,
        graded: a.submissions.filter((s) => s.status === "graded").length,
        pending: a.submissions.filter((s) => s.status === "submitted").length,
      })),
    [assignments],
  );

  const semesterDistribution = useMemo(() => {
    const now = new Date();
    const withSem = students.map((st) => {
      if (!st.joinDate) return { ...st, _semester: 1 };
      const joined = new Date(st.joinDate);
      const months =
        (now.getFullYear() - joined.getFullYear()) * 12 +
        (now.getMonth() - joined.getMonth());
      const sem = Math.min(Math.max(Math.ceil(months / 6), 1), 8);
      return { ...st, _semester: sem };
    });
    return [1, 2, 3, 4, 5, 6, 7, 8]
      .map((s) => ({
        semester: `Sem ${s}`,
        count: withSem.filter((st) => st._semester === s).length,
      }))
      .filter((x) => x.count > 0);
  }, [students]);

  const radarData = useMemo(
    () => [
      { subject: "Attendance", A: 82, fullMark: 100 },
      { subject: "Submissions", A: 74, fullMark: 100 },
      { subject: "Grading", A: 68, fullMark: 100 },
      { subject: "Events", A: events.length * 10, fullMark: 100 },
      { subject: "Courses", A: courses.length * 7, fullMark: 100 },
      { subject: "Faculty", A: teachers.length * 16, fullMark: 100 },
    ],
    [events, courses, teachers],
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">
          Analytics & Reports
        </h1>
        <p className="text-gray-500 mt-1">
          Comprehensive insights into university performance metrics
        </p>
      </div>

      {/* Quick KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: "Avg. Attendance Rate",
            value: "82.4%",
            change: "+3.2%",
            icon: <Activity size={20} />,
            color: "bg-indigo-600",
            up: true,
          },
          {
            label: "Assignment Submission",
            value: "74%",
            change: "+8.1%",
            icon: <BookOpen size={20} />,
            color: "bg-emerald-600",
            up: true,
          },
          {
            label: "Graduation Rate",
            value: "94.2%",
            change: "+1.8%",
            icon: <GraduationCap size={20} />,
            color: "bg-amber-500",
            up: true,
          },
          {
            label: "Student Satisfaction",
            value: "4.3/5",
            change: "+0.2",
            icon: <Award size={20} />,
            color: "bg-purple-600",
            up: true,
          },
        ].map((kpi) => (
          <Card key={kpi.label} className="rounded-2xl">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-10 h-10 ${kpi.color} rounded-xl flex items-center justify-center text-white`}
                >
                  {kpi.icon}
                </div>
                <Badge
                  variant="secondary"
                  className={`rounded-full ${kpi.up ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"}`}
                >
                  {kpi.change}
                </Badge>
              </div>
              <p className="text-gray-900 font-bold text-2xl">{kpi.value}</p>
              <p className="text-gray-400 text-xs mt-0.5">{kpi.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Enrollment Trend */}
        <Card className="lg:col-span-2 rounded-2xl">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900 font-semibold">
                Enrollment Trend (2024)
              </h3>
              <div className="flex items-center gap-4 text-xs">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-indigo-500" />
                  Students
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-emerald-500" />
                  Faculty
                </span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={enrollmentTrend}>
                <defs>
                  <linearGradient id="studentGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="teacherGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="students"
                  stroke="#4f46e5"
                  fill="url(#studentGrad)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="teachers"
                  stroke="#10b981"
                  fill="url(#teacherGrad)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* System Health Radar */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              System Health Score
            </h3>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                <Radar
                  name="Score"
                  dataKey="A"
                  stroke="#4f46e5"
                  fill="#4f46e5"
                  fillOpacity={0.3}
                />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Department Breakdown */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Department Overview
            </h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={deptData} barSize={20}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend iconType="circle" iconSize={8} />
                <Bar
                  dataKey="students"
                  name="Students"
                  fill="#4f46e5"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="courses"
                  name="Courses"
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Attendance by Department */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Attendance by Department (%)
            </h3>
            <div className="space-y-3">
              {attendanceOverview.map((d, i) => (
                <div key={d.dept}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-700 font-medium">
                      {d.dept}
                    </span>
                    <span
                      className={`text-sm font-bold ${d.rate >= 85 ? "text-emerald-600" : d.rate >= 75 ? "text-amber-600" : "text-red-500"}`}
                    >
                      {d.rate}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all"
                      style={{
                        width: `${d.rate}%`,
                        backgroundColor: COLORS[i],
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Assignment Stats */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Assignment Submission Status
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={submissionStats} barSize={16}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend iconType="circle" iconSize={8} />
                <Bar
                  dataKey="submitted"
                  name="Total Submitted"
                  fill="#4f46e5"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="graded"
                  name="Graded"
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="pending"
                  name="Pending"
                  fill="#f59e0b"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Semester Distribution */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Student Semester Distribution
            </h3>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={semesterDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="count"
                    nameKey="semester"
                    paddingAngle={4}
                  >
                    {semesterDistribution.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend
                    iconType="circle"
                    iconSize={8}
                    formatter={(v) => <span className="text-xs">{v}</span>}
                  />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Key Insights */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            title: "Top Performing Dept",
            value: "Electronics",
            subtitle: "91% attendance rate",
            icon: "🏆",
            color: "from-amber-500 to-amber-600",
          },
          {
            title: "Most Active Course",
            value: "MATH101",
            subtitle: "94 lecture views avg",
            icon: "📚",
            color: "from-indigo-500 to-indigo-600",
          },
          {
            title: "Highest Submission",
            value: "CS101",
            subtitle: "100% submission rate",
            icon: "✅",
            color: "from-emerald-500 to-emerald-600",
          },
          {
            title: "Events This Sem",
            value: `${events.length}`,
            subtitle: `${events.filter((e) => e.registrationOpen).length} open for registration`,
            icon: "🎉",
            color: "from-purple-500 to-purple-600",
          },
        ].map((card) => (
          <div
            key={card.title}
            className={`bg-gradient-to-br ${card.color} rounded-2xl p-5 text-white`}
          >
            <p className="text-3xl mb-2">{card.icon}</p>
            <p className="text-white/70 text-xs font-medium uppercase tracking-wide">
              {card.title}
            </p>
            <p className="font-bold text-xl mt-1">{card.value}</p>
            <p className="text-white/70 text-xs mt-1">{card.subtitle}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
