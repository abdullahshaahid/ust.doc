import { useMemo } from "react";
import { useData } from "../../context/DataContext";
import { StatsCard } from "../../components/shared/StatsCard";
import { useNavigate } from "react-router";
import {
  Users,
  BookOpen,
  Calendar,
  GraduationCap,
  TrendingUp,
  Award,
  ArrowRight,
  Megaphone,
  AlertTriangle,
  BarChart2,
  Plus,
  Clock,
  CheckCircle,
  UserCheck,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from "recharts";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { CHART_COLORS as COLORS } from "../../constants/chartColors";

export default function AdminDashboard() {
  const {
    users,
    courses,
    events,
    assignments,
    announcements,
    attendanceRecords,
  } = useData();
  const navigate = useNavigate();

  const students = useMemo(
    () => users.filter((u) => u.role === "student"),
    [users],
  );
  const teachers = useMemo(
    () => users.filter((u) => u.role === "teacher"),
    [users],
  );

  const deptData = useMemo(
    () => [
      {
        name: "CS",
        students: students.filter((s) => s.department === "Computer Science")
          .length,
        color: "#4f46e5",
      },
      {
        name: "Math",
        students: students.filter((s) => s.department === "Mathematics").length,
        color: "#f59e0b",
      },
      {
        name: "Physics",
        students: students.filter((s) => s.department === "Physics").length,
        color: "#8b5cf6",
      },
      {
        name: "Electronics",
        students: students.filter(
          (s) => s.department === "Electronics Engineering",
        ).length,
        color: "#ef4444",
      },
      {
        name: "Business",
        students: students.filter(
          (s) => s.department === "Business Administration",
        ).length,
        color: "#10b981",
      },
    ],
    [students],
  );

  const coursesByDept = useMemo(
    () => [
      {
        name: "CS",
        value: courses.filter((c) => c.department === "Computer Science")
          .length,
      },
      {
        name: "Math",
        value: courses.filter((c) => c.department === "Mathematics").length,
      },
      {
        name: "Physics",
        value: courses.filter((c) => c.department === "Physics").length,
      },
      {
        name: "Electronics",
        value: courses.filter((c) => c.department === "Electronics Engineering")
          .length,
      },
      {
        name: "Business",
        value: courses.filter((c) => c.department === "Business Administration")
          .length,
      },
    ],
    [courses],
  );

  const { monthlyActivity, totalSubmissions, pendingGrades } = useMemo(() => {
    const totalSub = assignments.reduce(
      (a, b) => a + (b.submissions || []).length,
      0,
    );
    const pending = assignments.reduce(
      (a, b) =>
        a +
        (b.submissions || []).filter((s) => s.status === "submitted").length,
      0,
    );
    const monthly = [
      { month: "Oct", logins: 1200, submissions: 430 },
      { month: "Nov", logins: 1500, submissions: 610 },
      { month: "Dec", logins: 1100, submissions: 290 },
      { month: "Jan", logins: 1800, submissions: 720 },
      { month: "Feb", logins: 2100, submissions: 890 },
      { month: "Mar", logins: users.length * 40, submissions: totalSub * 5 },
    ];
    return {
      monthlyActivity: monthly,
      totalSubmissions: totalSub,
      pendingGrades: pending,
    };
  }, [users, assignments]);

  const recentEvents = useMemo(
    () =>
      [...events]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 4),
    [events],
  );
  const recentUsers = useMemo(
    () =>
      [...users]
        .sort(
          (a, b) =>
            new Date(b.joinDate || "").getTime() -
            new Date(a.joinDate || "").getTime(),
        )
        .slice(0, 6),
    [users],
  );
  const activeAnnouncements = useMemo(
    () => announcements.filter((a) => a.isActive).slice(0, 3),
    [announcements],
  );

  const quickActions = [
    {
      label: "Add User",
      icon: <Plus size={16} />,
      path: "/admin/users",
      color: "bg-indigo-600 hover:bg-indigo-700",
    },
    {
      label: "Add Course",
      icon: <BookOpen size={16} />,
      path: "/admin/courses",
      color: "bg-emerald-600 hover:bg-emerald-700",
    },
    {
      label: "Add Event",
      icon: <Calendar size={16} />,
      path: "/admin/events",
      color: "bg-amber-500 hover:bg-amber-600",
    },
    {
      label: "Analytics",
      icon: <BarChart2 size={16} />,
      path: "/admin/analytics",
      color: "bg-purple-600 hover:bg-purple-700",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Admin Dashboard</h1>
          <p className="text-gray-500 mt-1">
            Overview of UniLearn Learning Management System
          </p>
        </div>
        <div className="flex gap-2">
          {quickActions.map((a) => (
            <Button
              key={a.label}
              onClick={() => navigate(a.path)}
              size="sm"
              className={`${a.color} text-white rounded-xl shadow-sm`}
            >
              {a.icon} {a.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Students"
          value={students.length}
          icon={<GraduationCap size={22} className="text-white" />}
          color="bg-indigo-600"
          subtitle="Active enrollments"
          trend={{ value: 12, label: "from last year" }}
        />
        <StatsCard
          title="Faculty Members"
          value={teachers.length}
          icon={<Users size={22} className="text-white" />}
          color="bg-emerald-600"
          subtitle="Active teachers"
          trend={{ value: 5, label: "new this year" }}
        />
        <StatsCard
          title="Active Courses"
          value={courses.length}
          icon={<BookOpen size={22} className="text-white" />}
          color="bg-amber-500"
          subtitle="All departments"
        />
        <StatsCard
          title="Upcoming Events"
          value={events.filter((e) => new Date(e.date) >= new Date()).length}
          icon={<Calendar size={22} className="text-white" />}
          color="bg-purple-600"
          subtitle="This semester"
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: "Total Submissions",
            value: totalSubmissions,
            icon: <CheckCircle size={18} />,
            color: "text-indigo-600 bg-indigo-50 border-indigo-100",
          },
          {
            label: "Pending Grades",
            value: pendingGrades,
            icon: <Clock size={18} />,
            color:
              pendingGrades > 0
                ? "text-amber-600 bg-amber-50 border-amber-100"
                : "text-gray-400 bg-gray-50 border-gray-100",
          },
          {
            label: "Active Announcements",
            value: announcements.filter((a) => a.isActive).length,
            icon: <Megaphone size={18} />,
            color: "text-purple-600 bg-purple-50 border-purple-100",
          },
          {
            label: "Attendance Records",
            value: attendanceRecords.length,
            icon: <UserCheck size={18} />,
            color: "text-emerald-600 bg-emerald-50 border-emerald-100",
          },
        ].map((s) => (
          <div
            key={s.label}
            className={`flex items-center gap-3 p-4 rounded-2xl border ${s.color}`}
          >
            <div className="flex-shrink-0">{s.icon}</div>
            <div>
              <p className="font-bold text-xl text-gray-900">{s.value}</p>
              <p className="text-xs opacity-70">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Area Chart: Monthly Activity */}
        <Card className="lg:col-span-2 rounded-2xl shadow-sm border-gray-100">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900 font-semibold">
                Platform Activity (Monthly)
              </h3>
              <div className="flex items-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-indigo-500 rounded" />
                  Logins
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 bg-emerald-500 rounded" />
                  Submissions
                </span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={monthlyActivity}>
                <defs>
                  <linearGradient id="loginGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="subGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="logins"
                  stroke="#4f46e5"
                  fill="url(#loginGrad)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="submissions"
                  stroke="#10b981"
                  fill="url(#subGrad)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie Chart */}
        <Card className="rounded-2xl shadow-sm border-gray-100">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Courses by Department
            </h3>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie
                  data={coursesByDept}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  dataKey="value"
                  paddingAngle={4}
                >
                  {coursesByDept.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 mt-2">
              {coursesByDept.map((d, i) => (
                <div
                  key={d.name}
                  className="flex items-center justify-between text-xs"
                >
                  <span className="flex items-center gap-1.5">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: COLORS[i] }}
                    />
                    {d.name}
                  </span>
                  <span className="font-medium text-gray-700">
                    {d.value} courses
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Students by Dept */}
        <Card className="rounded-2xl shadow-sm border-gray-100">
          <CardContent className="p-5">
            <h3 className="text-gray-900 font-semibold mb-4">
              Students by Department
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={deptData} barSize={28} layout="vertical">
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#f0f0f0"
                  horizontal={false}
                />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis
                  dataKey="name"
                  type="category"
                  tick={{ fontSize: 11 }}
                  width={55}
                />
                <Tooltip />
                <Bar dataKey="students" radius={[0, 6, 6, 0]}>
                  {deptData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Users */}
        <Card className="rounded-2xl shadow-sm border-gray-100">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-gray-900 font-semibold">Recently Joined</h3>
              <Button
                variant="link"
                onClick={() => navigate("/admin/users")}
                className="text-indigo-700 text-xs p-0 h-auto"
              >
                View all <ArrowRight size={12} />
              </Button>
            </div>
            <div className="space-y-2.5">
              {recentUsers.map((user) => {
                const roleColors = {
                  admin: "bg-red-100 text-red-700",
                  teacher: "bg-emerald-100 text-emerald-700",
                  student: "bg-indigo-100 text-indigo-700",
                };
                const avatarColors = {
                  admin: "bg-red-600",
                  teacher: "bg-emerald-600",
                  student: "bg-indigo-600",
                };
                return (
                  <div key={user.id} className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 ${avatarColors[user.role]} rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}
                    >
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase()
                        .slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-gray-900 text-sm truncate font-medium">
                        {user.name}
                      </p>
                      <p className="text-gray-400 text-xs">
                        {user.department || "Administration"}
                      </p>
                    </div>
                    <Badge
                      variant="secondary"
                      className={`rounded-full capitalize ${roleColors[user.role] || "bg-gray-100 text-gray-700"}`}
                    >
                      {user.role}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Events & Announcements */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-900 font-semibold text-sm">
                Upcoming Events
              </h3>
              <Button
                variant="link"
                onClick={() => navigate("/admin/events")}
                className="text-indigo-700 text-xs hover:underline h-auto p-0"
              >
                View all
              </Button>
            </div>
            <div className="space-y-2">
              {recentEvents.slice(0, 3).map((event) => {
                const typeColors = {
                  academic: "bg-blue-100 text-blue-700",
                  sports: "bg-green-100 text-green-700",
                  trip: "bg-orange-100 text-orange-700",
                  cultural: "bg-pink-100 text-pink-700",
                  workshop: "bg-purple-100 text-purple-700",
                  seminar: "bg-indigo-100 text-indigo-700",
                  competition: "bg-red-100 text-red-700",
                  fest: "bg-amber-100 text-amber-700",
                };
                return (
                  <div
                    key={event.id}
                    className="flex items-center gap-2 p-2.5 bg-gray-50 rounded-xl"
                  >
                    <img
                      src={event.image}
                      alt={event.title}
                      className="w-10 h-10 rounded-lg object-cover flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-gray-900 text-xs font-medium truncate">
                        {event.title}
                      </p>
                      <p className="text-gray-400 text-xs">
                        {new Date(event.date).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-xs capitalize ${typeColors[event.type] || "bg-gray-100 text-gray-600"}`}
                    >
                      {event.type}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Announcements */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-900 font-semibold text-sm flex items-center gap-2">
                <Megaphone size={14} className="text-indigo-600" />{" "}
                Announcements
              </h3>
              <Button
                variant="link"
                onClick={() => navigate("/admin/announcements")}
                className="text-indigo-700 text-xs hover:underline h-auto p-0"
              >
                Manage
              </Button>
            </div>
            <div className="space-y-2">
              {activeAnnouncements.map((ann) => {
                const colors = {
                  high: "bg-red-50 border-red-200 text-red-700",
                  medium: "bg-amber-50 border-amber-200 text-amber-700",
                  low: "bg-blue-50 border-blue-200 text-blue-700",
                };
                return (
                  <div
                    key={ann.id}
                    className={`p-2.5 rounded-xl border text-xs ${colors[ann.priority]}`}
                  >
                    <p className="font-medium truncate">{ann.title}</p>
                    <p className="opacity-70 mt-0.5">
                      For: {ann.targetRole} · {ann.priority} priority
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* System Overview Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-indigo-800 to-indigo-900 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-xl">System Health Overview</h3>
            <p className="text-indigo-200 text-sm mt-1">
              All systems operational — UniLearn LMS v2026.1
            </p>
          </div>
          <div className="flex items-center gap-8 flex-wrap">
            {[
              { value: (users || []).length, label: "Total Users" },
              {
                value: (assignments || []).reduce(
                  (a, b) => a + (b.submissions || []).length,
                  0,
                ),
                label: "Total Submissions",
              },
              { value: (courses || []).length, label: "Active Courses" },
              { value: "99.9%", label: "System Uptime" },
              {
                value: (announcements || []).filter((a) => a.isActive).length,
                label: "Active Alerts",
              },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className="font-bold text-2xl">{s.value}</p>
                <p className="text-indigo-200 text-xs">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
