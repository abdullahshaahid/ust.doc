import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  Plus,
  Edit2,
  Trash2,
  X,
  Megaphone,
  Bell,
  AlertTriangle,
  Info,
  CheckCircle,
  Search,
  Filter,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card, CardContent } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import { Textarea } from "../../components/ui/textarea";
import { Switch } from "../../components/ui/switch";

const priorityConfig = {
  high: {
    color: "bg-red-100 text-red-700 border-red-200",
    icon: <AlertTriangle size={14} />,
    dot: "bg-red-500",
  },
  medium: {
    color: "bg-amber-100 text-amber-700 border-amber-200",
    icon: <Bell size={14} />,
    dot: "bg-amber-500",
  },
  low: {
    color: "bg-blue-100 text-blue-700 border-blue-200",
    icon: <Info size={14} />,
    dot: "bg-blue-500",
  },
};

const targetConfig = {
  all: "bg-purple-100 text-purple-700",
  student: "bg-indigo-100 text-indigo-700",
  teacher: "bg-emerald-100 text-emerald-700",
};

const emptyForm = {
  title: "",
  content: "",
  targetRole: "all",
  priority: "medium",
  isActive: true,
};

export default function ManageAnnouncements() {
  const { currentUser } = useAuth();
  const {
    announcements,
    addAnnouncement,
    updateAnnouncement,
    deleteAnnouncement,
  } = useData();
  const [search, setSearch] = useState("");
  const [filterPriority, setFilterPriority] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [editAnn, setEditAnn] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const filtered = announcements
    .filter((a) => {
      const matchSearch =
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.content.toLowerCase().includes(search.toLowerCase());
      const matchPriority =
        filterPriority === "all" || a.priority === filterPriority;
      return matchSearch && matchPriority;
    })
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );

  const openAdd = () => {
    setForm(emptyForm);
    setEditAnn(null);
    setShowModal(true);
  };
  const openEdit = (ann) => {
    setForm({
      title: ann.title,
      content: ann.content,
      targetRole: ann.targetRole,
      priority: ann.priority,
      isActive: ann.isActive,
    });
    setEditAnn(ann);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.title || !form.content) return;
    if (editAnn) {
      updateAnnouncement(editAnn.id, form);
    } else {
      addAnnouncement({
        id: `ann_${Date.now()}`,
        ...form,
        createdAt: new Date().toISOString().split("T")[0],
        createdBy: currentUser?.id || "admin1",
      });
    }
    setShowModal(false);
  };

  const stats = {
    total: announcements.length,
    high: announcements.filter((a) => a.priority === "high").length,
    active: announcements.filter((a) => a.isActive).length,
    students: announcements.filter(
      (a) => a.targetRole === "student" || a.targetRole === "all",
    ).length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Announcements</h1>
          <p className="text-gray-500 mt-1">
            Create and manage announcements for students and teachers
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl shadow-sm"
        >
          <Plus size={18} /> New Announcement
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          {
            label: "Total",
            value: stats.total,
            icon: <Megaphone size={16} />,
            color: "bg-indigo-50 text-indigo-600 border-indigo-100",
          },
          {
            label: "High Priority",
            value: stats.high,
            icon: <AlertTriangle size={16} />,
            color: "bg-red-50 text-red-600 border-red-100",
          },
          {
            label: "Active",
            value: stats.active,
            icon: <CheckCircle size={16} />,
            color: "bg-emerald-50 text-emerald-600 border-emerald-100",
          },
          {
            label: "For Students",
            value: stats.students,
            icon: <Bell size={16} />,
            color: "bg-amber-50 text-amber-600 border-amber-100",
          },
        ].map((s) => (
          <div
            key={s.label}
            className={`rounded-xl p-4 border flex items-center gap-3 ${s.color}`}
          >
            {s.icon}
            <div>
              <p className="font-bold text-xl">{s.value}</p>
              <p className="text-xs opacity-70">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search announcements..."
            className="pl-9 rounded-xl bg-gray-50"
          />
        </div>
        <div className="flex gap-2">
          {["all", "high", "medium", "low"].map((p) => (
            <Button
              key={p}
              onClick={() => setFilterPriority(p)}
              variant={filterPriority === p ? "default" : "secondary"}
              className={`rounded-xl capitalize ${filterPriority === p ? "bg-indigo-700 hover:bg-indigo-800" : ""}`}
            >
              {p}
            </Button>
          ))}
        </div>
      </div>

      {/* Announcement Cards */}
      <div className="space-y-3">
        {filtered.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
            <Megaphone size={32} className="text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400">No announcements found</p>
          </div>
        )}
        {filtered.map((ann) => {
          const pc = priorityConfig[ann.priority];
          return (
            <Card
              key={ann.id}
              className="rounded-2xl hover:shadow-md transition-shadow"
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${pc.dot}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1.5">
                        <h3 className="font-semibold text-gray-900">
                          {ann.title}
                        </h3>
                        <Badge
                          variant="outline"
                          className={`rounded-full ${pc.color}`}
                        >
                          {pc.icon} {ann.priority}
                        </Badge>
                        <Badge
                          variant="secondary"
                          className={`rounded-full capitalize ${targetConfig[ann.targetRole]}`}
                        >
                          For: {ann.targetRole}
                        </Badge>
                        {!ann.isActive && (
                          <Badge
                            variant="secondary"
                            className="rounded-full bg-gray-100 text-gray-500"
                          >
                            Inactive
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        {ann.content}
                      </p>
                      <p className="text-gray-400 text-xs mt-2">
                        {new Date(ann.createdAt).toLocaleDateString("en-US", {
                          weekday: "short",
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEdit(ann)}
                      className="text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                    >
                      <Edit2 size={15} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteConfirm(ann.id)}
                      className="text-gray-400 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 size={15} />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Megaphone size={20} className="text-indigo-600" />
              {editAnn ? "Edit Announcement" : "New Announcement"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-gray-700">Title *</Label>
              <Input
                value={form.title}
                onChange={(e) =>
                  setForm((f) => ({ ...f, title: e.target.value }))
                }
                placeholder="Announcement title..."
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-700">Content *</Label>
              <Textarea
                value={form.content}
                onChange={(e) =>
                  setForm((f) => ({ ...f, content: e.target.value }))
                }
                rows={4}
                placeholder="Write the announcement details..."
                className="rounded-xl resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-gray-700">Target Audience</Label>
                <select
                  value={form.targetRole}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, targetRole: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  <option value="all">Everyone</option>
                  <option value="student">Students Only</option>
                  <option value="teacher">Teachers Only</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Priority</Label>
                <select
                  value={form.priority}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, priority: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={form.isActive}
                onCheckedChange={(checked) =>
                  setForm((f) => ({ ...f, isActive: checked }))
                }
              />
              <span className="text-sm text-gray-600">
                Active (visible to users)
              </span>
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editAnn ? "Save Changes" : "Publish"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trash2 size={20} className="text-red-600" />
          </div>
          <DialogHeader>
            <DialogTitle>Delete Announcement?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-500 text-sm mb-2">
            This action cannot be undone.
          </p>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteAnnouncement(deleteConfirm);
                setDeleteConfirm(null);
              }}
              className="flex-1 rounded-xl"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
