import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import { Plus, Edit2, Trash2, X, Calendar, MapPin, Image } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card, CardContent } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import { Textarea } from "../../components/ui/textarea";

const EVENT_TYPES = [
  "academic",
  "sports",
  "trip",
  "cultural",
  "workshop",
  "seminar",
  "competition",
  "fest",
];
const typeColors = {
  academic: "bg-blue-100 text-blue-700",
  sports: "bg-green-100 text-green-700",
  trip: "bg-orange-100 text-orange-700",
  cultural: "bg-pink-100 text-pink-700",
  workshop: "bg-purple-100 text-purple-700",
  seminar: "bg-indigo-100 text-indigo-700",
  competition: "bg-red-100 text-red-700",
  fest: "bg-amber-100 text-amber-700",
};

const emptyForm = {
  title: "",
  description: "",
  date: "",
  type: "academic",
  image: "",
  location: "",
  organizer: "",
  registrationOpen: true,
};

export default function ManageEvents() {
  const { events, addEvent, updateEvent, deleteEvent } = useData();
  const { currentUser } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [editEvent, setEditEvent] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const openAdd = () => {
    setForm(emptyForm);
    setEditEvent(null);
    setShowModal(true);
  };
  const openEdit = (e) => {
    setForm({
      title: e.title,
      description: e.description,
      date: e.date,
      type: e.type,
      image: e.image,
      location: e.location,
      organizer: e.organizer,
      registrationOpen: e.registrationOpen ?? true,
    });
    setEditEvent(e);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.title || !form.date) return;
    const imageUrl =
      form.image ||
      "https://images.unsplash.com/photo-1766476210492-824c8a4b79b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600";
    if (editEvent) {
      updateEvent(editEvent.id, {
        ...form,
        image: imageUrl,
      });
    } else {
      addEvent({
        id: `evt_${Date.now()}`,
        ...form,
        image: imageUrl,
        createdBy: currentUser?.id || "admin1",
      });
    }
    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Manage Events</h1>
          <p className="text-gray-500 mt-1">
            Create and manage university events
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
        >
          <Plus size={18} /> Add Event
        </Button>
      </div>

      {/* Event Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {events.map((event) => (
          <Card key={event.id} className="rounded-2xl overflow-hidden">
            <div className="relative h-44 overflow-hidden">
              <img
                src={event.image}
                alt={event.title}
                className="w-full h-full object-cover"
              />
              <Badge
                className={`absolute top-3 left-3 rounded-full capitalize ${typeColors[event.type] || "bg-gray-100 text-gray-700"}`}
              >
                {event.type}
              </Badge>
              <div className="absolute top-3 right-3 flex gap-1.5">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => openEdit(event)}
                  className="h-7 w-7 bg-white/90 backdrop-blur hover:bg-white shadow-sm"
                >
                  <Edit2 size={13} className="text-indigo-700" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setDeleteConfirm(event.id)}
                  className="h-7 w-7 bg-white/90 backdrop-blur hover:bg-white shadow-sm"
                >
                  <Trash2 size={13} className="text-red-600" />
                </Button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1">
                {event.title}
              </h3>
              <p className="text-gray-500 text-sm line-clamp-2 mb-3">
                {event.description}
              </p>
              <div className="flex items-center gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <Calendar size={11} />{" "}
                  {new Date(event.date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin size={11} /> {event.location}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                By: {event.organizer}
              </p>
            </div>
          </Card>
        ))}
      </div>

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editEvent ? "Edit Event" : "Add New Event"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-gray-700">Event Title *</Label>
              <Input
                value={form.title}
                onChange={(e) =>
                  setForm((f) => ({ ...f, title: e.target.value }))
                }
                placeholder="Event title"
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-700">Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) =>
                  setForm((f) => ({ ...f, description: e.target.value }))
                }
                rows={3}
                placeholder="Event description..."
                className="rounded-xl resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-gray-700">Date *</Label>
                <Input
                  type="date"
                  value={form.date}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, date: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Type</Label>
                <select
                  value={form.type}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, type: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {EVENT_TYPES.map((t) => (
                    <option key={t} value={t} className="capitalize">
                      {t.charAt(0).toUpperCase() + t.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-700">Location</Label>
              <Input
                value={form.location}
                onChange={(e) =>
                  setForm((f) => ({ ...f, location: e.target.value }))
                }
                placeholder="Event venue/location"
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-700">Organizer</Label>
              <Input
                value={form.organizer}
                onChange={(e) =>
                  setForm((f) => ({ ...f, organizer: e.target.value }))
                }
                placeholder="Organizing department/committee"
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-gray-700">Image URL</Label>
              <Input
                value={form.image}
                onChange={(e) =>
                  setForm((f) => ({ ...f, image: e.target.value }))
                }
                placeholder="https://... (leave blank for default)"
                className="rounded-xl"
              />
              {form.image && (
                <img
                  src={form.image}
                  className="mt-2 h-24 w-full object-cover rounded-xl"
                  onError={(e) => (e.currentTarget.style.display = "none")}
                />
              )}
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editEvent ? "Save Changes" : "Add Event"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trash2 size={20} className="text-red-600" />
          </div>
          <DialogHeader>
            <DialogTitle>Delete Event?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-500 text-sm mb-2">
            This will remove the event permanently.
          </p>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                deleteEvent(deleteConfirm);
                setDeleteConfirm(null);
              }}
              className="flex-1 rounded-xl"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
