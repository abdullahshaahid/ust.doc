import { useState } from "react";
import { useData } from "../../context/DataContext";
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  User,
  Mail,
  Phone,
  Building,
  GraduationCap,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../components/ui/table";

const DEPARTMENTS = [
  "Computer Science",
  "Mathematics",
  "Physics",
  "Business Administration",
];
const ROLES = ["student", "teacher"];

const emptyForm = {
  name: "",
  email: "",
  password: "",
  role: "student",
  department: "Computer Science",
  phone: "",
  semester: "1",
};

export default function ManageUsers() {
  const { users, addUser, updateUser, deleteUser } = useData();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const filtered = users.filter((u) => {
    if (u.role === "admin") return false;
    const matchSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === "all" || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  const openAdd = () => {
    setForm(emptyForm);
    setEditUser(null);
    setShowModal(true);
  };
  const openEdit = (user) => {
    setForm({
      name: user.name,
      email: user.email,
      password: user.password,
      role: user.role,
      department: user.department || "Computer Science",
      phone: user.phone || "",
      semester: String(user.semester || 1),
    });
    setEditUser(user);
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.name || !form.email || !form.password) return;
    if (editUser) {
      updateUser(editUser.id, {
        name: form.name,
        email: form.email,
        department: form.department,
        phone: form.phone,
      });
    } else {
      const id = `${form.role}_${Date.now()}`;
      const idCode =
        form.role === "student"
          ? `STU-${Date.now().toString().slice(-6)}`
          : `TCH-${Date.now().toString().slice(-6)}`;
      addUser({
        id,
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
        department: form.department,
        phone: form.phone,
        teacherId: form.role === "teacher" ? idCode : undefined,
        joinDate: new Date().toISOString().split("T")[0],
      });
    }
    setShowModal(false);
  };

  const handleDelete = (id) => {
    deleteUser(id);
    setDeleteConfirm(null);
  };

  const roleColors = {
    student: "bg-indigo-100 text-indigo-700",
    teacher: "bg-emerald-100 text-emerald-700",
  };
  const avatarColors = {
    student: "bg-indigo-600",
    teacher: "bg-emerald-600",
    admin: "bg-red-600",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-gray-900 font-bold text-2xl">Manage Users</h1>
          <p className="text-gray-500 mt-1">
            Add, edit, or remove students and teachers
          </p>
        </div>
        <Button
          onClick={openAdd}
          className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl shadow-sm"
        >
          <Plus size={18} /> Add New User
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
          />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email..."
            className="pl-9 rounded-xl bg-gray-50"
          />
        </div>
        <div className="flex gap-2">
          {["all", "student", "teacher"].map((r) => (
            <Button
              key={r}
              onClick={() => setRoleFilter(r)}
              variant={roleFilter === r ? "default" : "secondary"}
              className={`rounded-xl capitalize ${roleFilter === r ? "bg-indigo-700 hover:bg-indigo-800" : ""}`}
            >
              {r === "all"
                ? `All (${users.filter((u) => u.role !== "admin").length})`
                : `${r}s (${users.filter((u) => u.role === r).length})`}
            </Button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b border-gray-100">
                <TableHead className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  User
                </TableHead>
                <TableHead className="text-xs font-semibold text-gray-500 uppercase tracking-wider hidden sm:table-cell">
                  Email
                </TableHead>
                <TableHead className="text-xs font-semibold text-gray-500 uppercase tracking-wider hidden md:table-cell">
                  Department
                </TableHead>
                <TableHead className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Role
                </TableHead>
                <TableHead className="text-xs font-semibold text-gray-500 uppercase tracking-wider hidden lg:table-cell">
                  ID
                </TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  Actions
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="text-center py-12 text-gray-400"
                  >
                    No users found
                  </TableCell>
                </TableRow>
              )}
              {filtered.map((user) => (
                <TableRow key={user.id} className="hover:bg-gray-50">
                  <TableCell className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 ${avatarColors[user.role] || "bg-gray-500"} rounded-full flex items-center justify-center text-white font-medium text-sm flex-shrink-0`}
                      >
                        {user.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()
                          .slice(0, 2)}
                      </div>
                      <p className="font-medium text-gray-900 text-sm">
                        {user.name}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell className="px-5 py-4 text-gray-500 text-sm hidden sm:table-cell">
                    {user.email}
                  </TableCell>
                  <TableCell className="px-5 py-4 text-gray-500 text-sm hidden md:table-cell">
                    {user.department || "—"}
                  </TableCell>
                  <TableCell className="px-5 py-4">
                    <Badge
                      variant="secondary"
                      className={`rounded-full capitalize ${roleColors[user.role] || "bg-gray-100 text-gray-700"}`}
                    >
                      {user.role}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-5 py-4 text-gray-400 text-xs font-mono hidden lg:table-cell">
                    {user.studentId || user.teacherId || "—"}
                  </TableCell>
                  <TableCell className="px-5 py-4">
                    <div className="flex items-center gap-2 justify-end">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(user)}
                        className="text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                      >
                        <Edit2 size={15} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteConfirm(user.id)}
                        className="text-gray-400 hover:text-red-600 hover:bg-red-50"
                      >
                        <Trash2 size={15} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="rounded-2xl max-w-lg">
          <DialogHeader>
            <DialogTitle>{editUser ? "Edit User" : "Add New User"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Full Name *</Label>
                <Input
                  value={form.name}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, name: e.target.value }))
                  }
                  placeholder="Enter full name"
                  className="rounded-xl"
                />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Email *</Label>
                <Input
                  type="email"
                  value={form.email}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, email: e.target.value }))
                  }
                  placeholder="email@university.edu"
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Password *</Label>
                <Input
                  type="password"
                  value={form.password}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, password: e.target.value }))
                  }
                  placeholder="Password"
                  className="rounded-xl"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Role *</Label>
                <select
                  value={form.role}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, role: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r} className="capitalize">
                      {r.charAt(0).toUpperCase() + r.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-gray-700">Department</Label>
                <select
                  value={form.department}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, department: e.target.value }))
                  }
                  className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                >
                  {DEPARTMENTS.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-gray-700">Phone</Label>
                <Input
                  value={form.phone}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, phone: e.target.value }))
                  }
                  placeholder="+1-555-0000"
                  className="rounded-xl"
                />
              </div>
              {form.role === "student" && (
                <div className="space-y-1.5">
                  <Label className="text-gray-700">Semester</Label>
                  <select
                    value={form.semester}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, semester: e.target.value }))
                    }
                    className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                      <option key={s} value={s}>
                        Semester {s}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
            >
              {editUser ? "Save Changes" : "Create User"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog
        open={!!deleteConfirm}
        onOpenChange={() => setDeleteConfirm(null)}
      >
        <DialogContent className="rounded-2xl max-w-sm text-center">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trash2 size={20} className="text-red-600" />
          </div>
          <DialogHeader>
            <DialogTitle>Delete User?</DialogTitle>
          </DialogHeader>
          <p className="text-gray-500 text-sm mb-2">
            This action cannot be undone.
          </p>
          <DialogFooter className="flex gap-3 sm:gap-3">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirm(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleDelete(deleteConfirm)}
              className="flex-1 rounded-xl"
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
