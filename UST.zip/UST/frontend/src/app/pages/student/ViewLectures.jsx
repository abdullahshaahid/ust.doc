import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  BookOpen,
  FileText,
  Video,
  Link2,
  Search,
  Download,
  ExternalLink,
} from "lucide-react";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";

const typeIcons = {
  pdf: <FileText size={20} className="text-red-500" />,
  video: <Video size={20} className="text-blue-500" />,
  slides: <FileText size={20} className="text-amber-500" />,
  link: <Link2 size={20} className="text-emerald-500" />,
  document: <FileText size={20} className="text-purple-500" />,
};
const typeBadge = {
  pdf: "bg-red-100 text-red-700",
  video: "bg-blue-100 text-blue-700",
  slides: "bg-amber-100 text-amber-700",
  link: "bg-emerald-100 text-emerald-700",
  document: "bg-purple-100 text-purple-700",
};

export default function ViewLectures() {
  const { currentUser } = useAuth();
  const { courses, lectures, users } = useData();
  const [search, setSearch] = useState("");
  const [courseFilter, setCourseFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const enrichedUser = users.find((u) => u.id === currentUser?.id);
  const myCourseIds = enrichedUser?.enrolledCourses || [];
  const myCourses = courses.filter((c) => myCourseIds.includes(c.id));
  const myLectures = lectures.filter((l) => myCourseIds.includes(l.courseId));

  const filtered = myLectures.filter((l) => {
    const matchSearch =
      l.title.toLowerCase().includes(search.toLowerCase()) ||
      l.description.toLowerCase().includes(search.toLowerCase());
    const matchCourse = courseFilter === "all" || l.courseId === courseFilter;
    const matchType = typeFilter === "all" || l.type === typeFilter;
    return matchSearch && matchCourse && matchType;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">
          Lectures & Materials
        </h1>
        <p className="text-gray-500 mt-1">
          Access all course materials uploaded by your teachers
        </p>
      </div>

      {/* Filters */}
      <Card className="rounded-2xl p-4 shadow-sm border-gray-100">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search lectures..."
              className="pl-9 rounded-xl bg-gray-50"
            />
          </div>
          <select
            value={courseFilter}
            onChange={(e) => setCourseFilter(e.target.value)}
            className="px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
          >
            <option value="all">All Courses</option>
            {myCourses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.code}
              </option>
            ))}
          </select>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3.5 py-2.5 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
          >
            <option value="all">All Types</option>
            <option value="pdf">PDF</option>
            <option value="video">Video</option>
            <option value="slides">Slides</option>
            <option value="link">Link</option>
          </select>
        </div>
      </Card>

      {/* Lectures by Course */}
      {myCourses.map((course) => {
        const courseLectures = filtered.filter((l) => l.courseId === course.id);
        if (courseFilter !== "all" && courseFilter !== course.id) return null;
        return (
          <Card
            key={course.id}
            className="rounded-2xl shadow-sm border-gray-100 overflow-hidden"
          >
            <div className="flex items-center gap-3 px-5 py-4 bg-gradient-to-r from-indigo-50 to-white border-b border-gray-100">
              <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <BookOpen size={16} className="text-indigo-700" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">{course.name}</p>
                <p className="text-gray-400 text-xs">
                  {course.code} · {courseLectures.length} materials
                </p>
              </div>
            </div>
            {courseLectures.length === 0 ? (
              <div className="py-8 text-center text-gray-400 text-sm">
                No materials uploaded yet
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {courseLectures.map((lec, idx) => (
                  <div
                    key={lec.id}
                    className="flex items-center gap-4 px-5 py-4 hover:bg-gray-50 transition-colors group"
                  >
                    <span className="text-gray-300 text-sm w-5 flex-shrink-0">
                      {idx + 1}
                    </span>
                    <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-indigo-50 transition-colors">
                      {typeIcons[lec.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm group-hover:text-indigo-700 transition-colors">
                        {lec.title}
                      </p>
                      <p className="text-gray-400 text-xs">{lec.description}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge
                        className={`capitalize hidden sm:block rounded-full ${typeBadge[lec.type]}`}
                      >
                        {lec.type}
                      </Badge>
                      {lec.size && (
                        <span className="text-xs text-gray-400 hidden md:block">
                          {lec.size}
                        </span>
                      )}
                      <span className="text-xs text-gray-400 hidden md:block">
                        {new Date(lec.uploadedAt).toLocaleDateString("en-US", {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                      {lec.type === "link" ? (
                        <a
                          href={lec.url !== "#" ? lec.url : undefined}
                          className="p-2 text-gray-400 hover:text-indigo-700 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <ExternalLink size={15} />
                        </a>
                      ) : (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-gray-400 hover:text-indigo-700 hover:bg-indigo-50"
                        >
                          <Download size={15} />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        );
      })}

      {filtered.length === 0 && courseFilter === "all" && (
        <Card className="text-center py-16 rounded-2xl border-gray-100">
          <BookOpen size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400">
            No lectures found matching your search
          </p>
        </Card>
      )}
    </div>
  );
}
