import { useMemo } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import { StatsCard } from "../../components/shared/StatsCard";
import { useNavigate } from "react-router";
import {
  BookOpen,
  ClipboardList,
  UserCheck,
  Calculator,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  Megaphone,
  TrendingUp,
  Star,
  Calendar,
  Flame,
  Target,
  Bell,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Alert, AlertDescription } from "../../components/ui/alert";
import {
  RadialBarChart,
  RadialBar,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

export default function StudentDashboard() {
  const { currentUser } = useAuth();
  const {
    courses,
    lectures,
    assignments,
    attendanceRecords,
    announcements,
    users,
  } = useData();
  const navigate = useNavigate();

  const enrichedUser = useMemo(
    () => users.find((u) => u.id === currentUser?.id),
    [users, currentUser],
  );
  const myCourseIds = useMemo(
    () => enrichedUser?.enrolledCourses || [],
    [enrichedUser],
  );
  const myCourses = useMemo(
    () => courses.filter((c) => myCourseIds.includes(c.id)),
    [courses, myCourseIds],
  );
  const myLectures = useMemo(
    () => lectures.filter((l) => myCourseIds.includes(l.courseId)),
    [lectures, myCourseIds],
  );
  const myAssignments = useMemo(
    () => assignments.filter((a) => myCourseIds.includes(a.courseId)),
    [assignments, myCourseIds],
  );

  const { pendingAssignments, submittedCount, gradedCount } = useMemo(
    () => ({
      pendingAssignments: myAssignments.filter((a) => {
        const submitted = a.submissions.some(
          (s) => s.studentId === currentUser?.id,
        );
        return !submitted && new Date(a.dueDate) >= new Date();
      }),
      submittedCount: myAssignments.filter((a) =>
        a.submissions.some((s) => s.studentId === currentUser?.id),
      ).length,
      gradedCount: myAssignments.filter((a) =>
        a.submissions.some(
          (s) => s.studentId === currentUser?.id && s.status === "graded",
        ),
      ).length,
    }),
    [myAssignments, currentUser],
  );

  const { attendancePct, totalClasses, attended } = useMemo(() => {
    const myAtt = attendanceRecords.filter((r) =>
      myCourseIds.includes(r.courseId),
    );
    const total = myAtt.length;
    const att = myAtt.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status !== "absent",
      ),
    ).length;
    return {
      attendancePct: total > 0 ? Math.round((att / total) * 100) : 0,
      totalClasses: total,
      attended: att,
    };
  }, [attendanceRecords, myCourseIds, currentUser]);

  const upcomingDeadlines = useMemo(
    () =>
      myAssignments
        .filter(
          (a) =>
            !a.submissions.some((s) => s.studentId === currentUser?.id) &&
            new Date(a.dueDate) >= new Date(),
        )
        .sort(
          (a, b) =>
            new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime(),
        )
        .slice(0, 5),
    [myAssignments, currentUser],
  );

  const recentLectures = useMemo(
    () =>
      [...myLectures]
        .sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt))
        .slice(0, 5),
    [myLectures],
  );

  const myAnnouncements = useMemo(
    () =>
      announcements
        .filter(
          (a) =>
            a.isActive &&
            (a.targetRole === "all" || a.targetRole === "student"),
        )
        .slice(0, 3),
    [announcements],
  );

  const attendanceData = useMemo(
    () => [
      {
        name: "Attendance",
        value: attendancePct,
        fill: attendancePct >= 75 ? "#10b981" : "#ef4444",
      },
    ],
    [attendancePct],
  );

  const courseStats = useMemo(
    () =>
      myCourses.map((c) => {
        const courseAtt = attendanceRecords.filter((r) => r.courseId === c.id);
        const cAttended = courseAtt.filter((r) =>
          r.records.some(
            (rec) =>
              rec.studentId === currentUser?.id && rec.status !== "absent",
          ),
        ).length;
        const cPct =
          courseAtt.length > 0
            ? Math.round((cAttended / courseAtt.length) * 100)
            : 0;
        const courseAsgns = myAssignments.filter((a) => a.courseId === c.id);
        const submittedAsgns = courseAsgns.filter((a) =>
          a.submissions.some((s) => s.studentId === currentUser?.id),
        ).length;
        return {
          ...c,
          attendancePct: cPct,
          submittedAsgns,
          totalAsgns: courseAsgns.length,
        };
      }),
    [myCourses, attendanceRecords, myAssignments, currentUser],
  );

  const typeColors = {
    pdf: "bg-red-100 text-red-600 border-red-100",
    video: "bg-blue-100 text-blue-600 border-blue-100",
    slides: "bg-amber-100 text-amber-600 border-amber-100",
    link: "bg-emerald-100 text-emerald-600 border-emerald-100",
    document: "bg-purple-100 text-purple-600 border-purple-100",
  };

  const priorityColors = {
    high: "bg-red-50 border-red-200 text-red-700",
    medium: "bg-amber-50 border-amber-200 text-amber-700",
    low: "bg-blue-50 border-blue-200 text-blue-700",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-700 to-indigo-900 rounded-2xl p-6 text-white">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Flame size={18} className="text-amber-400" />
              <span className="text-amber-300 text-sm font-medium">
                Welcome back!
              </span>
            </div>
            <h1 className="text-white font-bold text-2xl">
              {currentUser?.name}
            </h1>
            <p className="text-indigo-200 mt-0.5 text-sm">
              {currentUser?.department} · Semester {currentUser?.semester} · ID:{" "}
              {currentUser?.studentId}
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => navigate("/student/cgpa")}
              variant="outline"
              className="bg-white/15 hover:bg-white/25 border-white/20 text-white rounded-xl"
            >
              <Calculator size={15} /> CGPA Calc
            </Button>
            <Button
              onClick={() => navigate("/student/roadmap")}
              className="bg-amber-500 hover:bg-amber-400 text-white rounded-xl shadow-lg shadow-amber-500/30"
            >
              <Target size={15} /> My Roadmap
            </Button>
          </div>
        </div>
      </div>

      {/* Low Attendance Warning */}
      {attendancePct < 75 && totalClasses > 0 && (
        <Alert
          variant="destructive"
          className="rounded-2xl border-red-200 bg-red-50 text-red-800"
        >
          <AlertCircle size={20} className="text-red-600" />
          <AlertDescription className="flex-1">
            <p className="font-semibold text-red-800">Low Attendance Warning</p>
            <p className="text-red-600 text-sm mt-0.5">
              Your overall attendance is {attendancePct}%. You need at least 75%
              to appear in exams. Please contact your academic advisor.
            </p>
          </AlertDescription>
          <Button
            variant="link"
            onClick={() => navigate("/student/attendance")}
            className="text-red-700 text-xs flex-shrink-0 h-auto p-0"
          >
            View Details
          </Button>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Enrolled Courses"
          value={myCourses.length}
          icon={<BookOpen size={22} className="text-white" />}
          color="bg-indigo-600"
          subtitle="This semester"
        />
        <StatsCard
          title="Pending Tasks"
          value={pendingAssignments.length}
          icon={<ClipboardList size={22} className="text-white" />}
          color={
            pendingAssignments.length > 0 ? "bg-amber-500" : "bg-emerald-600"
          }
          subtitle="Assignments due"
        />
        <StatsCard
          title="Attendance"
          value={`${attendancePct}%`}
          icon={<UserCheck size={22} className="text-white" />}
          color={attendancePct >= 75 ? "bg-emerald-600" : "bg-red-500"}
          subtitle={`${attended}/${totalClasses} classes`}
        />
        <StatsCard
          title="Submissions"
          value={submittedCount}
          icon={<CheckCircle2 size={22} className="text-white" />}
          color="bg-purple-600"
          subtitle={`${gradedCount} graded`}
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Attendance Radial */}
        <Card className="rounded-2xl flex flex-col items-center justify-center">
          <CardContent className="p-5 flex flex-col items-center justify-center">
            <h3 className="font-semibold text-gray-900 text-sm mb-2">
              Overall Attendance
            </h3>
            <div className="relative">
              <ResponsiveContainer width={160} height={160}>
                <RadialBarChart
                  cx="50%"
                  cy="50%"
                  innerRadius="60%"
                  outerRadius="90%"
                  data={attendanceData}
                  startAngle={90}
                  endAngle={-270}
                >
                  <RadialBar
                    dataKey="value"
                    cornerRadius={8}
                    background={{ fill: "#f3f4f6" }}
                  />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-bold text-2xl text-gray-900">
                  {attendancePct}%
                </span>
                <span className="text-xs text-gray-400">
                  {attended}/{totalClasses}
                </span>
              </div>
            </div>
            <p
              className={`text-sm font-medium mt-2 ${attendancePct >= 75 ? "text-emerald-600" : "text-red-500"}`}
            >
              {attendancePct >= 75 ? "✓ Good standing" : "⚠ Below required"}
            </p>
            <Button
              variant="link"
              onClick={() => navigate("/student/attendance")}
              className="mt-3 text-indigo-700 text-xs h-auto p-0"
            >
              View Details <ArrowRight size={11} />
            </Button>
          </CardContent>
        </Card>

        {/* Upcoming Deadlines */}
        <Card className="lg:col-span-2 rounded-2xl">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Clock size={16} className="text-amber-500" /> Upcoming
                Deadlines
              </h3>
              <Button
                variant="link"
                onClick={() => navigate("/student/assignments")}
                className="text-indigo-700 text-xs h-auto p-0"
              >
                All assignments <ArrowRight size={11} />
              </Button>
            </div>
            {upcomingDeadlines.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2
                  size={28}
                  className="text-emerald-400 mx-auto mb-2"
                />
                <p className="text-gray-400 text-sm">
                  All caught up! No pending assignments.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {upcomingDeadlines.map((asgn) => {
                  const course = courses.find((c) => c.id === asgn.courseId);
                  const daysLeft = Math.ceil(
                    (new Date(asgn.dueDate).getTime() - new Date().getTime()) /
                      (1000 * 60 * 60 * 24),
                  );
                  const urgency =
                    daysLeft <= 2 ? "red" : daysLeft <= 5 ? "amber" : "indigo";
                  const urgencyClasses = {
                    red: {
                      bg: "bg-red-50 border-red-100",
                      icon: "bg-red-100 text-red-600",
                      badge: "bg-red-100 text-red-700",
                      text: "text-red-600",
                    },
                    amber: {
                      bg: "bg-amber-50 border-amber-100",
                      icon: "bg-amber-100 text-amber-600",
                      badge: "bg-amber-100 text-amber-700",
                      text: "text-amber-600",
                    },
                    indigo: {
                      bg: "bg-gray-50 border-gray-100",
                      icon: "bg-indigo-100 text-indigo-600",
                      badge: "bg-indigo-100 text-indigo-700",
                      text: "text-indigo-600",
                    },
                  };
                  const uc = urgencyClasses[urgency];
                  return (
                    <div
                      key={asgn.id}
                      className={`flex items-center gap-3 p-3.5 border rounded-xl ${uc.bg}`}
                    >
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${uc.icon}`}
                      >
                        <ClipboardList size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 text-sm truncate">
                          {asgn.title}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {course?.code} · {asgn.totalMarks} marks
                        </p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <Badge className={`rounded-full ${uc.badge}`}>
                          {daysLeft === 0
                            ? "Due Today"
                            : daysLeft === 1
                              ? "Tomorrow"
                              : `${daysLeft}d left`}
                        </Badge>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(asgn.dueDate).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Materials */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <BookOpen size={16} className="text-indigo-600" /> Recent
                Lectures
              </h3>
              <Button
                variant="link"
                onClick={() => navigate("/student/lectures")}
                className="text-indigo-700 text-xs h-auto p-0"
              >
                All materials <ArrowRight size={11} />
              </Button>
            </div>
            {recentLectures.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-400 text-sm">
                  No lectures uploaded yet
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {recentLectures.map((lec) => {
                  const course = courses.find((c) => c.id === lec.courseId);
                  return (
                    <div
                      key={lec.id}
                      className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group cursor-pointer"
                    >
                      <Badge
                        variant="outline"
                        className={`rounded-lg uppercase ${typeColors[lec.type] || "bg-gray-100 text-gray-600"}`}
                      >
                        {lec.type}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 text-sm truncate">
                          {lec.title}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {course?.code} ·{" "}
                          {new Date(lec.uploadedAt).toLocaleDateString(
                            "en-US",
                            {
                              month: "short",
                              day: "numeric",
                            },
                          )}
                        </p>
                      </div>
                      {lec.size && (
                        <span className="text-xs text-gray-400 flex-shrink-0">
                          {lec.size}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Announcements */}
        <Card className="rounded-2xl">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                <Bell size={16} className="text-indigo-600" /> Announcements
              </h3>
            </div>
            {myAnnouncements.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-400 text-sm">No announcements</p>
              </div>
            ) : (
              <div className="space-y-3">
                {myAnnouncements.map((ann) => (
                  <div
                    key={ann.id}
                    className={`p-4 rounded-xl border ${priorityColors[ann.priority]}`}
                  >
                    <div className="flex items-start gap-2">
                      {ann.priority === "high" && (
                        <AlertCircle
                          size={15}
                          className="flex-shrink-0 mt-0.5"
                        />
                      )}
                      <div>
                        <p className="font-medium text-sm">{ann.title}</p>
                        <p className="text-xs opacity-75 mt-0.5 line-clamp-2">
                          {ann.content}
                        </p>
                        <p className="text-xs opacity-50 mt-1.5">
                          {new Date(ann.createdAt).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* My Courses Overview */}
      <Card className="rounded-2xl">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900 flex items-center gap-2">
              <TrendingUp size={16} className="text-indigo-600" /> Course
              Performance
            </h3>
            <Button
              variant="link"
              onClick={() => navigate("/student/timetable")}
              className="text-indigo-700 text-xs hover:underline flex items-center gap-1 h-auto p-0"
            >
              View Timetable <ArrowRight size={11} />
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {courseStats.map((c) => (
              <div
                key={c.id}
                className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:shadow-sm transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-medium text-gray-900 text-sm line-clamp-1">
                      {c.name}
                    </p>
                    <p className="text-gray-400 text-xs">
                      {c.code} · {c.credits} credits
                    </p>
                  </div>
                  <Badge
                    className={`rounded-full ${c.attendancePct >= 75 ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}
                  >
                    {c.attendancePct}%
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Attendance</span>
                      <span>{c.attendancePct}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div
                        className="h-1.5 rounded-full transition-all"
                        style={{
                          width: `${c.attendancePct}%`,
                          backgroundColor:
                            c.attendancePct >= 75 ? "#10b981" : "#ef4444",
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Assignments</span>
                      <span>
                        {c.submittedAsgns}/{c.totalAsgns}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div
                        className="h-1.5 rounded-full bg-indigo-500 transition-all"
                        style={{
                          width:
                            c.totalAsgns > 0
                              ? `${(c.submittedAsgns / c.totalAsgns) * 100}%`
                              : "0%",
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
