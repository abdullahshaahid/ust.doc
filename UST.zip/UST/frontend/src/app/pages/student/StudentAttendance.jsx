import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  TrendingUp,
} from "lucide-react";
import { Alert, AlertTitle } from "../../components/ui/alert";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../components/ui/table";

export default function StudentAttendance() {
  const { currentUser } = useAuth();
  const { courses, attendanceRecords, users } = useData();
  const [selectedCourse, setSelectedCourse] = useState("all");

  const enrichedUser = users.find((u) => u.id === currentUser?.id);
  const myCourseIds = enrichedUser?.enrolledCourses || [];
  const myCourses = courses.filter((c) => myCourseIds.includes(c.id));

  const getCourseStats = (courseId) => {
    const records = attendanceRecords.filter((r) => r.courseId === courseId);
    const total = records.length;
    const present = records.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "present",
      ),
    ).length;
    const late = records.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "late",
      ),
    ).length;
    const absent = records.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "absent",
      ),
    ).length;
    const pct =
      total > 0 ? Math.round(((present + late * 0.5) / total) * 100) : 0;
    return { total, present, late, absent, pct };
  };

  const overallStats = (() => {
    const allRecords = attendanceRecords.filter((r) =>
      myCourseIds.includes(r.courseId),
    );
    const total = allRecords.length;
    const present = allRecords.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "present",
      ),
    ).length;
    const late = allRecords.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "late",
      ),
    ).length;
    const absent = allRecords.filter((r) =>
      r.records.some(
        (rec) => rec.studentId === currentUser?.id && rec.status === "absent",
      ),
    ).length;
    const pct =
      total > 0 ? Math.round(((present + late * 0.5) / total) * 100) : 0;
    return { total, present, late, absent, pct };
  })();

  const detailRecords = attendanceRecords
    .filter((r) =>
      selectedCourse === "all"
        ? myCourseIds.includes(r.courseId)
        : r.courseId === selectedCourse,
    )
    .filter((r) => r.records.some((rec) => rec.studentId === currentUser?.id))
    .sort((a, b) => b.date.localeCompare(a.date));

  const getStatus = (record) => {
    const rec = record.records.find((r) => r.studentId === currentUser?.id);
    return rec?.status || "absent";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">Attendance Record</h1>
        <p className="text-gray-500 mt-1">
          Track your attendance across all courses
        </p>
      </div>

      {/* Overall Warning */}
      {overallStats.pct < 75 && overallStats.total > 0 && (
        <Alert
          variant="destructive"
          className="bg-red-50 border-red-200 rounded-2xl p-4 flex items-start gap-3"
        >
          <AlertTriangle
            size={20}
            className="text-red-600 flex-shrink-0 mt-0.5"
          />
          <div>
            <AlertTitle className="font-semibold text-red-800">
              Attendance Below Minimum
            </AlertTitle>
            <p className="text-red-600 text-sm mt-1">
              Your overall attendance is <strong>{overallStats.pct}%</strong>.
              You need at least 75% to sit for exams. You need to attend{" "}
              <strong>
                {Math.max(
                  0,
                  Math.ceil(overallStats.total * 0.75) - overallStats.present,
                )}
              </strong>{" "}
              more classes.
            </p>
          </div>
        </Alert>
      )}

      {/* Overall Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100 text-center">
          <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mx-auto mb-2">
            <TrendingUp size={20} className="text-indigo-600" />
          </div>
          <p
            className={`font-bold text-2xl ${overallStats.pct >= 75 ? "text-emerald-600" : "text-red-500"}`}
          >
            {overallStats.pct}%
          </p>
          <p className="text-gray-400 text-xs mt-1">Overall Attendance</p>
        </Card>
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100 text-center">
          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-2">
            <CheckCircle2 size={20} className="text-emerald-600" />
          </div>
          <p className="font-bold text-2xl text-emerald-600">
            {overallStats.present}
          </p>
          <p className="text-gray-400 text-xs mt-1">Present</p>
        </Card>
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100 text-center">
          <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mx-auto mb-2">
            <Clock size={20} className="text-amber-600" />
          </div>
          <p className="font-bold text-2xl text-amber-600">
            {overallStats.late}
          </p>
          <p className="text-gray-400 text-xs mt-1">Late</p>
        </Card>
        <Card className="rounded-2xl p-5 shadow-sm border-gray-100 text-center">
          <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-2">
            <XCircle size={20} className="text-red-600" />
          </div>
          <p className="font-bold text-2xl text-red-500">
            {overallStats.absent}
          </p>
          <p className="text-gray-400 text-xs mt-1">Absent</p>
        </Card>
      </div>

      {/* Per Course Breakdown */}
      <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="font-semibold text-gray-900">Attendance by Course</h3>
        </div>
        <div className="divide-y divide-gray-50">
          {myCourses.map((course) => {
            const stats = getCourseStats(course.id);
            const canMissMore = Math.max(
              0,
              Math.floor(stats.total * 0.25) - stats.absent,
            );
            const needsToAttend = Math.max(
              0,
              Math.ceil(stats.total * 0.75) - stats.present,
            );
            return (
              <div key={course.id} className="p-5">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <p className="font-semibold text-gray-900">{course.name}</p>
                    <p className="text-gray-400 text-xs">
                      {course.code} · {stats.total} classes recorded
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p
                      className={`font-bold text-xl ${stats.pct >= 75 ? "text-emerald-600" : "text-red-500"}`}
                    >
                      {stats.pct}%
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex-1 bg-gray-100 rounded-full h-2.5">
                    <div
                      className="h-2.5 rounded-full transition-all duration-300"
                      style={{
                        width: `${Math.min(stats.pct, 100)}%`,
                        backgroundColor:
                          stats.pct >= 75
                            ? "#10b981"
                            : stats.pct >= 60
                              ? "#f59e0b"
                              : "#ef4444",
                      }}
                    />
                  </div>
                  <span className="text-xs text-gray-400">
                    {stats.present + stats.late}/{stats.total}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <span className="flex items-center gap-1 text-emerald-600">
                    <CheckCircle2 size={12} />
                    {stats.present} present
                  </span>
                  <span className="flex items-center gap-1 text-amber-500">
                    <Clock size={12} />
                    {stats.late} late
                  </span>
                  <span className="flex items-center gap-1 text-red-500">
                    <XCircle size={12} />
                    {stats.absent} absent
                  </span>
                  {stats.pct >= 75 ? (
                    <span className="text-gray-400 ml-auto">
                      Can miss {canMissMore} more
                    </span>
                  ) : (
                    <span className="text-red-600 font-medium ml-auto">
                      Need {needsToAttend} more classes
                    </span>
                  )}
                </div>
              </div>
            );
          })}
          {myCourses.length === 0 && (
            <p className="text-center text-gray-400 text-sm py-8">
              No courses enrolled
            </p>
          )}
        </div>
      </Card>

      {/* Detailed Records */}
      <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between flex-wrap gap-3">
          <h3 className="font-semibold text-gray-900">Detailed Records</h3>
          <select
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3.5 py-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Courses</option>
            {myCourses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.code} - {c.name}
              </option>
            ))}
          </select>
        </div>
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase">
                Date
              </TableHead>
              <TableHead className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase hidden sm:table-cell">
                Course
              </TableHead>
              <TableHead className="text-center px-5 py-3 text-xs font-semibold text-gray-500 uppercase">
                Status
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-gray-50">
            {detailRecords.length === 0 && (
              <TableRow>
                <TableCell
                  colSpan={3}
                  className="text-center py-8 text-gray-400 text-sm"
                >
                  No records found
                </TableCell>
              </TableRow>
            )}
            {detailRecords.map((rec) => {
              const status = getStatus(rec);
              const course = courses.find((c) => c.id === rec.courseId);
              const statusConfig = {
                present: {
                  color: "bg-emerald-100 text-emerald-700",
                  label: "Present",
                  icon: <CheckCircle2 size={13} />,
                },
                absent: {
                  color: "bg-red-100 text-red-700",
                  label: "Absent",
                  icon: <XCircle size={13} />,
                },
                late: {
                  color: "bg-amber-100 text-amber-700",
                  label: "Late",
                  icon: <Clock size={13} />,
                },
              }[status] || {
                color: "bg-gray-100 text-gray-700",
                label: status,
                icon: null,
              };

              return (
                <TableRow
                  key={rec.id}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <TableCell className="px-5 py-3 text-sm text-gray-700">
                    {new Date(rec.date).toLocaleDateString("en-US", {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </TableCell>
                  <TableCell className="px-5 py-3 text-sm text-gray-500 hidden sm:table-cell">
                    {course?.code} — {course?.name}
                  </TableCell>
                  <TableCell className="px-5 py-3 text-center">
                    <Badge
                      className={`inline-flex items-center gap-1 rounded-full ${statusConfig.color}`}
                    >
                      {statusConfig.icon} {statusConfig.label}
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
