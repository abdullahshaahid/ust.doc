import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  CheckCircle2,
  Circle,
  ChevronRight,
  BookOpen,
  Target,
} from "lucide-react";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";

export default function StudentRoadmap() {
  const { currentUser } = useAuth();
  const { roadmap } = useData();

  const dept = currentUser?.department || "Computer Science";
  const currentSemester = currentUser?.semester || 1;

  const deptRoadmap = roadmap
    .filter((r) => r.department === dept)
    .sort((a, b) => a.semester - b.semester);

  const totalSemesters = deptRoadmap.length;
  const completedSemesters = deptRoadmap.filter(
    (r) => r.semester < currentSemester,
  ).length;
  const progressPct =
    totalSemesters > 0
      ? Math.round((completedSemesters / totalSemesters) * 100)
      : 0;

  const statusOf = (sem) => {
    if (sem < currentSemester) return "completed";
    if (sem === currentSemester) return "current";
    return "upcoming";
  };

  const statusConfig = {
    completed: {
      bg: "bg-emerald-600",
      border: "border-emerald-600",
      text: "text-emerald-700",
      light: "bg-emerald-50 border-emerald-200",
      label: "Completed",
    },
    current: {
      bg: "bg-indigo-600",
      border: "border-indigo-600",
      text: "text-indigo-700",
      light: "bg-indigo-50 border-indigo-200",
      label: "In Progress",
    },
    upcoming: {
      bg: "bg-gray-300",
      border: "border-gray-300",
      text: "text-gray-500",
      light: "bg-gray-50 border-gray-200",
      label: "Upcoming",
    },
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">Academic Roadmap</h1>
        <p className="text-gray-500 mt-1">
          {dept} Department — Your path to graduation
        </p>
      </div>

      {/* Progress Overview */}
      <div className="bg-gradient-to-r from-indigo-700 to-indigo-900 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="text-indigo-200 text-sm mb-1">Academic Progress</p>
            <h2 className="text-white font-bold text-2xl">{dept}</h2>
            <p className="text-indigo-200 text-sm mt-1">
              Currently in Semester {currentSemester}
            </p>
          </div>
          <div className="w-full md:w-64">
            <div className="flex items-center justify-between mb-2">
              <span className="text-indigo-200 text-sm">
                {completedSemesters} of {totalSemesters} semesters
              </span>
              <span className="font-bold text-white">{progressPct}%</span>
            </div>
            <div className="bg-white/20 rounded-full h-3">
              <div
                className="bg-amber-400 h-3 rounded-full transition-all duration-700"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-indigo-300">
              <span>Start</span>
              <span>Graduation</span>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/10">
          <div className="text-center">
            <p className="font-bold text-2xl text-emerald-400">
              {completedSemesters}
            </p>
            <p className="text-indigo-200 text-xs mt-1">Completed</p>
          </div>
          <div className="text-center">
            <p className="font-bold text-2xl text-amber-400">1</p>
            <p className="text-indigo-200 text-xs mt-1">In Progress</p>
          </div>
          <div className="text-center">
            <p className="font-bold text-2xl text-white">
              {Math.max(0, totalSemesters - currentSemester)}
            </p>
            <p className="text-indigo-200 text-xs mt-1">Remaining</p>
          </div>
        </div>
      </div>

      {/* Roadmap Timeline */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-gray-200 hidden sm:block" />

        <div className="space-y-6">
          {deptRoadmap.map((item, idx) => {
            const status = statusOf(item.semester);
            const cfg = statusConfig[status];
            const isRight = idx % 2 === 0;

            return (
              <div
                key={item.id}
                className={`relative flex flex-col sm:flex-row gap-4 sm:gap-8 items-start sm:items-center ${!isRight ? "sm:flex-row-reverse" : ""}`}
              >
                {/* Timeline dot */}
                <div
                  className={`hidden sm:flex absolute left-1/2 transform -translate-x-1/2 w-10 h-10 ${cfg.bg} rounded-full items-center justify-center text-white font-bold text-sm shadow-lg z-10 flex-shrink-0`}
                >
                  {status === "completed" ? (
                    <CheckCircle2 size={20} className="fill-white/30" />
                  ) : (
                    item.semester
                  )}
                </div>

                {/* Card */}
                <div
                  className={`w-full sm:w-5/12 ${isRight ? "sm:pr-8" : "sm:pl-8"}`}
                >
                  <div
                    className={`rounded-2xl border-2 p-5 ${cfg.light} ${status === "current" ? "shadow-md shadow-indigo-100" : "shadow-sm"}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <Badge
                        className={`rounded-full font-semibold ${cfg.light.replace("border-", "border ")} ${cfg.text} border`}
                      >
                        Semester {item.semester} · {cfg.label}
                      </Badge>
                      {status === "current" && (
                        <span className="flex h-2.5 w-2.5">
                          <span className="animate-ping absolute inline-flex h-2.5 w-2.5 rounded-full bg-indigo-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500" />
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-gray-900 text-lg mb-1">
                      {item.title}
                    </h3>
                    <p className="text-gray-500 text-sm mb-4">
                      {item.description}
                    </p>

                    {/* Courses */}
                    <div className="space-y-1.5 mb-4">
                      <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                        <BookOpen size={11} /> Courses
                      </p>
                      {item.courses.map((course, ci) => (
                        <div
                          key={ci}
                          className="flex items-center gap-2 text-sm text-gray-700"
                        >
                          {status === "completed" ? (
                            <CheckCircle2
                              size={14}
                              className="text-emerald-500 flex-shrink-0"
                            />
                          ) : status === "current" ? (
                            <div className="w-3.5 h-3.5 rounded-full border-2 border-indigo-500 flex-shrink-0" />
                          ) : (
                            <Circle
                              size={14}
                              className="text-gray-300 flex-shrink-0"
                            />
                          )}
                          {course}
                        </div>
                      ))}
                    </div>

                    {/* Outcomes */}
                    <div className="border-t border-current/10 pt-3">
                      <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1 mb-2">
                        <Target size={11} /> Learning Outcomes
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {item.outcomes.map((outcome, oi) => (
                          <Badge
                            key={oi}
                            className={`rounded-full ${cfg.text} ${status === "completed" ? "bg-emerald-100" : status === "current" ? "bg-indigo-100" : "bg-gray-100 text-gray-500"}`}
                          >
                            {outcome}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Empty space for the other side on desktop */}
                <div className="hidden sm:block w-5/12" />
              </div>
            );
          })}
        </div>
      </div>

      {deptRoadmap.length === 0 && (
        <Card className="text-center py-16 rounded-2xl border-gray-100">
          <BookOpen size={32} className="text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400">
            No roadmap defined for {dept} department yet
          </p>
        </Card>
      )}
    </div>
  );
}
