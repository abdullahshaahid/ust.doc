import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  ClipboardList,
  CheckCircle2,
  Clock,
  AlertCircle,
  Send,
  X,
  Star,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

export default function ViewAssignments() {
  const { currentUser } = useAuth();
  const { courses, assignments, submitAssignment, users } = useData();
  const [filter, setFilter] = useState("all");
  const [submitting, setSubmitting] = useState(null);
  const [content, setContent] = useState("");

  const enrichedUser = users.find((u) => u.id === currentUser?.id);
  const myCourseIds = enrichedUser?.enrolledCourses || [];
  const myCourses = courses.filter((c) => myCourseIds.includes(c.id));
  const myAssignments = assignments.filter((a) =>
    myCourseIds.includes(a.courseId),
  );

  const getMySubmission = (a) =>
    a.submissions.find((s) => s.studentId === currentUser?.id);

  const filtered = myAssignments
    .filter((a) => {
      const sub = getMySubmission(a);
      if (filter === "pending") return !sub;
      if (filter === "submitted") return sub?.status === "submitted";
      if (filter === "graded") return sub?.status === "graded";
      return true;
    })
    .sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime(),
    );

  const handleSubmit = () => {
    if (!submitting || !content.trim()) return;
    submitAssignment(submitting, {
      studentId: currentUser?.id || "",
      submittedAt: new Date().toISOString(),
      content: content.trim(),
      status: "submitted",
    });
    setSubmitting(null);
    setContent("");
  };

  const pendingCount = myAssignments.filter((a) => !getMySubmission(a)).length;
  const submittedCount = myAssignments.filter(
    (a) => getMySubmission(a)?.status === "submitted",
  ).length;
  const gradedCount = myAssignments.filter(
    (a) => getMySubmission(a)?.status === "graded",
  ).length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">Assignments</h1>
        <p className="text-gray-500 mt-1">
          View and submit your course assignments
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          {
            key: "all",
            label: `All (${myAssignments.length})`,
            color: "indigo",
          },
          {
            key: "pending",
            label: `Pending (${pendingCount})`,
            color: "amber",
          },
          {
            key: "submitted",
            label: `Submitted (${submittedCount})`,
            color: "blue",
          },
          { key: "graded", label: `Graded (${gradedCount})`, color: "emerald" },
        ].map((tab) => (
          <Button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            variant={filter === tab.key ? "default" : "outline"}
            className={`rounded-xl ${filter === tab.key ? "bg-indigo-700 text-white" : "hover:border-indigo-300 hover:text-indigo-700"}`}
          >
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Assignments */}
      <div className="space-y-4">
        {filtered.length === 0 && (
          <Card className="text-center py-16 rounded-2xl border-gray-100">
            <CheckCircle2 size={32} className="text-emerald-400 mx-auto mb-3" />
            <p className="text-gray-400">No assignments in this category</p>
          </Card>
        )}
        {filtered.map((asgn) => {
          const sub = getMySubmission(asgn);
          const course = courses.find((c) => c.id === asgn.courseId);
          const isOverdue = new Date(asgn.dueDate) < new Date();
          const daysLeft = Math.ceil(
            (new Date(asgn.dueDate).getTime() - new Date().getTime()) /
              (1000 * 60 * 60 * 24),
          );

          return (
            <Card
              key={asgn.id}
              className="rounded-2xl shadow-sm border-gray-100 overflow-hidden"
            >
              <div className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-gray-900">
                        {asgn.title}
                      </h3>
                      {sub?.status === "graded" && (
                        <Badge className="flex items-center gap-1 bg-emerald-100 text-emerald-700 rounded-full">
                          <CheckCircle2 size={11} /> Graded
                        </Badge>
                      )}
                      {sub?.status === "submitted" && (
                        <Badge className="flex items-center gap-1 bg-blue-100 text-blue-700 rounded-full">
                          <Clock size={11} /> Submitted
                        </Badge>
                      )}
                      {!sub && isOverdue && (
                        <Badge className="flex items-center gap-1 bg-red-100 text-red-700 rounded-full">
                          <AlertCircle size={11} /> Overdue
                        </Badge>
                      )}
                      {!sub && !isOverdue && (
                        <Badge className="flex items-center gap-1 bg-amber-100 text-amber-700 rounded-full">
                          <Clock size={11} /> Pending
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-400 text-xs mb-3">
                      {course?.code} · {course?.name} · {asgn.totalMarks} marks
                      total
                    </p>
                    <p className="text-gray-600 text-sm">{asgn.description}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p
                      className={`text-sm font-semibold ${isOverdue && !sub ? "text-red-600" : daysLeft <= 3 && !sub ? "text-amber-600" : "text-gray-600"}`}
                    >
                      {sub
                        ? new Date(asgn.dueDate).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })
                        : isOverdue
                          ? "Overdue"
                          : daysLeft === 0
                            ? "Due Today"
                            : daysLeft === 1
                              ? "Due Tomorrow"
                              : `${daysLeft} days left`}
                    </p>
                    <p className="text-xs text-gray-400">
                      Due:{" "}
                      {new Date(asgn.dueDate).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </p>
                  </div>
                </div>

                {/* Grade Display */}
                {sub?.status === "graded" && (
                  <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-emerald-800 flex items-center gap-2">
                        <Star
                          size={16}
                          className="fill-amber-400 text-amber-400"
                        />{" "}
                        Grade
                      </p>
                      <p className="font-bold text-emerald-700 text-xl">
                        {sub.marks}/{asgn.totalMarks}{" "}
                        <span className="text-sm font-normal">
                          ({Math.round((sub.marks / asgn.totalMarks) * 100)}%)
                        </span>
                      </p>
                    </div>
                    {sub.feedback && (
                      <p className="text-emerald-700 text-sm">
                        <span className="font-medium">Feedback:</span>{" "}
                        {sub.feedback}
                      </p>
                    )}
                  </div>
                )}

                {/* Submission Display */}
                {sub?.status === "submitted" && (
                  <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                    <p className="text-blue-700 text-sm font-medium">
                      ✓ Submitted on{" "}
                      {new Date(sub.submittedAt).toLocaleDateString("en-US", {
                        month: "long",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </p>
                    <p className="text-blue-600 text-xs mt-1">
                      Awaiting teacher review...
                    </p>
                  </div>
                )}

                {/* Submit Button */}
                {!sub && (
                  <div className="mt-4">
                    <Button
                      onClick={() => {
                        setSubmitting(asgn.id);
                        setContent("");
                      }}
                      disabled={isOverdue}
                      className={`flex items-center gap-2 rounded-xl ${isOverdue ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-indigo-700 text-white hover:bg-indigo-800"}`}
                    >
                      <Send size={14} />{" "}
                      {isOverdue ? "Submission Closed" : "Submit Assignment"}
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Submit Modal */}
      <Dialog
        open={!!submitting}
        onOpenChange={(open) => !open && setSubmitting(null)}
      >
        <DialogContent className="rounded-2xl max-w-lg">
          <DialogHeader>
            <DialogTitle>Submit Assignment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600 text-sm font-medium">
              {assignments.find((a) => a.id === submitting)?.title}
            </p>
            <div>
              <Label className="mb-1.5">Your Answer / Notes</Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={6}
                placeholder="Write your answer or describe your submission here..."
                className="rounded-xl resize-none"
              />
              <p className="text-gray-400 text-xs mt-2">
                In a real system, you would upload files here. Describe your
                submission.
              </p>
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setSubmitting(null)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!content.trim()}
              className="flex-1 bg-indigo-700 text-white rounded-xl hover:bg-indigo-800 disabled:opacity-50"
            >
              <Send size={14} className="mr-2" /> Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
