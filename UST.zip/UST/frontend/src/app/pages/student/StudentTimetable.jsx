import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import { Clock, MapPin, BookOpen, FlaskConical } from "lucide-react";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../components/ui/table";

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
const TIME_SLOTS = [
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
];

const typeColors = {
  lecture: "bg-indigo-100 border-indigo-300 text-indigo-800",
  lab: "bg-emerald-100 border-emerald-300 text-emerald-800",
  tutorial: "bg-amber-100 border-amber-300 text-amber-800",
};

const typeIcons = {
  lecture: <BookOpen size={12} />,
  lab: <FlaskConical size={12} />,
  tutorial: <Clock size={12} />,
};

export default function StudentTimetable() {
  const { currentUser } = useAuth();
  const { courses, timetable, users } = useData();

  const enrichedUser = users.find((u) => u.id === currentUser?.id);
  const myCourseIds = enrichedUser?.enrolledCourses || [];
  const myEntries = timetable.filter((t) => myCourseIds.includes(t.courseId));

  const getCourse = (id) => courses.find((c) => c.id === id);

  const getEntriesForSlot = (day, hour) => {
    return myEntries.filter((e) => {
      if (e.day !== day) return false;
      const start = parseInt(e.startTime.split(":")[0]);
      const slotHour = parseInt(hour.split(":")[0]);
      const end = parseInt(e.endTime.split(":")[0]);
      return start === slotHour;
    });
  };

  const today = DAYS[new Date().getDay() - 1] || "";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">My Timetable</h1>
        <p className="text-gray-500 mt-1">
          Weekly class schedule for your enrolled courses
        </p>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 flex-wrap">
        {Object.entries(typeColors).map(([type, color]) => (
          <div key={type} className="flex items-center gap-2">
            <div
              className={`w-4 h-4 rounded border ${color.split(" ").slice(0, 2).join(" ")}`}
            />
            <span className="text-sm text-gray-500 capitalize">{type}</span>
          </div>
        ))}
      </div>

      {/* Desktop Grid */}
      <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden hidden md:block">
        <Table className="min-w-[700px]">
          <TableHeader>
            <TableRow className="bg-gray-50 border-b border-gray-100">
              <TableHead className="w-20 py-4 px-3 text-xs font-semibold text-gray-400 uppercase text-center">
                Time
              </TableHead>
              {DAYS.map((day) => (
                <TableHead
                  key={day}
                  className={`py-4 px-3 text-xs font-semibold uppercase text-center ${day === today ? "text-indigo-700 bg-indigo-50" : "text-gray-500"}`}
                >
                  {day}
                  {day === today && (
                    <Badge className="ml-1 bg-indigo-600 text-white rounded-full">
                      Today
                    </Badge>
                  )}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {TIME_SLOTS.map((slot) => (
              <TableRow
                key={slot}
                className="border-b border-gray-50 last:border-0"
              >
                <TableCell className="py-2 px-3 text-center">
                  <span className="text-xs text-gray-400 font-mono">
                    {slot}
                  </span>
                </TableCell>
                {DAYS.map((day) => {
                  const entries = getEntriesForSlot(day, slot);
                  return (
                    <TableCell
                      key={day}
                      className={`py-1 px-2 min-w-[140px] ${day === today ? "bg-indigo-50/30" : ""}`}
                    >
                      {entries.map((entry) => {
                        const course = getCourse(entry.courseId);
                        return (
                          <div
                            key={entry.id}
                            className={`rounded-xl border p-2 mb-1 ${typeColors[entry.type] || "bg-gray-100 border-gray-200 text-gray-700"}`}
                          >
                            <div className="flex items-center gap-1 mb-0.5">
                              {typeIcons[entry.type]}
                              <span className="text-xs font-semibold">
                                {course?.code}
                              </span>
                            </div>
                            <p className="text-xs font-medium leading-tight line-clamp-1">
                              {course?.name}
                            </p>
                            <div className="flex items-center gap-1 mt-1 text-xs opacity-70">
                              <Clock size={10} />
                              {entry.startTime}–{entry.endTime}
                              <MapPin size={10} className="ml-1" />
                              {entry.room}
                            </div>
                          </div>
                        );
                      })}
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Mobile List View */}
      <div className="md:hidden space-y-4">
        {DAYS.map((day) => {
          const dayEntries = myEntries
            .filter((e) => e.day === day)
            .sort((a, b) => a.startTime.localeCompare(b.startTime));
          return (
            <Card
              key={day}
              className="rounded-2xl shadow-sm border-gray-100 overflow-hidden"
            >
              <div
                className={`px-4 py-3 border-b border-gray-100 flex items-center gap-2 ${day === today ? "bg-indigo-50" : "bg-gray-50"}`}
              >
                <h3
                  className={`font-semibold ${day === today ? "text-indigo-700" : "text-gray-900"}`}
                >
                  {day}
                </h3>
                {day === today && (
                  <Badge className="bg-indigo-600 text-white rounded-full">
                    Today
                  </Badge>
                )}
              </div>
              {dayEntries.length === 0 ? (
                <p className="text-center text-gray-400 text-sm py-6">
                  No classes
                </p>
              ) : (
                <div className="divide-y divide-gray-50">
                  {dayEntries.map((entry) => {
                    const course = getCourse(entry.courseId);
                    return (
                      <div
                        key={entry.id}
                        className="flex items-center gap-3 px-4 py-3"
                      >
                        <div
                          className={`w-2 self-stretch rounded-full ${entry.type === "lecture" ? "bg-indigo-400" : entry.type === "lab" ? "bg-emerald-400" : "bg-amber-400"}`}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 text-sm">
                            {course?.name}
                          </p>
                          <p className="text-gray-400 text-xs">
                            {course?.code} · {entry.room}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="text-sm font-medium text-gray-700">
                            {entry.startTime}
                          </p>
                          <p className="text-xs text-gray-400">
                            {entry.endTime}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {["lecture", "lab", "tutorial"].map((type) => {
          const count = myEntries.filter((e) => e.type === type).length;
          return (
            <Card
              key={type}
              className="rounded-2xl p-4 shadow-sm border-gray-100 text-center"
            >
              <p className="font-bold text-gray-900 text-xl">{count}</p>
              <p className="text-gray-400 text-xs mt-1 capitalize">
                {type}s/week
              </p>
            </Card>
          );
        })}
        <Card className="rounded-2xl p-4 shadow-sm border-gray-100 text-center">
          <p className="font-bold text-gray-900 text-xl">{myEntries.length}</p>
          <p className="text-gray-400 text-xs mt-1">Total sessions/week</p>
        </Card>
      </div>
    </div>
  );
}
