import { useState } from "react";
import { useData } from "../../context/DataContext";
import { useAuth } from "../../context/AuthContext";
import {
  Calculator,
  Plus,
  Trash2,
  Star,
  TrendingUp,
  BookOpen,
  Award,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import { Card } from "../../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../components/ui/dialog";

const GRADES = [
  { letter: "A+", gpa: 4.0, label: "A+ (4.0)" },
  { letter: "A", gpa: 4.0, label: "A  (4.0)" },
  { letter: "A-", gpa: 3.7, label: "A- (3.7)" },
  { letter: "B+", gpa: 3.3, label: "B+ (3.3)" },
  { letter: "B", gpa: 3.0, label: "B  (3.0)" },
  { letter: "B-", gpa: 2.7, label: "B- (2.7)" },
  { letter: "C+", gpa: 2.3, label: "C+ (2.3)" },
  { letter: "C", gpa: 2.0, label: "C  (2.0)" },
  { letter: "C-", gpa: 1.7, label: "C- (1.7)" },
  { letter: "D", gpa: 1.0, label: "D  (1.0)" },
  { letter: "F", gpa: 0.0, label: "F  (0.0)" },
];

const getGradeColor = (cgpa) => {
  if (cgpa >= 3.7)
    return {
      color: "text-emerald-600",
      bg: "bg-emerald-50 border-emerald-200",
      label: "Distinction",
      icon: "🏆",
    };
  if (cgpa >= 3.3)
    return {
      color: "text-blue-600",
      bg: "bg-blue-50 border-blue-200",
      label: "Very Good",
      icon: "🌟",
    };
  if (cgpa >= 2.7)
    return {
      color: "text-indigo-600",
      bg: "bg-indigo-50 border-indigo-200",
      label: "Good",
      icon: "👍",
    };
  if (cgpa >= 2.0)
    return {
      color: "text-amber-600",
      bg: "bg-amber-50 border-amber-200",
      label: "Satisfactory",
      icon: "📚",
    };
  return {
    color: "text-red-600",
    bg: "bg-red-50 border-red-200",
    label: "Needs Improvement",
    icon: "⚠️",
  };
};

export default function CGPACalculator() {
  const { currentUser } = useAuth();
  const { courses, assignments, users } = useData();

  const enrichedUser = users.find((u) => u.id === currentUser?.id);
  const myCourseIds = enrichedUser?.enrolledCourses || [];
  const myCourses = courses.filter((c) => myCourseIds.includes(c.id));

  // Current semester courses pre-filled
  const [semesterCourses, setSemesterCourses] = useState(
    myCourses.map((c) => ({
      id: c.id,
      name: `${c.code} - ${c.name}`,
      credits: c.credits,
      grade: "B",
    })),
  );

  // Previous semesters (mock data for cumulative)
  const [prevSemesters, setPrevSemesters] = useState([
    { semester: 1, cgpa: 3.2, credits: 15 },
    { semester: 2, cgpa: 3.5, credits: 16 },
  ]);
  const [showPrevModal, setShowPrevModal] = useState(false);
  const [newPrev, setNewPrev] = useState({
    semester: "",
    cgpa: "",
    credits: "",
  });

  const calcSGPA = (courseList) => {
    const totalPoints = courseList.reduce((acc, c) => {
      const grade = GRADES.find((g) => g.letter === c.grade);
      return acc + (grade?.gpa || 0) * c.credits;
    }, 0);
    const totalCredits = courseList.reduce((acc, c) => acc + c.credits, 0);
    return totalCredits > 0 ? totalPoints / totalCredits : 0;
  };

  const currentSGPA = calcSGPA(semesterCourses);
  const currentCredits = semesterCourses.reduce((a, c) => a + c.credits, 0);

  // CGPA = weighted average of all semesters
  const allSemesters = [
    ...prevSemesters,
    {
      semester: prevSemesters.length + 1,
      cgpa: currentSGPA,
      credits: currentCredits,
    },
  ];
  const totalWeightedPoints = allSemesters.reduce(
    (acc, s) => acc + s.cgpa * s.credits,
    0,
  );
  const totalAllCredits = allSemesters.reduce((acc, s) => acc + s.credits, 0);
  const overallCGPA =
    totalAllCredits > 0 ? totalWeightedPoints / totalAllCredits : 0;

  const gradeInfo = getGradeColor(overallCGPA);

  const addCourse = () => {
    setSemesterCourses((prev) => [
      ...prev,
      {
        id: `custom_${Date.now()}`,
        name: "New Course",
        credits: 3,
        grade: "B",
      },
    ]);
  };

  const removeCourse = (id) => {
    setSemesterCourses((prev) => prev.filter((c) => c.id !== id));
  };

  const updateCourse = (id, field, value) => {
    setSemesterCourses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, [field]: value } : c)),
    );
  };

  // Graded assignments to show actual performance
  const gradedAssignments = assignments
    .filter((a) => myCourseIds.includes(a.courseId))
    .flatMap((a) =>
      a.submissions
        .filter((s) => s.studentId === currentUser?.id && s.status === "graded")
        .map((s) => ({ ...s, assignment: a })),
    );

  const requiredForTarget = (target) => {
    const prevTotal = prevSemesters.reduce(
      (acc, s) => acc + s.cgpa * s.credits,
      0,
    );
    const prevCredits = prevSemesters.reduce((acc, s) => acc + s.credits, 0);
    if (target <= prevTotal / prevCredits) return null;
    const needed =
      (target * (prevCredits + currentCredits) - prevTotal) / currentCredits;
    return Math.min(4.0, Math.max(0, needed));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">CGPA Calculator</h1>
        <p className="text-gray-500 mt-1">
          Calculate your Semester GPA and Cumulative GPA
        </p>
      </div>

      {/* CGPA Result Banner */}
      <div className={`rounded-2xl border-2 p-6 ${gradeInfo.bg}`}>
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <p className="text-sm font-medium text-gray-500 mb-1">
              Your Cumulative GPA
            </p>
            <div className="flex items-baseline gap-2">
              <p className={`font-bold text-6xl ${gradeInfo.color}`}>
                {overallCGPA.toFixed(2)}
              </p>
              <p className="text-gray-400 text-lg">/ 4.00</p>
            </div>
            <p className={`font-semibold mt-1 ${gradeInfo.color}`}>
              {gradeInfo.icon} {gradeInfo.label}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-white/70 rounded-xl p-4">
              <p
                className={`font-bold text-2xl ${currentSGPA >= 3.0 ? "text-emerald-600" : "text-amber-500"}`}
              >
                {currentSGPA.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500 mt-1">Current SGPA</p>
            </div>
            <div className="bg-white/70 rounded-xl p-4">
              <p className="font-bold text-2xl text-indigo-600">
                {totalAllCredits}
              </p>
              <p className="text-xs text-gray-500 mt-1">Total Credits</p>
            </div>
            <div className="bg-white/70 rounded-xl p-4">
              <p className="font-bold text-2xl text-purple-600">
                {prevSemesters.length + 1}
              </p>
              <p className="text-xs text-gray-500 mt-1">Semesters</p>
            </div>
            <div className="bg-white/70 rounded-xl p-4">
              <p className="font-bold text-2xl text-amber-600">
                {currentCredits}
              </p>
              <p className="text-xs text-gray-500 mt-1">Current Credits</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Current Semester Calculator */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900">
                  Current Semester (Sem {prevSemesters.length + 1})
                </h3>
                <p className="text-gray-400 text-xs mt-0.5">
                  SGPA: {currentSGPA.toFixed(2)} · {currentCredits} credits
                </p>
              </div>
              <Button
                onClick={addCourse}
                className="flex items-center gap-1.5 bg-indigo-700 text-white rounded-xl text-sm hover:bg-indigo-800"
              >
                <Plus size={15} /> Add Course
              </Button>
            </div>
            <div className="divide-y divide-gray-50">
              {semesterCourses.map((course) => {
                const gradeObj = GRADES.find((g) => g.letter === course.grade);
                const points = (gradeObj?.gpa || 0) * course.credits;
                return (
                  <div
                    key={course.id}
                    className="flex items-center gap-3 px-5 py-3"
                  >
                    <div className="flex-1 min-w-0">
                      <Input
                        value={course.name}
                        onChange={(e) =>
                          updateCourse(course.id, "name", e.target.value)
                        }
                        className="font-medium text-gray-900 text-sm bg-transparent border-none outline-none w-full truncate shadow-none h-auto p-0"
                        placeholder="Course name"
                      />
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="flex items-center gap-1">
                        <Label className="text-xs text-gray-400">Cr:</Label>
                        <Input
                          type="number"
                          value={course.credits}
                          min={1}
                          max={6}
                          onChange={(e) =>
                            updateCourse(
                              course.id,
                              "credits",
                              parseInt(e.target.value) || 1,
                            )
                          }
                          className="w-10 text-center border border-gray-200 rounded-lg py-1 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 h-auto px-1"
                        />
                      </div>
                      <select
                        value={course.grade}
                        onChange={(e) =>
                          updateCourse(course.id, "grade", e.target.value)
                        }
                        className="border border-gray-200 rounded-lg py-1 px-2 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white font-mono"
                      >
                        {GRADES.map((g) => (
                          <option key={g.letter} value={g.letter}>
                            {g.label}
                          </option>
                        ))}
                      </select>
                      <span
                        className={`text-xs font-bold w-10 text-right ${(gradeObj?.gpa || 0) >= 3.0 ? "text-emerald-600" : (gradeObj?.gpa || 0) >= 2.0 ? "text-amber-500" : "text-red-500"}`}
                      >
                        {points.toFixed(1)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeCourse(course.id)}
                        className="h-7 w-7 text-gray-300 hover:text-red-500"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                );
              })}
              {semesterCourses.length === 0 && (
                <div className="text-center py-8 text-gray-400 text-sm">
                  No courses added. Click "Add Course" to begin.
                </div>
              )}
            </div>
          </Card>

          {/* Previous Semesters */}
          <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">
                Previous Semesters
              </h3>
              <Button
                variant="link"
                onClick={() => setShowPrevModal(true)}
                className="text-indigo-600 text-xs font-medium"
              >
                + Add Semester
              </Button>
            </div>
            <div className="divide-y divide-gray-50">
              {prevSemesters.map((sem, idx) => {
                const info = getGradeColor(sem.cgpa);
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-4 px-5 py-3.5"
                  >
                    <div className="w-9 h-9 bg-indigo-100 rounded-xl flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0">
                      S{sem.semester}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 text-sm">
                        Semester {sem.semester}
                      </p>
                      <p className="text-gray-400 text-xs">
                        {sem.credits} credits
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold text-lg ${info.color}`}>
                        {sem.cgpa.toFixed(2)}
                      </p>
                      <p className="text-xs text-gray-400">GPA</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() =>
                        setPrevSemesters((prev) =>
                          prev.filter((_, i) => i !== idx),
                        )
                      }
                      className="h-7 w-7 text-gray-300 hover:text-red-500 ml-2"
                    >
                      <Trash2 size={13} />
                    </Button>
                  </div>
                );
              })}
              {prevSemesters.length === 0 && (
                <p className="text-center py-6 text-gray-400 text-sm">
                  No previous semesters added
                </p>
              )}
            </div>
          </Card>
        </div>

        {/* Right Panel */}
        <div className="space-y-4">
          {/* Grade Scale */}
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Star size={16} className="text-amber-500 fill-amber-400" /> Grade
              Scale
            </h3>
            <div className="space-y-1.5">
              {GRADES.slice(0, 8).map((g) => (
                <div
                  key={g.letter}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="font-mono font-bold text-gray-800 w-8">
                    {g.letter}
                  </span>
                  <div className="flex-1 mx-3 bg-gray-100 rounded-full h-1.5">
                    <div
                      className="h-1.5 rounded-full"
                      style={{
                        width: `${(g.gpa / 4) * 100}%`,
                        backgroundColor:
                          g.gpa >= 3.0
                            ? "#10b981"
                            : g.gpa >= 2.0
                              ? "#f59e0b"
                              : "#ef4444",
                      }}
                    />
                  </div>
                  <span className="text-gray-500 text-xs w-8 text-right">
                    {g.gpa.toFixed(1)}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          {/* Target CGPA */}
          <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <TrendingUp size={16} className="text-indigo-600" /> CGPA Targets
            </h3>
            <div className="space-y-2">
              {[
                { target: 3.7, label: "Distinction (3.7)" },
                { target: 3.3, label: "Very Good (3.3)" },
                { target: 3.0, label: "Good (3.0)" },
              ].map((t) => {
                const needed = requiredForTarget(t.target);
                const achieved = overallCGPA >= t.target;
                return (
                  <div
                    key={t.target}
                    className={`rounded-xl p-3 ${achieved ? "bg-emerald-50 border border-emerald-200" : "bg-gray-50 border border-gray-200"}`}
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-700">
                        {t.label}
                      </p>
                      {achieved ? (
                        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 rounded-full">
                          ✓ Achieved
                        </Badge>
                      ) : needed !== null ? (
                        <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 rounded-full">
                          Need {needed.toFixed(2)} SGPA
                        </Badge>
                      ) : (
                        <Badge
                          variant="secondary"
                          className="text-gray-500 rounded-full"
                        >
                          Already exceeded
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Graded Assignments */}
          {gradedAssignments.length > 0 && (
            <Card className="rounded-2xl p-5 shadow-sm border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Award size={16} className="text-purple-600" /> Recent Grades
              </h3>
              <div className="space-y-2">
                {gradedAssignments.slice(0, 4).map((item, idx) => {
                  const pct = Math.round(
                    (item.marks / item.assignment.totalMarks) * 100,
                  );
                  return (
                    <div key={idx} className="flex items-center gap-3 text-sm">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0 ${pct >= 80 ? "bg-emerald-100 text-emerald-700" : pct >= 60 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}
                      >
                        {pct}%
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-gray-900 text-xs font-medium truncate">
                          {item.assignment.title}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {item.marks}/{item.assignment.totalMarks} marks
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Add Previous Semester Modal */}
      <Dialog open={showPrevModal} onOpenChange={setShowPrevModal}>
        <DialogContent className="rounded-2xl max-w-sm">
          <DialogHeader>
            <DialogTitle>Add Previous Semester</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5">Semester Number</Label>
              <Input
                type="number"
                value={newPrev.semester}
                onChange={(e) =>
                  setNewPrev((p) => ({ ...p, semester: e.target.value }))
                }
                min="1"
                className="rounded-xl"
                placeholder="e.g., 1"
              />
            </div>
            <div>
              <Label className="mb-1.5">GPA for that semester</Label>
              <Input
                type="number"
                value={newPrev.cgpa}
                onChange={(e) =>
                  setNewPrev((p) => ({ ...p, cgpa: e.target.value }))
                }
                min="0"
                max="4"
                step="0.01"
                className="rounded-xl"
                placeholder="e.g., 3.25"
              />
            </div>
            <div>
              <Label className="mb-1.5">Total Credits</Label>
              <Input
                type="number"
                value={newPrev.credits}
                onChange={(e) =>
                  setNewPrev((p) => ({ ...p, credits: e.target.value }))
                }
                min="1"
                className="rounded-xl"
                placeholder="e.g., 15"
              />
            </div>
          </div>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setShowPrevModal(false)}
              className="flex-1 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (newPrev.cgpa && newPrev.credits) {
                  setPrevSemesters((prev) => [
                    ...prev,
                    {
                      semester: parseInt(newPrev.semester) || prev.length + 1,
                      cgpa: parseFloat(newPrev.cgpa),
                      credits: parseInt(newPrev.credits),
                    },
                  ]);
                  setNewPrev({ semester: "", cgpa: "", credits: "" });
                  setShowPrevModal(false);
                }
              }}
              className="flex-1 bg-indigo-700 text-white rounded-xl hover:bg-indigo-800"
            >
              Add
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
