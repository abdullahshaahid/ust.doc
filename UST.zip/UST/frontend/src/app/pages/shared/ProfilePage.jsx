import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useData } from "../../context/DataContext";
import {
  User,
  Mail,
  Phone,
  Building2,
  BookOpen,
  Calendar,
  Edit3,
  Save,
  X,
  Shield,
  Award,
  Clock,
  GraduationCap,
  CheckCircle,
  Key,
} from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Card, CardContent } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Alert, AlertDescription } from "../../components/ui/alert";
import { Separator } from "../../components/ui/separator";

export default function ProfilePage() {
  const { currentUser } = useAuth();
  const { courses, assignments, attendanceRecords, updateUser, users } =
    useData();
  const [editing, setEditing] = useState(false);
  const [changingPwd, setChangingPwd] = useState(false);
  const [form, setForm] = useState({
    name: currentUser?.name || "",
    phone: currentUser?.phone || "",
  });
  const [pwdForm, setPwdForm] = useState({
    current: "",
    newPwd: "",
    confirm: "",
  });
  const [saved, setSaved] = useState(false);
  const [pwdError, setPwdError] = useState("");
  const [pwdSuccess, setPwdSuccess] = useState(false);

  if (!currentUser) return null;

  const roleColors = {
    admin: { bg: "bg-red-600", text: "text-red-700", light: "bg-red-50" },
    teacher: {
      bg: "bg-emerald-600",
      text: "text-emerald-700",
      light: "bg-emerald-50",
    },
    student: {
      bg: "bg-indigo-600",
      text: "text-indigo-700",
      light: "bg-indigo-50",
    },
  };
  const rc = roleColors[currentUser.role];

  // Stats based on role
  const myCourseIds =
    currentUser.role === "student"
      ? currentUser.enrolledCourses || []
      : currentUser.role === "teacher"
        ? courses.filter((c) => c.teacherId === currentUser.id).map((c) => c.id)
        : [];

  const myCourses = courses.filter((c) => myCourseIds.includes(c.id));

  const myAssignments = assignments.filter((a) =>
    myCourseIds.includes(a.courseId),
  );

  const myAttendance = attendanceRecords.filter((r) =>
    myCourseIds.includes(r.courseId),
  );
  const attended = myAttendance.filter((r) =>
    r.records.some(
      (rec) => rec.studentId === currentUser.id && rec.status !== "absent",
    ),
  ).length;
  const attendancePct =
    myAttendance.length > 0
      ? Math.round((attended / myAttendance.length) * 100)
      : 0;

  const handleSave = () => {
    const fullUser = users.find((u) => u.id === currentUser.id);
    if (fullUser)
      updateUser({ ...fullUser, name: form.name, phone: form.phone });
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handlePwdChange = () => {
    setPwdError("");
    const fullUser = users.find((u) => u.id === currentUser.id);
    if (!fullUser || fullUser.password !== pwdForm.current) {
      setPwdError("Current password is incorrect");
      return;
    }
    if (pwdForm.newPwd.length < 6) {
      setPwdError("New password must be at least 6 characters");
      return;
    }
    if (pwdForm.newPwd !== pwdForm.confirm) {
      setPwdError("Passwords do not match");
      return;
    }
    updateUser({ ...fullUser, password: pwdForm.newPwd });
    setPwdForm({ current: "", newPwd: "", confirm: "" });
    setChangingPwd(false);
    setPwdSuccess(true);
    setTimeout(() => setPwdSuccess(false), 3000);
  };

  const getInitials = (name) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

  const stats =
    currentUser.role === "student"
      ? [
          {
            label: "Enrolled Courses",
            value: myCourses.length,
            icon: <BookOpen size={18} />,
            color: "text-indigo-600 bg-indigo-50",
          },
          {
            label: "Assignments",
            value: myAssignments.length,
            icon: <CheckCircle size={18} />,
            color: "text-emerald-600 bg-emerald-50",
          },
          {
            label: "Attendance Rate",
            value: `${attendancePct}%`,
            icon: <Clock size={18} />,
            color:
              attendancePct >= 75
                ? "text-emerald-600 bg-emerald-50"
                : "text-red-600 bg-red-50",
          },
          {
            label: "Semester",
            value: currentUser.semester || 1,
            icon: <GraduationCap size={18} />,
            color: "text-amber-600 bg-amber-50",
          },
        ]
      : currentUser.role === "teacher"
        ? [
            {
              label: "Courses Teaching",
              value: myCourses.length,
              icon: <BookOpen size={18} />,
              color: "text-indigo-600 bg-indigo-50",
            },
            {
              label: "Total Students",
              value: new Set(myCourses.flatMap((c) => c.enrolledStudents)).size,
              icon: <User size={18} />,
              color: "text-emerald-600 bg-emerald-50",
            },
            {
              label: "Assignments Set",
              value: myAssignments.length,
              icon: <CheckCircle size={18} />,
              color: "text-amber-600 bg-amber-50",
            },
            {
              label: "Department",
              value: currentUser.department?.split(" ")[0] || "N/A",
              icon: <Building2 size={18} />,
              color: "text-purple-600 bg-purple-50",
            },
          ]
        : [
            {
              label: "Total Users",
              value: users.length,
              icon: <User size={18} />,
              color: "text-indigo-600 bg-indigo-50",
            },
            {
              label: "Total Courses",
              value: courses.length,
              icon: <BookOpen size={18} />,
              color: "text-emerald-600 bg-emerald-50",
            },
            {
              label: "Role",
              value: "Admin",
              icon: <Shield size={18} />,
              color: "text-red-600 bg-red-50",
            },
            {
              label: "Access Level",
              value: "Full",
              icon: <Award size={18} />,
              color: "text-amber-600 bg-amber-50",
            },
          ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-gray-900 font-bold text-2xl">My Profile</h1>
        <p className="text-gray-500 mt-1">
          Manage your personal information and account settings
        </p>
      </div>

      {/* Success banners */}
      {saved && (
        <Alert className="border-emerald-200 bg-emerald-50 text-emerald-700 rounded-xl">
          <CheckCircle size={16} />
          <AlertDescription>Profile updated successfully!</AlertDescription>
        </Alert>
      )}
      {pwdSuccess && (
        <Alert className="border-emerald-200 bg-emerald-50 text-emerald-700 rounded-xl">
          <CheckCircle size={16} />
          <AlertDescription>Password changed successfully!</AlertDescription>
        </Alert>
      )}

      {/* Profile Card */}
      <Card className="rounded-2xl shadow-sm border-gray-100 overflow-hidden">
        {/* Cover Banner */}
        <div
          className={`h-28 bg-gradient-to-r ${currentUser.role === "admin" ? "from-red-600 to-red-800" : currentUser.role === "teacher" ? "from-emerald-600 to-emerald-800" : "from-indigo-600 to-indigo-800"}`}
        />

        <div className="px-6 pb-6">
          <div className="flex items-end justify-between -mt-12 mb-4">
            {/* Avatar */}
            <div
              className={`w-24 h-24 ${rc.bg} rounded-2xl border-4 border-white flex items-center justify-center text-white text-2xl font-bold shadow-lg`}
            >
              {getInitials(currentUser.name)}
            </div>
            {/* Edit Button */}
            {!editing ? (
              <Button
                variant="secondary"
                onClick={() => setEditing(true)}
                className="rounded-xl"
              >
                <Edit3 size={15} /> Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  onClick={() => setEditing(false)}
                  className="rounded-xl"
                >
                  <X size={15} /> Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
                >
                  <Save size={15} /> Save Changes
                </Button>
              </div>
            )}
          </div>

          {editing ? (
            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              <div>
                <Label className="text-gray-700 mb-1.5">Full Name</Label>
                <Input
                  value={form.name}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, name: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label className="text-gray-700 mb-1.5">Phone Number</Label>
                <Input
                  value={form.phone}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, phone: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
            </div>
          ) : (
            <>
              <h2 className="text-gray-900 font-bold text-xl">
                {currentUser.name}
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <Badge
                  variant="secondary"
                  className={`rounded-full capitalize ${rc.light} ${rc.text}`}
                >
                  {currentUser.role}
                </Badge>
                {currentUser.department && (
                  <span className="text-gray-400 text-sm">
                    · {currentUser.department}
                  </span>
                )}
              </div>
            </>
          )}

          {/* Info Grid */}
          <div className="grid sm:grid-cols-2 gap-4 mt-5">
            <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
              <Mail size={16} className="text-gray-400 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-gray-400">Email Address</p>
                <p className="text-sm font-medium text-gray-900 truncate">
                  {currentUser.email}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
              <Phone size={16} className="text-gray-400 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-gray-400">Phone</p>
                <p className="text-sm font-medium text-gray-900">
                  {currentUser.phone || "Not set"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
              <Building2 size={16} className="text-gray-400 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-gray-400">Department</p>
                <p className="text-sm font-medium text-gray-900">
                  {currentUser.department || "Administration"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
              <Calendar size={16} className="text-gray-400 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs text-gray-400">Joined Date</p>
                <p className="text-sm font-medium text-gray-900">
                  {currentUser.joinDate
                    ? new Date(currentUser.joinDate).toLocaleDateString(
                        "en-US",
                        { month: "long", day: "numeric", year: "numeric" },
                      )
                    : "N/A"}
                </p>
              </div>
            </div>
            {currentUser.studentId && (
              <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
                <GraduationCap
                  size={16}
                  className="text-gray-400 flex-shrink-0"
                />
                <div>
                  <p className="text-xs text-gray-400">Student ID</p>
                  <p className="text-sm font-medium text-gray-900">
                    {currentUser.studentId}
                  </p>
                </div>
              </div>
            )}
            {currentUser.teacherId && (
              <div className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl">
                <Award size={16} className="text-gray-400 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-400">Faculty ID</p>
                  <p className="text-sm font-medium text-gray-900">
                    {currentUser.teacherId}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm"
          >
            <div
              className={`w-9 h-9 ${s.color} rounded-xl flex items-center justify-center mb-3`}
            >
              {s.icon}
            </div>
            <p className="text-gray-900 font-bold text-xl">{s.value}</p>
            <p className="text-gray-400 text-xs mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Change Password */}
      <Card className="rounded-2xl p-5 border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center">
              <Key size={16} className="text-gray-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-sm">
                Change Password
              </h3>
              <p className="text-gray-400 text-xs">Keep your account secure</p>
            </div>
          </div>
          {!changingPwd && (
            <Button
              variant="secondary"
              onClick={() => setChangingPwd(true)}
              className="rounded-xl"
            >
              Change
            </Button>
          )}
        </div>

        {changingPwd && (
          <div className="space-y-3">
            {pwdError && (
              <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl p-3">
                {pwdError}
              </div>
            )}
            <div className="grid sm:grid-cols-3 gap-3">
              <div>
                <Label className="text-gray-600 mb-1.5 text-xs">
                  Current Password
                </Label>
                <Input
                  type="password"
                  value={pwdForm.current}
                  onChange={(e) =>
                    setPwdForm((f) => ({ ...f, current: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label className="text-gray-600 mb-1.5 text-xs">
                  New Password
                </Label>
                <Input
                  type="password"
                  value={pwdForm.newPwd}
                  onChange={(e) =>
                    setPwdForm((f) => ({ ...f, newPwd: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
              <div>
                <Label className="text-gray-600 mb-1.5 text-xs">
                  Confirm Password
                </Label>
                <Input
                  type="password"
                  value={pwdForm.confirm}
                  onChange={(e) =>
                    setPwdForm((f) => ({ ...f, confirm: e.target.value }))
                  }
                  className="rounded-xl"
                />
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <Button
                variant="outline"
                onClick={() => {
                  setChangingPwd(false);
                  setPwdError("");
                  setPwdForm({ current: "", newPwd: "", confirm: "" });
                }}
                className="rounded-xl"
              >
                Cancel
              </Button>
              <Button
                onClick={handlePwdChange}
                className="bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl"
              >
                Update Password
              </Button>
            </div>
          </div>
        )}
      </Card>
      {myCourses.length > 0 && (
        <Card className="rounded-2xl p-5 border-gray-100 shadow-sm">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <BookOpen size={16} className="text-indigo-600" />
            {currentUser.role === "student"
              ? "Enrolled Courses"
              : "Teaching Courses"}
          </h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {myCourses.map((c) => (
              <div
                key={c.id}
                className="flex items-center gap-3 p-3.5 bg-gray-50 rounded-xl"
              >
                <div className="w-9 h-9 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BookOpen size={15} className="text-indigo-700" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {c.name}
                  </p>
                  <p className="text-xs text-gray-400">
                    {c.code} · {c.credits} credits · Sem {c.semester}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
