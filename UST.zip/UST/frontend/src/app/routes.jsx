import { createBrowserRouter, Navigate, Outlet } from 'react-router';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { ProtectedRoute } from './components/shared/ProtectedRoute';
import { DashboardLayout } from './components/layout/DashboardLayout';

// Public Pages
import HomePage from './pages/public/HomePage';
import LoginPage from './pages/auth/LoginPage';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import ManageUsers from './pages/admin/ManageUsers';
import ManageCourses from './pages/admin/ManageCourses';
import ManageEvents from './pages/admin/ManageEvents';
import ManageTimetable from './pages/admin/ManageTimetable';
import ManageRoadmap from './pages/admin/ManageRoadmap';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import ManageAnnouncements from './pages/admin/ManageAnnouncements';

// Teacher Pages
import TeacherDashboard from './pages/teacher/TeacherDashboard';
import UploadLectures from './pages/teacher/UploadLectures';
import ManageAssignments from './pages/teacher/ManageAssignments';
import AttendanceManager from './pages/teacher/AttendanceManager';
import AttendanceCalculator from './pages/teacher/AttendanceCalculator';

// Student Pages
import StudentDashboard from './pages/student/StudentDashboard';
import ViewLectures from './pages/student/ViewLectures';
import ViewAssignments from './pages/student/ViewAssignments';
import StudentTimetable from './pages/student/StudentTimetable';
import StudentAttendance from './pages/student/StudentAttendance';
import CGPACalculator from './pages/student/CGPACalculator';
import StudentRoadmap from './pages/student/StudentRoadmap';

// Shared Pages
import ProfilePage from './pages/shared/ProfilePage';

// Root layout with providers
function Root() {
  return (
    <AuthProvider>
      <DataProvider>
        <Outlet />
      </DataProvider>
    </AuthProvider>
  );
}

// Role-protected layout wrappers
function AdminLayout() {
  return (
    <ProtectedRoute roles={['admin']}>
      <DashboardLayout />
    </ProtectedRoute>
  );
}

function TeacherLayout() {
  return (
    <ProtectedRoute roles={['teacher']}>
      <DashboardLayout />
    </ProtectedRoute>
  );
}

function StudentLayout() {
  return (
    <ProtectedRoute roles={['student']}>
      <DashboardLayout />
    </ProtectedRoute>
  );
}

export const router = createBrowserRouter([
  {
    Component: Root,
    children: [
      // Public routes
      { path: '/', Component: HomePage },
      { path: '/login', Component: LoginPage },

      // Admin routes
      {
        path: '/admin',
        Component: AdminLayout,
        children: [
          { index: true, Component: AdminDashboard },
          { path: 'users', Component: ManageUsers },
          { path: 'courses', Component: ManageCourses },
          { path: 'events', Component: ManageEvents },
          { path: 'timetable', Component: ManageTimetable },
          { path: 'roadmap', Component: ManageRoadmap },
          { path: 'analytics', Component: AdminAnalytics },
          { path: 'announcements', Component: ManageAnnouncements },
          { path: 'profile', Component: ProfilePage },
        ],
      },

      // Teacher routes
      {
        path: '/teacher',
        Component: TeacherLayout,
        children: [
          { index: true, Component: TeacherDashboard },
          { path: 'lectures', Component: UploadLectures },
          { path: 'assignments', Component: ManageAssignments },
          { path: 'attendance', Component: AttendanceManager },
          { path: 'attendance-calculator', Component: AttendanceCalculator },
          { path: 'profile', Component: ProfilePage },
        ],
      },

      // Student routes
      {
        path: '/student',
        Component: StudentLayout,
        children: [
          { index: true, Component: StudentDashboard },
          { path: 'lectures', Component: ViewLectures },
          { path: 'assignments', Component: ViewAssignments },
          { path: 'timetable', Component: StudentTimetable },
          { path: 'attendance', Component: StudentAttendance },
          { path: 'cgpa', Component: CGPACalculator },
          { path: 'roadmap', Component: StudentRoadmap },
          { path: 'profile', Component: ProfilePage },
        ],
      },

      // Catch-all
      { path: '*', element: <Navigate to="/" replace /> },
    ],
  },
]);