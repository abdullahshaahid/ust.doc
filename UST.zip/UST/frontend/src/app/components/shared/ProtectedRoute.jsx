import { Navigate } from "react-router";
import { useAuth } from "../../context/AuthContext";

export function ProtectedRoute({ children, roles }) {
  const { currentUser, isAuthenticated } = useAuth();

  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && currentUser && !roles.includes(currentUser.role)) {
    const redirect =
      currentUser.role === "admin"
        ? "/admin"
        : currentUser.role === "teacher"
          ? "/teacher"
          : "/student";
    return <Navigate to={redirect} replace />;
  }

  return <>{children}</>;
}
