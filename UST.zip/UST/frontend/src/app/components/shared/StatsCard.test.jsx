import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { StatsCard } from "./StatsCard";

describe("StatsCard", () => {
  it("renders title and value", () => {
    render(<StatsCard title="Test Title" value={42} color="bg-blue-600" />);
    expect(screen.getByText("Test Title")).toBeInTheDocument();
    expect(screen.getByText("42")).toBeInTheDocument();
  });

  it("renders subtitle when provided", () => {
    render(
      <StatsCard
        title="Title"
        value={10}
        color="bg-blue-600"
        subtitle="extra info"
      />,
    );
    expect(screen.getByText("extra info")).toBeInTheDocument();
  });

  it("renders trend when provided", () => {
    render(
      <StatsCard
        title="Title"
        value={10}
        color="bg-blue-600"
        trend={{ value: 5, label: "this week" }}
      />,
    );
    expect(screen.getByText(/5%/)).toBeInTheDocument();
    expect(screen.getByText(/this week/)).toBeInTheDocument();
  });

  it("shows negative trend correctly", () => {
    render(
      <StatsCard
        title="Title"
        value={10}
        color="bg-blue-600"
        trend={{ value: -3, label: "last month" }}
      />,
    );
    expect(screen.getByText(/3%/)).toBeInTheDocument();
    expect(screen.getByText(/↓/)).toBeInTheDocument();
  });

  it("does not render subtitle when not provided", () => {
    const { container } = render(
      <StatsCard title="Title" value={10} color="bg-blue-600" />,
    );
    const subtitleElements = container.querySelectorAll(
      ".text-gray-400.text-xs",
    );
    expect(subtitleElements.length).toBe(0);
  });
});
