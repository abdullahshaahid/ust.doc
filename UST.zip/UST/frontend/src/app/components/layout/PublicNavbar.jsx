import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { GraduationCap, Menu, X, LogIn, ChevronDown } from "lucide-react";
import { Button } from "../ui/button";

export function PublicNavbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const links = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Departments", href: "#departments" },
    { label: "Events", href: "#events" },
    { label: "Gallery", href: "#gallery" },
    { label: "Faculty", href: "#faculty" },
    { label: "Roadmap", href: "#roadmap" },
    { label: "Contact", href: "#contact" },
  ];

  const scrollTo = (id) => {
    setOpen(false);
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/98 backdrop-blur-md shadow-md border-b border-gray-100"
          : "bg-white/95 backdrop-blur-sm shadow-sm border-b border-gray-100"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => navigate("/")}
          >
            <div className="w-9 h-9 bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-xl flex items-center justify-center shadow-sm">
              <GraduationCap size={20} className="text-white" />
            </div>
            <div>
              <span className="text-indigo-700 font-bold text-base leading-none block">
                UniLearn
              </span>
              <span className="text-gray-400 text-xs leading-none">
                University LMS
              </span>
            </div>
          </div>

          {/* Desktop Links */}
          <div className="hidden lg:flex items-center gap-1">
            {links.map((l) => (
              <Button
                key={l.label}
                variant="ghost"
                onClick={() => scrollTo(l.href)}
                className="text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 transition-colors text-sm px-3 py-2 rounded-lg h-auto"
              >
                {l.label}
              </Button>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Button
              onClick={() => navigate("/login")}
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-700 to-indigo-800 text-white px-5 py-2.5 rounded-xl hover:from-indigo-600 hover:to-indigo-700 transition-all text-sm shadow-sm shadow-indigo-200 h-auto"
            >
              <LogIn size={15} />
              Sign In to Portal
            </Button>
          </div>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setOpen(!open)}
          >
            {open ? (
              <X size={22} className="text-gray-700" />
            ) : (
              <Menu size={22} className="text-gray-700" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-lg">
          <div className="px-4 py-3 space-y-1">
            {links.map((l) => (
              <Button
                key={l.label}
                variant="ghost"
                onClick={() => scrollTo(l.href)}
                className="block w-full text-left text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 py-2.5 px-3 rounded-xl text-sm transition-colors justify-start h-auto"
              >
                {l.label}
              </Button>
            ))}
            <div className="pt-2 pb-1">
              <Button
                onClick={() => {
                  setOpen(false);
                  navigate("/login");
                }}
                className="w-full bg-indigo-700 text-white px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 h-auto"
              >
                <LogIn size={15} /> Sign In to Portal
              </Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
