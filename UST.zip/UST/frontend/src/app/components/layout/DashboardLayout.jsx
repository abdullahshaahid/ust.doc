import { useState, useRef, useEffect } from "react";
import { Link, useLocation, useNavigate, Outlet } from "react-router";
import {
  GraduationCap,
  LayoutDashboard,
  Users,
  BookOpen,
  Calendar,
  ClipboardList,
  BarChart2,
  UserCheck,
  LogOut,
  Menu,
  X,
  Bell,
  ChevronRight,
  Map,
  Clock,
  Calculator,
  Home,
  Award,
  Megaphone,
  Settings,
  TrendingUp,
  AlertTriangle,
  Info,
  CheckCircle,
  User,
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useData } from "../../context/DataContext";
import { Button } from "../ui/button";

const adminNav = [
  { label: "Dashboard", path: "/admin", icon: <LayoutDashboard size={18} /> },
  { label: "Manage Users", path: "/admin/users", icon: <Users size={18} /> },
  { label: "Courses", path: "/admin/courses", icon: <BookOpen size={18} /> },
  { label: "Events", path: "/admin/events", icon: <Calendar size={18} /> },
  { label: "Timetable", path: "/admin/timetable", icon: <Clock size={18} /> },
  { label: "Roadmap", path: "/admin/roadmap", icon: <Map size={18} /> },
  {
    label: "Analytics",
    path: "/admin/analytics",
    icon: <TrendingUp size={18} />,
  },
  {
    label: "Announcements",
    path: "/admin/announcements",
    icon: <Megaphone size={18} />,
  },
];

const teacherNav = [
  { label: "Dashboard", path: "/teacher", icon: <LayoutDashboard size={18} /> },
  {
    label: "Lectures",
    path: "/teacher/lectures",
    icon: <BookOpen size={18} />,
  },
  {
    label: "Assignments",
    path: "/teacher/assignments",
    icon: <ClipboardList size={18} />,
  },
  {
    label: "Attendance",
    path: "/teacher/attendance",
    icon: <UserCheck size={18} />,
  },
  {
    label: "Att. Calculator",
    path: "/teacher/attendance-calculator",
    icon: <Calculator size={18} />,
  },
];

const studentNav = [
  { label: "Dashboard", path: "/student", icon: <LayoutDashboard size={18} /> },
  {
    label: "Lectures",
    path: "/student/lectures",
    icon: <BookOpen size={18} />,
  },
  {
    label: "Assignments",
    path: "/student/assignments",
    icon: <ClipboardList size={18} />,
  },
  { label: "Timetable", path: "/student/timetable", icon: <Clock size={18} /> },
  {
    label: "Attendance",
    path: "/student/attendance",
    icon: <UserCheck size={18} />,
  },
  {
    label: "CGPA Calculator",
    path: "/student/cgpa",
    icon: <Calculator size={18} />,
  },
  { label: "Roadmap", path: "/student/roadmap", icon: <Map size={18} /> },
];

const roleConfig = {
  admin: {
    bg: "bg-rose-600",
    light: "bg-rose-50",
    text: "text-rose-700",
    border: "border-rose-200",
    gradient: "from-rose-600 to-rose-800",
    label: "Admin Portal",
    headerBg: "bg-gradient-to-r from-rose-700 to-rose-900",
  },
  teacher: {
    bg: "bg-emerald-600",
    light: "bg-emerald-50",
    text: "text-emerald-700",
    border: "border-emerald-200",
    gradient: "from-emerald-600 to-emerald-800",
    label: "Teacher Portal",
    headerBg: "bg-gradient-to-r from-emerald-700 to-emerald-900",
  },
  student: {
    bg: "bg-indigo-600",
    light: "bg-indigo-50",
    text: "text-indigo-700",
    border: "border-indigo-200",
    gradient: "from-indigo-600 to-indigo-800",
    label: "Student Portal",
    headerBg: "bg-gradient-to-r from-indigo-700 to-indigo-900",
  },
};

const priorityConfig = {
  high: {
    icon: <AlertTriangle size={13} />,
    color: "text-red-600 bg-red-50 border-red-200",
    dot: "bg-red-500",
  },
  medium: {
    icon: <Bell size={13} />,
    color: "text-amber-600 bg-amber-50 border-amber-200",
    dot: "bg-amber-500",
  },
  low: {
    icon: <Info size={13} />,
    color: "text-blue-600 bg-blue-50 border-blue-200",
    dot: "bg-blue-500",
  },
};

export function DashboardLayout() {
  const { currentUser, logout } = useAuth();
  const { announcements } = useData();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef(null);

  useEffect(() => {
    function handleClick(e) {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  if (!currentUser) return null;

  const navItems =
    currentUser.role === "admin"
      ? adminNav
      : currentUser.role === "teacher"
        ? teacherNav
        : studentNav;
  const rc = roleConfig[currentUser.role];
  const profilePath = `/${currentUser.role}/profile`;

  // Filter relevant announcements
  const myAnnouncements = announcements
    .filter(
      (a) =>
        a.isActive &&
        (a.targetRole === "all" || a.targetRole === currentUser.role),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    )
    .slice(0, 5);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const isActive = (path) => {
    if (path === "/admin" || path === "/teacher" || path === "/student")
      return location.pathname === path;
    return location.pathname.startsWith(path);
  };

  const getInitials = (name) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

  const currentPageLabel =
    navItems.find((n) => isActive(n.path))?.label ||
    (location.pathname.endsWith("/profile") ? "My Profile" : "Dashboard");

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 bg-gradient-to-br ${rc.gradient} rounded-xl flex items-center justify-center shadow-md`}
          >
            <GraduationCap size={22} className="text-white" />
          </div>
          <div>
            <p className="font-bold text-gray-900 leading-tight text-base">
              UniLearn
            </p>
            <p className="text-gray-400 text-xs capitalize">{rc.label}</p>
          </div>
        </div>
      </div>

      {/* User Card */}
      <div className="p-4 border-b border-gray-100">
        <Link
          to={profilePath}
          onClick={() => setSidebarOpen(false)}
          className={`flex items-center gap-3 p-3 rounded-xl ${rc.light} ${rc.border} border hover:opacity-90 transition-opacity`}
        >
          <div
            className={`w-10 h-10 bg-gradient-to-br ${rc.gradient} rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0 shadow-sm`}
          >
            {getInitials(currentUser.name)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-gray-900 text-sm truncate">
              {currentUser.name}
            </p>
            <p className={`text-xs ${rc.text} capitalize`}>
              {currentUser.role}
            </p>
            {currentUser.department && (
              <p className="text-xs text-gray-400 truncate">
                {currentUser.department}
              </p>
            )}
          </div>
          <User size={14} className="text-gray-400 flex-shrink-0" />
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => setSidebarOpen(false)}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm group relative ${
              isActive(item.path)
                ? `bg-gradient-to-r ${rc.gradient} text-white shadow-md`
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}
          >
            <span
              className={
                isActive(item.path)
                  ? "text-white"
                  : `${rc.text} group-hover:text-gray-900`
              }
            >
              {item.icon}
            </span>
            <span className="flex-1">{item.label}</span>
            {item.badge && item.badge > 0 && (
              <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {item.badge}
              </span>
            )}
            {isActive(item.path) && (
              <ChevronRight size={14} className="text-white/70" />
            )}
          </Link>
        ))}
      </nav>

      {/* Divider with label */}
      <div className="px-4 py-2">
        <p className="text-xs text-gray-400 uppercase tracking-wider">
          Account
        </p>
      </div>

      {/* Bottom Actions */}
      <div className="p-3 border-t border-gray-100 space-y-0.5">
        <Link
          to={profilePath}
          onClick={() => setSidebarOpen(false)}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition-colors"
        >
          <User size={18} className="text-gray-400" />
          <span>My Profile</span>
        </Link>
        <Link
          to="/"
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition-colors"
        >
          <Home size={18} className="text-gray-400" />
          <span>Homepage</span>
        </Link>
        <Button
          variant="ghost"
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-red-600 hover:bg-red-50 transition-colors justify-start h-auto"
        >
          <LogOut size={18} />
          <span>Logout</span>
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-gray-100 shadow-sm flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="relative z-10 w-72 bg-white h-full shadow-2xl">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-gray-100 hover:bg-gray-200"
              onClick={() => setSidebarOpen(false)}
            >
              <X size={18} />
            </Button>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-100 px-4 h-16 flex items-center justify-between flex-shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={20} className="text-gray-600" />
            </Button>
            <div className="hidden sm:block">
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <span className="capitalize">{currentUser.role}</span>
                <ChevronRight size={14} />
                <span className="text-gray-900 font-semibold">
                  {currentPageLabel}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Notification Bell */}
            <div className="relative" ref={notifRef}>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setNotifOpen(!notifOpen)}
                className="p-2 rounded-xl hover:bg-gray-100 text-gray-500 relative transition-colors"
              >
                <Bell size={19} />
                {myAnnouncements.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white" />
                )}
              </Button>

              {/* Notification Dropdown */}
              {notifOpen && (
                <div className="absolute right-0 top-12 w-80 bg-white rounded-2xl shadow-xl border border-gray-100 z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="font-semibold text-gray-900 text-sm">
                      Announcements
                    </h3>
                    <span className="bg-indigo-100 text-indigo-700 text-xs font-medium px-2 py-0.5 rounded-full">
                      {myAnnouncements.length} new
                    </span>
                  </div>
                  {myAnnouncements.length === 0 ? (
                    <div className="py-8 text-center">
                      <CheckCircle
                        size={24}
                        className="text-gray-300 mx-auto mb-2"
                      />
                      <p className="text-gray-400 text-sm">No announcements</p>
                    </div>
                  ) : (
                    <div className="max-h-80 overflow-y-auto divide-y divide-gray-50">
                      {myAnnouncements.map((ann) => {
                        const pc = priorityConfig[ann.priority];
                        return (
                          <div
                            key={ann.id}
                            className="px-4 py-3 hover:bg-gray-50 transition-colors"
                          >
                            <div className="flex items-start gap-2">
                              <div
                                className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${pc.dot}`}
                              />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 leading-tight">
                                  {ann.title}
                                </p>
                                <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">
                                  {ann.content}
                                </p>
                                <p className="text-xs text-gray-400 mt-1">
                                  {new Date(ann.createdAt).toLocaleDateString(
                                    "en-US",
                                    { month: "short", day: "numeric" },
                                  )}
                                </p>
                              </div>
                              <span
                                className={`flex items-center gap-1 px-1.5 py-0.5 rounded-md text-xs border flex-shrink-0 ${pc.color}`}
                              >
                                {pc.icon}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Avatar */}
            <Link
              to={profilePath}
              className={`w-9 h-9 bg-gradient-to-br ${rc.gradient} rounded-full flex items-center justify-center text-white text-xs font-bold hover:opacity-90 transition-opacity shadow-sm`}
            >
              {getInitials(currentUser.name)}
            </Link>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
