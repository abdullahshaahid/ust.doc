# Frontend Backend Connection Setup Guide

## 🔌 Connection Overview

Your frontend is now fully connected to the Express.js + SQLite backend via API calls. All data operations are now synchronized with the backend database.

## 🚀 Quick Start

### 1. Backend Setup (if not done)

```bash
cd backend
npm install
npm run init-db
npm start
```

Backend will run at: `http://localhost:3000`

### 2. Frontend Environment Configuration

The `.env` file is already configured:

```env
VITE_API_URL=http://localhost:3000/api
```

If you need to change the backend URL:
- Edit `.env` and `.env.local`
- Restart the frontend dev server

### 3. Install Frontend Dependencies

```bash
npm install
```

This includes the new `axios` dependency for API calls.

### 4. Start Frontend Development Server

```bash
npm run dev
```

Frontend will run at: `http://localhost:5173` (Vite default)

## 🤝 How Frontend & Backend Communicate

### API Client Setup

The frontend uses an axios-based API client located at [src/lib/api.ts](src/lib/api.ts) which:

- **Base URL**: `http://localhost:3000/api`
- **Auto-attaches JWT token** from localStorage to all requests
- **Handles 401 errors** (token expiry) by clearing auth and redirecting to login
- **Provides pre-built functions** for all API endpoints

### Example API Usage

```typescript
// In any component
import { courseApi, userApi } from '../../lib/api';

// Fetch all courses
const courses = await courseApi.getAllCourses();

// Create a course
await courseApi.createCourse({
  id: 'cs102',
  name: 'Web Development',
  code: 'CS102',
  teacherId: 'teacher1',
  department: 'Computer Science',
  credits: 3,
  semester: 2,
  description: 'Learn web development'
});
```

## 🔐 Authentication Flow

### Login Process

1. User enters email and password on LoginPage
2. `login()` from AuthContext calls `authApi.login()`
3. Backend validates and returns JWT token + user data
4. Frontend stores token in `localStorage.auth_token`
5. User is redirected to their dashboard (admin/teacher/student)
6. Token is automatically attached to all subsequent requests

### Token Management

- **Storage**: JWT token stored in `localStorage.auth_token`
- **Attachment**: Automatically added via axios interceptor
- **Expiry**: 24 hours (backend config)
- **Refresh**: Manual refresh available, auto-logout on 401

### Logout

```typescript
const { logout } = useAuth();
logout(); // Clears token and user data
```

## 📊 Data Context Integration

### How DataContext Fetches Data

All data is now fetched from the backend on app load:

```typescript
import { useData } from '../../context/DataContext';

const MyComponent = () => {
  const { courses, assignments, isLoading } = useData();

  if (isLoading) return <div>Loading...</div>;
  
  return (
    <div>
      {courses.map(course => (
        <div key={course.id}>{course.name}</div>
      ))}
    </div>
  );
};
```

### Available Data & Operations

```typescript
const {
  // Data
  users,
  courses,
  lectures,
  assignments,
  attendanceRecords,
  events,
  roadmap,
  timetable,
  announcements,

  // States
  isLoading,        // Initial data load
  isSyncing,        // Operation in progress

  // Methods (all async)
  addCourse,
  updateCourse,
  deleteCourse,
  enrollStudentInCourse,
  unenrollStudentFromCourse,
  
  // ... and many more operations

  // Refresh all data from backend
  refetchAll,
} = useData();
```

## 🔄 Example: Creating a Course

### Frontend Component

```typescript
import { useState } from 'react';
import { useData } from '../../context/DataContext';

export const CreateCourseForm = () => {
  const { addCourse, isSyncing } = useData();
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    code: '',
    teacherId: 'teacher1',
    department: 'Computer Science',
    credits: 3,
    semester: 1,
    description: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addCourse(formData);
      alert('Course created successfully!');
      setFormData({...}); // Reset form
    } catch (error) {
      alert('Error: ' + error.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        value={formData.name}
        onChange={(e) => setFormData({...formData, name: e.target.value})}
        placeholder="Course name"
      />
      <button disabled={isSyncing} type="submit">
        {isSyncing ? 'Creating...' : 'Create Course'}
      </button>
    </form>
  );
};
```

### What Happens Behind the Scenes

1. User submits form
2. `addCourse()` calls `courseApi.createCourse(data)`
3. Axios sends POST request to `/api/courses` with JWT token
4. Backend validates and saves to SQLite database
5. Backend returns success response
6. DataContext calls `refetchAll()` to sync latest data
7. Component state updates, UI refreshes
8. User sees new course in the list

## 🧪 Testing the Connection

### 1. Check Backend is Running

```bash
curl http://localhost:3000/
```

Should return:
```json
{
  "message": "🎓 UniversityLearn Backend API",
  "version": "1.0.0",
  "status": "active"
}
```

### 2. Test Frontend API Connection

Navigate to browser console and run:

```javascript
// Check if token is stored
console.log(localStorage.getItem('auth_token'));

// Make a test API call
import { courseApi } from './src/lib/api';
const courses = await courseApi.getAllCourses();
console.log(courses);
```

### 3. Login with Demo Account

Use credentials:
- **Email**: `admin@university.edu`
- **Password**: `admin123`

Should successfully log in and show dashboard.

## 🐛 Troubleshooting

### API Connection Failed

**Problem**: "Failed to connect to backend"

**Solutions**:
- Check backend is running: `npm start` in backend folder
- Verify port 3000 is not blocked
- Check `.env` file has correct `VITE_API_URL`
- Check backend console for errors

### 401 Unauthorized

**Problem**: All API requests return 401

**Solutions**:
- Token expired - log in again
- Check localStorage has `auth_token` key
- Backend might be restarted - frontend needs to re-login

### CORS Error

**Problem**: "Access to XMLHttpRequest has been blocked by CORS policy"

**Solutions**:
- Backend has CORS enabled - check `main.js` imports cors
- Verify frontend URL matches backend CORS config
- Restart both servers

### Login Fails but Credentials are Correct

**Problem**: Invalid email or password

**Solutions**:
- Check database was seeded: `npm run init-db`
- Verify backend is using SQLite at `backend/university.db`
- Check backend console for error messages
- Try demo credentials

## 🗂️ File Structure

**Frontend API Integration Files**:
```
frontend/
├── .env                          # API URL config
├── .env.local                    # Local overrides
├── src/
│   ├── lib/
│   │   └── api.ts               # API client with all endpoints
│   └── app/
│       ├── context/
│       │   ├── AuthContext.tsx   # Updated to use backend
│       │   └── DataContext.tsx   # Updated to use backend
│       └── pages/
│           └── auth/
│               └── LoginPage.tsx # Updated for async login
```

## 🔄 Data Sync Flow

```
┌─────────────────────────────────────────┐
│ User Action (e.g., Create Course)       │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ Component calls useData().addCourse()   │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ API Client (axios) sends POST request   │
│ with JWT token in Authorization header  │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ Backend receives, validates & saves to  │
│ SQLite database                         │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ Backend returns success response        │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ DataContext calls refetchAll()          │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ All data re-fetched from backend        │
└────────────┬────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────┐
│ Component state updates, UI re-renders  │
└─────────────────────────────────────────┘
```

## 📚 API Reference

All API functions are organized by resource in `src/lib/api.ts`:

- `authApi.*` - Authentication
- `userApi.*` - User management
- `courseApi.*` - Courses
- `lectureApi.*` - Lectures
- `assignmentApi.*` - Assignments
- `announcementApi.*` - Announcements
- `eventApi.*` - Events
- `attendanceApi.*` - Attendance
- `timetableApi.*` - Timetables
- `roadmapApi.*` - Learning paths
- `analyticsApi.*` - Dashboard stats
- `gradesApi.*` - Grades and CGPA
- `filesApi.*` - File management

See also: [Backend README](../backend/README.md) for complete endpoint documentation.

## 🎯 Next Steps

1. ✅ Backend running at `http://localhost:3000`
2. ✅ Frontend running at `http://localhost:5173`
3. ✅ API client configured
4. ✅ AuthContext updated
5. ✅ DataContext updated

**Now test the full system:**

```bash
# Terminal 1: Backend
cd backend && npm start

# Terminal 2: Frontend
cd frontend && npm run dev
```

Visit `http://localhost:5173` and log in with demo credentials!

## 📝 Notes

- All API calls include automatic JWT authentication
- Token expires after 24 hours (backend setting)
- Data is automatically synced after all operations
- Loading states available: `isLoading` and `isSyncing`
- Errors are caught and can be displayed to users

## ✨ Features Now Enabled

✅ Real-time data synchronization with SQLite backend
✅ Secure JWT-based authentication
✅ Role-based access control
✅ Automatic offline data caching (localStorage)
✅ Error handling and retry logic
✅ Optimistic UI updates
✅ Real-time analytics from backend
