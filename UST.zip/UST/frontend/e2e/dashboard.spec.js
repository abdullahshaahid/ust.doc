import { test, expect } from "@playwright/test";

// Helper to login as a specific role
async function loginAs(page, role) {
  const creds = {
    student: { email: "alice@student.edu", password: "student123" },
    teacher: { email: "john.smith@university.edu", password: "teacher123" },
    admin: { email: "admin@university.edu", password: "admin123" },
  };

  await page.goto("/login");
  await page.getByPlaceholder(/email/i).fill(creds[role].email);
  await page.getByPlaceholder(/password/i).fill(creds[role].password);
  await page.getByRole("button", { name: /sign in/i }).click();
  await page.waitForURL(`**/${role}`, { timeout: 10000 });
}

test.describe("Student Dashboard", () => {
  test.beforeEach(async ({ page }) => {
    await loginAs(page, "student");
  });

  test("displays enrolled courses stats", async ({ page }) => {
    await expect(page.getByText("Courses").first()).toBeVisible();
  });

  test("shows welcome message with student name", async ({ page }) => {
    await expect(page.getByText("Alice Johnson").first()).toBeVisible();
    await expect(page.getByText(/welcome back/i).first()).toBeVisible();
  });
});

test.describe("Student Navigation", () => {
  test.beforeEach(async ({ page }) => {
    await loginAs(page, "student");
  });

  test("can navigate to lectures page", async ({ page }) => {
    await page.getByRole("link", { name: /Lectures/i }).click();
    await page.waitForURL("**/student/lectures");
  });

  test("can navigate to assignments page", async ({ page }) => {
    await page.getByRole("link", { name: /Assignments/i }).click();
    await page.waitForURL("**/student/assignments");
  });

  test("can navigate to timetable page", async ({ page }) => {
    await page.getByRole("link", { name: /Timetable/i }).click();
    await page.waitForURL("**/student/timetable");
  });

  test("can navigate to attendance page", async ({ page }) => {
    await page.getByRole("link", { name: /Attendance/i }).click();
    await page.waitForURL("**/student/attendance");
  });

  test("can navigate to CGPA calculator", async ({ page }) => {
    await page.getByRole("link", { name: /CGPA Calculator/i }).click();
    await page.waitForURL("**/student/cgpa");
  });

  test("can navigate to roadmap", async ({ page }) => {
    await page.getByRole("link", { name: /Roadmap/i }).click();
    await page.waitForURL("**/student/roadmap");
  });
});

test.describe("Teacher Dashboard", () => {
  test.beforeEach(async ({ page }) => {
    await loginAs(page, "teacher");
  });

  test("shows teacher name and dashboard", async ({ page }) => {
    await expect(page.getByText("Dr. John Smith").first()).toBeVisible();
  });

  test("can navigate to lectures management", async ({ page }) => {
    await page.getByRole("link", { name: /Lectures/i }).click();
    await page.waitForURL("**/teacher/lectures");
  });

  test("can navigate to assignments management", async ({ page }) => {
    await page.getByRole("link", { name: /Assignments/i }).click();
    await page.waitForURL("**/teacher/assignments");
  });

  test("can navigate to attendance management", async ({ page }) => {
    await page
      .getByRole("link", { name: /Attendance/i })
      .first()
      .click();
    await page.waitForURL("**/teacher/attendance");
  });
});

test.describe("Admin Dashboard", () => {
  test.beforeEach(async ({ page }) => {
    await loginAs(page, "admin");
  });

  test("shows admin dashboard with stats", async ({ page }) => {
    await expect(page.getByText("Dr. Richard Clark").first()).toBeVisible();
  });

  test("can navigate to manage users", async ({ page }) => {
    await page.getByRole("link", { name: /Manage Users/i }).click();
    await page.waitForURL("**/admin/users");
  });

  test("can navigate to manage courses", async ({ page }) => {
    await page.getByRole("link", { name: /Courses/i }).click();
    await page.waitForURL("**/admin/courses");
  });

  test("can navigate to events", async ({ page }) => {
    await page.getByRole("link", { name: /Events/i }).click();
    await page.waitForURL("**/admin/events");
  });

  test("can navigate to analytics", async ({ page }) => {
    await page.getByRole("link", { name: /Analytics/i }).click();
    await page.waitForURL("**/admin/analytics");
  });
});

test.describe("Logout", () => {
  test("student can logout", async ({ page }) => {
    await loginAs(page, "student");
    await page.getByRole("button", { name: /log\s*out/i }).click();
    await page.waitForURL("**/login");
    await expect(page.getByPlaceholder(/email/i)).toBeVisible();
  });
});
