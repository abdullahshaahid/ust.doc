import { test, expect } from "@playwright/test";

test.describe("Authentication Flow", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/login");
  });

  test("shows login page with form fields", async ({ page }) => {
    await expect(page.getByPlaceholder(/email/i)).toBeVisible();
    await expect(page.getByPlaceholder(/password/i)).toBeVisible();
  });

  test("shows demo account buttons", async ({ page }) => {
    await expect(
      page.getByRole("button", { name: /Admin.*Full system control/i }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: /Teacher.*Lecture/i }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: /Student.*Academic/i }),
    ).toBeVisible();
  });

  test("student can login and see dashboard", async ({ page }) => {
    await page.getByPlaceholder(/email/i).fill("alice@student.edu");
    await page.getByPlaceholder(/password/i).fill("student123");
    await page.getByRole("button", { name: /sign in/i }).click();

    await page.waitForURL("**/student");
    await expect(page.getByText("Alice Johnson").first()).toBeVisible();
  });

  test("teacher can login and see dashboard", async ({ page }) => {
    await page.getByPlaceholder(/email/i).fill("john.smith@university.edu");
    await page.getByPlaceholder(/password/i).fill("teacher123");
    await page.getByRole("button", { name: /sign in/i }).click();

    await page.waitForURL("**/teacher");
    await expect(page.getByText("Dr. John Smith").first()).toBeVisible();
  });

  test("admin can login and see dashboard", async ({ page }) => {
    await page.getByPlaceholder(/email/i).fill("admin@university.edu");
    await page.getByPlaceholder(/password/i).fill("admin123");
    await page.getByRole("button", { name: /sign in/i }).click();

    await page.waitForURL("**/admin");
    await expect(page.getByText("Dr. Richard Clark").first()).toBeVisible();
  });

  test("shows error on invalid credentials", async ({ page }) => {
    const emailInput = page.getByPlaceholder(/email/i);
    const passwordInput = page.getByPlaceholder(/password/i);

    await emailInput.fill("wrong@test.com");
    await passwordInput.fill("wrongpassword");

    await page.getByRole("button", { name: /sign in/i }).click();

    // The 401 response triggers the axios interceptor which redirects back to /login.
    // Verify user stays on the login page (not redirected to a dashboard).
    await page.waitForURL("**/login", { timeout: 10000 });
    await expect(page.getByPlaceholder(/email/i)).toBeVisible();
  });

  test("clicking demo student button fills credentials", async ({ page }) => {
    await page.getByRole("button", { name: /Student.*Academic/i }).click();

    await expect(page.getByPlaceholder(/email/i)).toHaveValue(
      "alice@student.edu",
    );
    await expect(page.getByPlaceholder(/password/i)).toHaveValue("student123");
  });
});
