# UniversityLearn Frontend

The React single-page application for the UniversityLearn university management system. Built with **React 18**, **Vite**, and **TailwindCSS 4**, it provides role-based dashboards for admins, teachers, and students, a public-facing homepage, and full CRUD interfaces for every resource the backend exposes.

## Table of Contents

- [How It Works](#how-it-works)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [NPM Scripts](#npm-scripts)
- [Entry Points](#entry-points)
- [Routing](#routing)
- [Authentication — AuthContext](#authentication--authcontext)
- [Data Management — DataContext](#data-management--datacontext)
- [API Client — src/lib/api.js](#api-client--srclibapijs)
- [Layout Components](#layout-components)
- [Pages — By Role](#pages--by-role)
- [Shared Components](#shared-components)
- [Styling](#styling)
- [Testing](#testing)
- [Environment Variables](#environment-variables)
- [Connecting to the Backend](#connecting-to-the-backend)
- [Troubleshooting](#troubleshooting)

---

## How It Works

1. **Vite** serves the app in development (port 5173) and bundles it for production. The config loads the React and TailwindCSS plugins and sets up a `@` path alias to `./src`.
2. **`index.html`** is the single HTML file. It contains a `<div id="root">` and loads `src/main.jsx`.
3. **`main.jsx`** renders the root `<App />` component into the DOM.
4. **`App.jsx`** creates a `RouterProvider` from React Router, which reads the route tree defined in `routes.jsx`.
5. **`routes.jsx`** wraps all routes in `AuthProvider` → `DataProvider`, then defines three protected route groups (`/admin/*`, `/teacher/*`, `/student/*`) and two public routes (`/` and `/login`). Each group enforces its role through a `ProtectedRoute` wrapper.
6. On mount, **`AuthContext`** checks `localStorage` for a saved token and user. If found, the user is automatically logged in. Otherwise they see the public homepage or login page.
7. Once authenticated, **`DataContext`** fetches all data from the backend in parallel (users, courses, lectures, assignments, attendance, events, roadmap, timetable, announcements, enrollments), enriches the raw data (adds enrolled students to courses, enrolled courses to users, submissions to assignments, groups attendance records), and exposes it plus CRUD methods to every component via React context.
8. Every CRUD operation in `DataContext` calls the corresponding function in **`src/lib/api.js`**, which uses an Axios instance with automatic JWT attachment and 401 handling.

---

## Project Structure

```
frontend/
├── index.html                        # HTML shell — single <div id="root">
├── package.json                      # Dependencies & npm scripts
├── vite.config.js                    # Vite + React + TailwindCSS plugin config
├── postcss.config.mjs                # PostCSS config
├── playwright.config.js              # Playwright E2E config
├── BACKEND_CONNECTION.md             # Integration guide for the backend API
│
├── src/
│   ├── main.jsx                      # React DOM entry — renders <App />
│   │
│   ├── app/
│   │   ├── App.jsx                   # Root component — creates RouterProvider
│   │   ├── routes.jsx                # Full route tree with role-based protection
│   │   │
│   │   ├── context/
│   │   │   ├── AuthContext.jsx       # Authentication state, login/logout, session restore
│   │   │   └── DataContext.jsx       # All app data + CRUD operations via backend API
│   │   │
│   │   ├── components/
│   │   │   ├── layout/
│   │   │   │   ├── DashboardLayout.jsx   # Sidebar + topbar layout for authenticated pages
│   │   │   │   └── PublicNavbar.jsx      # Navigation bar for the public homepage
│   │   │   ├── shared/
│   │   │   │   ├── ProtectedRoute.jsx    # Role-based route guard
│   │   │   │   └── StatsCard.jsx         # Reusable statistic display card
│   │   │   ├── figma/
│   │   │   │   └── ImageWithFallback.jsx # Image with broken-image placeholder
│   │   │   └── ui/                       # Radix UI primitives (button, dialog, card, etc.)
│   │   │
│   │   └── pages/
│   │       ├── auth/
│   │       │   └── LoginPage.jsx         # Login form with demo account quick-login buttons
│   │       ├── public/
│   │       │   └── HomePage.jsx          # Public landing page (hero, stats, departments, etc.)
│   │       ├── admin/                    # 8 admin pages (see Pages section)
│   │       ├── teacher/                  # 5 teacher pages
│   │       ├── student/                  # 7 student pages
│   │       └── shared/
│   │           └── ProfilePage.jsx       # Profile editor shared across all roles
│   │
│   ├── lib/
│   │   └── api.js                    # Axios-based API client with JWT interceptor
│   │
│   ├── data/
│   │   └── homepage.json             # Static fallback for homepage content
│   │
│   ├── styles/
│   │   ├── index.css                 # Master stylesheet — imports all sub-files
│   │   ├── tailwind.css              # TailwindCSS directives and source scanning
│   │   ├── theme.css                 # CSS custom properties (colors, radius, dark mode)
│   │   └── fonts.css                 # Reserved for custom font imports
│   │
│   └── test/
│       ├── setup.js                  # Imports @testing-library/jest-dom matchers
│       ├── AuthContext.test.jsx      # Unit tests for AuthContext
│       ├── DataContext.test.jsx      # Unit tests for DataContext
│       ├── LoginPage.test.jsx        # Unit tests for LoginPage
│       ├── ProtectedRoute.test.jsx   # Unit tests for ProtectedRoute
│       └── StudentDashboard.test.jsx # Unit tests for StudentDashboard
│
├── e2e/
│   ├── auth.spec.js                  # Playwright: login/logout flows
│   └── dashboard.spec.js            # Playwright: dashboard interactions
│
└── test-results/                     # Playwright output (screenshots on failure)
```

---

## Getting Started

```bash
cd frontend
npm install       # install React, Vite, TailwindCSS, Axios, Radix UI, etc.
npm run dev       # start the dev server on http://localhost:5173
```

The backend must be running at `http://localhost:3000` for data to load. See the [root README](../README.md) for full setup.

---

## NPM Scripts

| Script       | Command           | Purpose                                    |
| ------------ | ----------------- | ------------------------------------------ |
| `dev`        | `vite`            | Start Vite dev server with hot reload      |
| `build`      | `vite build`      | Create optimized production build in dist/ |
| `test`       | `vitest run`      | Run unit tests once                        |
| `test:watch` | `vitest`          | Run unit tests in watch mode               |
| `test:e2e`   | `playwright test` | Run Playwright end-to-end tests            |

---

## Entry Points

### index.html

A minimal HTML file with a viewport meta tag, the page title "University Learning Management System", a single `<div id="root"></div>`, and a script tag pointing to `src/main.jsx`.

### main.jsx

```jsx
createRoot(document.getElementById("root")).render(<App />);
```

Imports global styles from `styles/index.css` and renders the `<App />` component.

### App.jsx

Creates a `RouterProvider` from React Router using the route tree from `routes.jsx`. This is the only thing it does — all context providers are set up inside the route tree itself.

---

## Routing

All routes are defined in `routes.jsx`. The root `<Root>` component wraps everything with `<AuthProvider>` then `<DataProvider>`, making auth and data available everywhere.

### Route Map

| Path                             | Component            | Access       |
| -------------------------------- | -------------------- | ------------ |
| `/`                              | HomePage             | Public       |
| `/login`                         | LoginPage            | Public       |
| **Admin** (`/admin`)             |                      |              |
| `/admin`                         | AdminDashboard       | Admin only   |
| `/admin/users`                   | ManageUsers          | Admin only   |
| `/admin/courses`                 | ManageCourses        | Admin only   |
| `/admin/events`                  | ManageEvents         | Admin only   |
| `/admin/timetable`               | ManageTimetable      | Admin only   |
| `/admin/roadmap`                 | ManageRoadmap        | Admin only   |
| `/admin/analytics`               | AdminAnalytics       | Admin only   |
| `/admin/announcements`           | ManageAnnouncements  | Admin only   |
| `/admin/profile`                 | ProfilePage          | Admin only   |
| **Teacher** (`/teacher`)         |                      |              |
| `/teacher`                       | TeacherDashboard     | Teacher only |
| `/teacher/lectures`              | UploadLectures       | Teacher only |
| `/teacher/assignments`           | ManageAssignments    | Teacher only |
| `/teacher/attendance`            | AttendanceManager    | Teacher only |
| `/teacher/attendance-calculator` | AttendanceCalculator | Teacher only |
| `/teacher/profile`               | ProfilePage          | Teacher only |
| **Student** (`/student`)         |                      |              |
| `/student`                       | StudentDashboard     | Student only |
| `/student/lectures`              | ViewLectures         | Student only |
| `/student/assignments`           | ViewAssignments      | Student only |
| `/student/timetable`             | StudentTimetable     | Student only |
| `/student/attendance`            | StudentAttendance    | Student only |
| `/student/cgpa`                  | CGPACalculator       | Student only |
| `/student/roadmap`               | StudentRoadmap       | Student only |
| `/student/profile`               | ProfilePage          | Student only |

### How Protection Works

Each role group is wrapped in a layout component (e.g., `AdminLayout`) that renders a `ProtectedRoute`:

- If the user is **not authenticated**, they are redirected to `/login`.
- If the user is **authenticated but the wrong role**, they are redirected to their own dashboard (`/admin`, `/teacher`, or `/student`).
- Otherwise the child page renders normally.

---

## Authentication — AuthContext

`AuthContext.jsx` provides authentication state and methods to every component in the app.

### State

| Field             | Type           | Description                             |
| ----------------- | -------------- | --------------------------------------- |
| `currentUser`     | object or null | The logged-in user's data               |
| `isLoading`       | boolean        | True while a login request is in flight |
| `isAuthenticated` | boolean        | Derived: `!!currentUser`                |

### Methods

| Method                   | Description                                                                                          |
| ------------------------ | ---------------------------------------------------------------------------------------------------- |
| `login(email, password)` | Calls `authApi.login()`, stores the token and user in `localStorage`, returns `{ success, message }` |
| `logout()`               | Clears `localStorage` keys (`auth_token`, `current_user`), sets `currentUser` to null                |

### Session Restore

On mount, the context checks `localStorage` for a saved `auth_token` and `current_user`. If both exist, the user is restored without hitting the backend, so refreshing the page does not log the user out.

### localStorage Keys

| Key            | Value                        |
| -------------- | ---------------------------- |
| `auth_token`   | The JWT string               |
| `current_user` | JSON-stringified user object |

---

## Data Management — DataContext

`DataContext.jsx` is the central state store for all application data. It fetches data from the backend on mount, enriches it, and provides CRUD methods.

### State

| Field               | Type    | Description                                               |
| ------------------- | ------- | --------------------------------------------------------- |
| `users`             | array   | All user records, enriched with `enrolledCourses`         |
| `courses`           | array   | All courses, enriched with `enrolledStudents`             |
| `lectures`          | array   | All lectures                                              |
| `assignments`       | array   | All assignments, enriched with `submissions`              |
| `attendanceRecords` | array   | Attendance grouped by `{ courseId, date, records }`       |
| `events`            | array   | All events                                                |
| `roadmap`           | array   | Roadmap items with parsed `courses` and `outcomes` arrays |
| `timetable`         | array   | All timetable entries                                     |
| `announcements`     | array   | All announcements                                         |
| `enrollments`       | array   | All enrollment records                                    |
| `isLoading`         | boolean | True during initial data fetch                            |
| `isSyncing`         | boolean | True during any CRUD operation                            |

### Data Enrichment

After fetching raw data, the context enriches it before storing:

- **Users** get an `enrolledCourses` array (derived from enrollments).
- **Courses** get an `enrolledStudents` array.
- **Assignments** get a `submissions` array (from the submissions endpoint).
- **Attendance** is grouped from flat records into `{ courseId, date, records: [{ studentId, status }] }` objects.
- **Roadmap** items have their `skills` field parsed into a `courses` array and `resources` parsed into an `outcomes` array.

### CRUD Methods

Every method calls the backend API, then runs `refetchAll()` to re-fetch and re-enrich all data:

| Category      | Methods                                                                                           |
| ------------- | ------------------------------------------------------------------------------------------------- |
| Users         | `addUser`, `updateUser`, `deleteUser`                                                             |
| Courses       | `addCourse`, `updateCourse`, `deleteCourse`, `enrollStudentInCourse`, `unenrollStudentFromCourse` |
| Lectures      | `addLecture`, `updateLecture`, `deleteLecture`                                                    |
| Assignments   | `addAssignment`, `updateAssignment`, `deleteAssignment`, `submitAssignment`, `gradeSubmission`    |
| Attendance    | `addAttendance`, `updateAttendance`, `deleteAttendance` (handles single and batch records)        |
| Events        | `addEvent`, `updateEvent`, `deleteEvent`, `registerForEvent`, `unregisterFromEvent`               |
| Roadmap       | `addRoadmapItem`, `updateRoadmapItem`, `deleteRoadmapItem`                                        |
| Timetable     | `addTimetableEntry`, `updateTimetableEntry`, `deleteTimetableEntry`                               |
| Announcements | `addAnnouncement`, `updateAnnouncement`, `deleteAnnouncement`                                     |
| Utility       | `refetchAll()` — re-fetches everything from the backend in parallel                               |

### Usage

```jsx
import { useData } from "../../context/DataContext";

function MyComponent() {
  const { courses, addCourse, isLoading } = useData();

  if (isLoading) return <div>Loading...</div>;

  return courses.map((c) => <div key={c.id}>{c.name}</div>);
}
```

---

## API Client — src/lib/api.js

A centralized Axios instance that all API calls go through.

### Configuration

- **Base URL**: reads `VITE_API_URL` from environment (defaults to `http://localhost:3000/api`).
- **Request interceptor**: attaches `Authorization: Bearer <token>` from `localStorage.auth_token` to every request.
- **Response interceptor**: on a 401 response, clears auth data from `localStorage` and redirects to `/login`.

### API Modules

Each module groups related endpoint functions:

| Module            | Functions                                                                                                                                                                                                                                  |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `authApi`         | `login`, `logout`, `getCurrentUser`, `register`, `refreshToken`                                                                                                                                                                            |
| `userApi`         | `getAllUsers`, `getUserById`, `getUsersByRole`, `getUsersByDepartment`, `createUser`, `updateUser`, `deleteUser`                                                                                                                           |
| `courseApi`       | `getAllCourses`, `getCourseById`, `getCoursesByTeacher`, `getCoursesByStudent`, `getCourseStudents`, `createCourse`, `updateCourse`, `deleteCourse`, `enrollStudent`, `unenrollStudent`                                                    |
| `lectureApi`      | `getAllLectures`, `getLectureById`, `getLecturesByCourse`, `createLecture`, `updateLecture`, `deleteLecture`, `trackDownload`                                                                                                              |
| `assignmentApi`   | `getAllAssignments`, `getAssignmentById`, `getAssignmentsByCourse`, `getAssignmentsByStudent`, `createAssignment`, `updateAssignment`, `deleteAssignment`, `submitAssignment`, `getSubmissions`, `getStudentSubmission`, `gradeSubmission` |
| `announcementApi` | `getAllAnnouncements`, `getAnnouncementById`, `getAnnouncementsByRole`, `createAnnouncement`, `updateAnnouncement`, `updateAnnouncementStatus`, `deleteAnnouncement`                                                                       |
| `eventApi`        | `getAllEvents`, `getEventById`, `getEventsByType`, `createEvent`, `updateEvent`, `deleteEvent`, `registerForEvent`, `unregisterFromEvent`, `getEventRegistrations`                                                                         |
| `attendanceApi`   | `getAllAttendance`, `getAttendanceByCourse`, `getAttendanceByStudent`, `getAttendancePercentage`, `getAttendanceReport`, `markAttendance`, `updateAttendance`, `deleteAttendance`                                                          |
| `timetableApi`    | `getAllTimetable`, `getTimetableById`, `getTimetableByCourse`, `getTimetableByDay`, `getStudentTimetable`, `createTimetableEntry`, `updateTimetableEntry`, `deleteTimetableEntry`                                                          |
| `roadmapApi`      | `getAllRoadmap`, `getRoadmapById`, `getRoadmapByDepartment`, `getRoadmapBySemester`, `createRoadmapItem`, `updateRoadmapItem`, `deleteRoadmapItem`                                                                                         |
| `enrollmentApi`   | `getAll`                                                                                                                                                                                                                                   |
| `submissionApi`   | `getAll`                                                                                                                                                                                                                                   |
| `analyticsApi`    | `getDashboard`, `getUserStats`, `getCourseStats`, `getAttendanceSummary`, `getPerformanceStats`, `generateReport`                                                                                                                          |
| `gradesApi`       | `getStudentGrades`, `getCourseGrades`, `recordGrade`                                                                                                                                                                                       |
| `filesApi`        | `uploadFile`, `downloadFile`, `deleteFile`, `batchUpload`                                                                                                                                                                                  |

---

## Layout Components

### DashboardLayout.jsx

The main layout for all authenticated pages. It renders:

- **Sidebar** with role-specific navigation links:
  - **Admin** (rose color): Dashboard, Manage Users, Courses, Events, Timetable, Roadmap, Analytics, Announcements
  - **Teacher** (emerald color): Dashboard, Lectures, Assignments, Attendance, Attendance Calculator
  - **Student** (indigo color): Dashboard, Lectures, Assignments, Timetable, Attendance, CGPA Calculator, Roadmap
- **Sidebar header** with application logo and branding.
- **User card** displaying initials, name, role, and department.
- **Active page highlight** with gradient styling.
- **Mobile hamburger menu** that toggles the sidebar on smaller screens.
- **Top bar** with a notifications bell icon that shows a dropdown of recent active announcements (filtered by role, sorted newest first, max 5), with priority-based color coding (high/medium/low).
- **Profile link** and **logout button**.

### PublicNavbar.jsx

Navigation for the public homepage. Features:

- Links: Home, About, Departments, Events, Gallery, Faculty, Roadmap, Contact.
- Smooth scrolling to page sections (anchor IDs like `#home`, `#about`).
- Scroll-based backdrop blur effect on the header.
- Mobile menu overlay.
- "Sign In to Portal" call-to-action button that navigates to `/login`.

---

## Pages — By Role

### Public Pages

| Page          | Description                                                                                                                                                                                                          |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **HomePage**  | Public landing page with hero section, animated statistics counters, department cards, roadmap preview, testimonials carousel, events list, gallery bento layout, and call-to-action section                         |
| **LoginPage** | Email/password login form with validation and error handling. Includes quick-login buttons for demo accounts (admin, teacher, student). Animated background. Redirects to the user's role-based dashboard on success |

### Admin Pages (8)

| Page                    | Path                   | Description                                                                                                                                                                                                |
| ----------------------- | ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **AdminDashboard**      | `/admin`               | Overview stats cards, activity area chart (logins/submissions over time), pie chart for courses by department, bar chart for students by department, recent users list, events and announcements summaries |
| **ManageUsers**         | `/admin/users`         | Full CRUD interface for user accounts — create, edit, delete users with role/department assignment                                                                                                         |
| **ManageCourses**       | `/admin/courses`       | Full CRUD for courses — create, edit, delete courses, manage enrollments                                                                                                                                   |
| **ManageEvents**        | `/admin/events`        | Full CRUD for campus events — create, edit, delete events                                                                                                                                                  |
| **ManageTimetable**     | `/admin/timetable`     | Full CRUD for timetable entries — assign rooms, times, days                                                                                                                                                |
| **ManageRoadmap**       | `/admin/roadmap`       | Full CRUD for semester learning roadmaps by department                                                                                                                                                     |
| **AdminAnalytics**      | `/admin/analytics`     | System-wide analytics dashboard with charts and report generation                                                                                                                                          |
| **ManageAnnouncements** | `/admin/announcements` | Full CRUD for announcements with role targeting and priority settings                                                                                                                                      |

### Teacher Pages (5)

| Page                     | Path                             | Description                                                                                                                                    |
| ------------------------ | -------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| **TeacherDashboard**     | `/teacher`                       | My courses count, total enrolled students, pending grades alert, bar chart for attendance by course, pie chart for submission status breakdown |
| **UploadLectures**       | `/teacher/lectures`              | Upload and manage lecture materials for assigned courses                                                                                       |
| **ManageAssignments**    | `/teacher/assignments`           | Create assignments, view student submissions, grade individual submissions                                                                     |
| **AttendanceManager**    | `/teacher/attendance`            | Mark attendance for enrolled students in assigned courses                                                                                      |
| **AttendanceCalculator** | `/teacher/attendance-calculator` | Calculate and view attendance percentages for courses                                                                                          |

### Student Pages (7)

| Page                  | Path                   | Description                                                                                                                      |
| --------------------- | ---------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| **StudentDashboard**  | `/student`             | Radial bar chart for overall attendance %, pending assignments list, recent lectures, per-course attendance stats, announcements |
| **ViewLectures**      | `/student/lectures`    | Browse lecture materials for enrolled courses                                                                                    |
| **ViewAssignments**   | `/student/assignments` | View assignments with due dates, submission status, and grades                                                                   |
| **StudentTimetable**  | `/student/timetable`   | Weekly schedule for enrolled courses                                                                                             |
| **StudentAttendance** | `/student/attendance`  | Attendance summary and per-course breakdown                                                                                      |
| **CGPACalculator**    | `/student/cgpa`        | View grades and cumulative GPA calculation                                                                                       |
| **StudentRoadmap**    | `/student/roadmap`     | View the semester learning roadmap for the student's department                                                                  |

### Shared Pages

| Page            | Path              | Description                                                                                                                                                                                                                                                                 |
| --------------- | ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **ProfilePage** | `/{role}/profile` | Edit name and phone, change password. Shows role-specific stats: students see enrolled courses, assignments, attendance %, and semester; teachers see courses teaching, total students, assignments created, and department; admins see user/course counts and access level |

---

## Shared Components

### ProtectedRoute

Route guard component. Checks auth status and user role:

- Not authenticated → redirect to `/login`
- Wrong role → redirect to the user's correct dashboard
- Correct role → render children

### StatsCard

Reusable card for displaying a statistic. Props:

| Prop       | Type   | Description                                      |
| ---------- | ------ | ------------------------------------------------ |
| `title`    | string | Label below the value                            |
| `value`    | string | The main number/text displayed                   |
| `icon`     | node   | Icon element shown beside the value              |
| `color`    | string | Color theme for the card                         |
| `subtitle` | string | Optional secondary text                          |
| `trend`    | object | Optional trend indicator (percentage, direction) |

### ImageWithFallback

Renders an `<img>` tag that swaps in a placeholder SVG (broken image icon) if the image fails to load. Passes through all standard img props.

### ui/ Directory

Contains headless Radix UI primitive wrappers styled with TailwindCSS: accordion, alert-dialog, avatar, badge, breadcrumb, button, calendar, card, carousel, chart, checkbox, collapsible, command, context-menu, dialog, drawer, dropdown-menu, form, hover-card, input, label, menubar, navigation-menu, pagination, popover, progress, radio-group, scroll-area, select, separator, sheet, sidebar, skeleton, slider, sonner (toast), switch, table, tabs, textarea, toggle, toggle-group, and tooltip.

---

## Styling

The app uses **TailwindCSS 4** with the `@tailwindcss/vite` plugin.

### Style Files

| File           | Purpose                                                                                                                                                                                  |
| -------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `index.css`    | Master entry point — imports all other style files                                                                                                                                       |
| `tailwind.css` | TailwindCSS directives, source scanning config (`@source '../**/*.{js,ts,jsx,tsx}'`), and tw-animate-css import                                                                          |
| `theme.css`    | CSS custom properties for colors (using `oklch()` color space), border radius, font weights, ring styles. Supports dark mode via `.dark` class. Includes chart colors and sidebar colors |
| `fonts.css`    | Reserved for custom font imports (currently empty)                                                                                                                                       |

### Color System

Colors are defined as CSS custom properties in `theme.css` and referenced by Tailwind utility classes. Key variables include `--primary`, `--secondary`, `--muted`, `--accent`, `--destructive`, with corresponding foreground variants. Dark mode overrides are defined inside `.dark { }`.

---

## Testing

### Unit Tests (Vitest + React Testing Library)

Unit tests live in `src/test/` and use Vitest with jsdom environment and React Testing Library.

| Test File                   | What It Tests                                      |
| --------------------------- | -------------------------------------------------- |
| `AuthContext.test.jsx`      | Login/logout flows, session restore, error cases   |
| `DataContext.test.jsx`      | Data fetching, CRUD operations, state updates      |
| `LoginPage.test.jsx`        | Form validation, submit behavior, demo buttons     |
| `ProtectedRoute.test.jsx`   | Redirects for unauthenticated and wrong-role users |
| `StudentDashboard.test.jsx` | Dashboard rendering with mock data                 |

Setup file (`src/test/setup.js`) imports `@testing-library/jest-dom` for custom matchers like `toBeInTheDocument()`.

The Vite config (`vite.config.js`) configures the test environment:

- Environment: `jsdom`
- Global test APIs enabled
- CSS processing enabled
- E2E tests excluded from unit test runs

```bash
npm test              # run once
npm run test:watch    # watch mode
```

### End-to-End Tests (Playwright)

E2E tests live in `e2e/` and use Playwright.

| Test File           | What It Tests                           |
| ------------------- | --------------------------------------- |
| `auth.spec.js`      | Login/logout flows in a real browser    |
| `dashboard.spec.js` | Dashboard page interactions and content |

The Playwright config (`playwright.config.js`):

- Test directory: `./e2e`
- Timeout: 30 seconds
- Headless Chromium browser
- Screenshots on failure
- Automatically starts both backend (port 3000) and frontend (port 5173) web servers before tests

```bash
npm run test:e2e
```

---

## Environment Variables

Environment files (`.env`, `.env.local`, `.env.development`, `.env.production`) configure the backend API URL:

| Variable       | Default                     | Description                   |
| -------------- | --------------------------- | ----------------------------- |
| `VITE_API_URL` | `http://localhost:3000/api` | Base URL for all API requests |

To change the backend URL, edit the appropriate `.env` file and restart the dev server.

---

## Connecting to the Backend

The frontend requires the backend to be running for any data to appear. The connection works as follows:

1. `src/lib/api.js` creates an Axios instance pointing at `VITE_API_URL`.
2. On every request, the request interceptor reads `auth_token` from `localStorage` and attaches it as a `Bearer` token.
3. The backend validates the JWT and returns JSON data.
4. On a 401 response (token expired or invalid), the response interceptor clears `localStorage` and redirects to `/login`.
5. `DataContext` calls these API functions on mount and after every CRUD operation.

If the backend is not running, the app will load but show empty data and log network errors to the console.

---

## Troubleshooting

### Blank page or console errors about API

- Make sure the backend is running at `http://localhost:3000`.
- Check that `.env` has `VITE_API_URL=http://localhost:3000/api`.
- Restart the frontend dev server after changing `.env`.

### Login fails

- Verify the backend database is seeded: `cd backend && npm run init-db`.
- Check the backend terminal for error messages.
- Try clearing localStorage: open browser console and run `localStorage.clear()`.

### Styles not loading

- Make sure `npm install` completed successfully.
- Restart the dev server — TailwindCSS 4 detects class usage at build time.

### Port conflict

```bash
# Start on a different port
npx vite --port 5174
```

### E2E tests fail

- Both backend and frontend must be available (Playwright starts them automatically, but pre-existing processes on those ports can conflict).
- Run `npx playwright install` if browser binaries are missing.

---

## Demo Credentials

| Role    | Email                       | Password     |
| ------- | --------------------------- | ------------ |
| Admin   | `admin@university.edu`      | `admin123`   |
| Teacher | `john.smith@university.edu` | `teacher123` |
| Student | `alice@student.edu`         | `student123` |
