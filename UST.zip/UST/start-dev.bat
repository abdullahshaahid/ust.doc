@echo off
REM UniversityLearn Development Server Startup Script (Windows)
REM Starts both backend and frontend in parallel

echo.
echo 🎓 UniversityLearn - Full Stack Development Server
echo ==================================================
echo.

REM Check if backend folder exists
if not exist "backend" (
    echo ❌ Backend folder not found!
    exit /b 1
)

REM Check if frontend folder exists
if not exist "frontend" (
    echo ❌ Frontend folder not found!
    exit /b 1
)

echo 📦 Starting services...
echo.

echo 🔧 Backend (port 3000) - initializing...
cd backend
call npm install >nul 2>&1
call npm run init-db >nul 2>&1
start "UniversityLearn Backend" npm start
cd ..

REM Give backend time to start
timeout /t 3 /nobreak

echo ⚡ Frontend (port 5173) - starting...
cd frontend
call npm install >nul 2>&1
start "UniversityLearn Frontend" npm run dev
cd ..

echo.
echo ✅ Services started in separate windows!
echo.
echo 📍 Backend:  http://localhost:3000
echo 📍 Frontend: http://localhost:5173
echo 🔍 API:      http://localhost:3000/api
echo.
echo 🔐 Demo Credentials:
echo    Admin:   admin@university.edu / admin123
echo    Teacher: john.smith@university.edu / teacher123
echo    Student: alice@student.edu / student123
echo.
echo Close the terminal windows to stop the servers.
pause
