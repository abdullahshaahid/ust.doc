# UniversityLearn — Complete University Management System

A full-stack university learning management system with role-based dashboards for admins, teachers, and students. Built with **React + Vite** on the frontend and **Express.js + SQLite** on the backend.

## Table of Contents

- [Quick Start](#quick-start)
- [How It All Comes Together](#how-it-all-comes-together)
- [System Architecture](#system-architecture)
- [Features](#features)
- [Prerequisites](#prerequisites)
- [Setup Instructions](#setup-instructions)
- [Running the Application](#running-the-application)
- [Demo Credentials](#demo-credentials)
- [Project Structure](#project-structure)
- [Documentation](#documentation)
- [Troubleshooting](#troubleshooting)
- [Deployment](#deployment)

---

## Quick Start

### One-Command Start (Recommended)

**Linux / Mac:**

```bash
chmod +x start-dev.sh
./start-dev.sh
```

**Windows:**

```bash
start-dev.bat
```

These scripts install dependencies, initialize the database, and launch both servers in parallel.

### Manual Start

```bash
# Terminal 1 — Backend
cd backend
npm install
npm run init-db
npm start

# Terminal 2 — Frontend
cd frontend
npm install
npm run dev
```

Then open **http://localhost:5173** in your browser.

---

## How It All Comes Together

The system is split into two independent Node.js projects that communicate over HTTP:

### The Backend (Express.js + SQLite)

The backend is a REST API server that owns all the data. It runs on **port 3000** and handles:

- **Authentication** — Users log in with email and password. The backend verifies credentials against hashed passwords in SQLite, then returns a signed JWT (JSON Web Token) valid for 24 hours.
- **Data persistence** — Every resource (users, courses, assignments, grades, attendance, events, announcements, timetables, roadmaps) is stored in a single SQLite database file (`backend/university.db`). The database is created automatically on first startup with 13 tables and sample data.
- **Authorization** — Each request that needs to know who is calling must include the JWT in the `Authorization` header. A middleware layer decodes the token and checks the user's role (admin, teacher, or student) before allowing access.
- **16 API route groups** — One per resource, all mounted under `/api/*`. Every route handler runs parameterized SQL and returns JSON.

When you run `npm start` in the backend directory, it opens the SQLite database, creates any missing tables, seeds sample data if the database is empty, and starts listening for HTTP requests.

See [backend/README.md](backend/README.md) for the complete API reference, database schema, and every route endpoint.

### The Frontend (React + Vite + TailwindCSS)

The frontend is a single-page React application served by Vite on **port 5173** during development. It handles:

- **Routing** — React Router defines public routes (`/`, `/login`) and three protected route groups (`/admin/*`, `/teacher/*`, `/student/*`). Each group is guarded by a `ProtectedRoute` component that checks the user's role.
- **Authentication state** — `AuthContext` manages login/logout, stores the JWT in `localStorage`, and restores the session on page refresh.
- **Data fetching and state** — `DataContext` fetches all application data from the backend's REST API on mount, enriches it (e.g., attaching enrolled students to courses, submissions to assignments), and provides CRUD methods that call the backend then refresh all data.
- **API client** — `src/lib/api.js` is an Axios instance that auto-attaches the JWT to every request and redirects to `/login` on 401 responses (expired token).
- **Role-based dashboards** — Each role has a dedicated layout with its own sidebar navigation, color scheme, and set of pages (8 admin pages, 5 teacher pages, 7 student pages, plus a shared profile page).
- **UI library** — Radix UI headless primitives styled with TailwindCSS, plus charts via Recharts.

When you run `npm run dev` in the frontend directory, Vite starts a dev server with hot module replacement. Every API call goes to `http://localhost:3000/api` (configured in the `.env` file).

See [frontend/README.md](frontend/README.md) for the complete component breakdown, context documentation, and every page.

### The Connection Between Them

```
Browser (React SPA on :5173)
    │
    │  HTTP requests with JWT in Authorization header
    │  e.g. GET /api/courses, POST /api/auth/login
    │
    ▼
Express.js Server (:3000)
    │
    │  Validates JWT → runs SQL → returns JSON
    │
    ▼
SQLite Database (university.db)
```

1. User opens the frontend at `http://localhost:5173`.
2. They see the public homepage or navigate to `/login`.
3. On login, the frontend sends `POST /api/auth/login` to the backend with email and password.
4. The backend validates credentials, returns a JWT and user object.
5. The frontend stores the JWT in `localStorage` and redirects to the user's dashboard.
6. `DataContext` immediately fetches all data from the backend (users, courses, assignments, etc.) using the JWT for authorization.
7. When the user creates, updates, or deletes anything, the frontend calls the matching API endpoint, then re-fetches all data to keep the UI in sync.
8. On logout, the frontend clears `localStorage` and redirects to `/login`.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│              Browser (React + Vite)                      │
│                                                          │
│  ┌────────────────────────────────────────────────────┐ │
│  │  AuthContext          DataContext                   │ │
│  │  (login/logout/JWT)   (fetch/CRUD/state)           │ │
│  └───────────┬────────────────────┬───────────────────┘ │
│              │                    │                      │
│  ┌───────────▼────────────────────▼───────────────────┐ │
│  │              src/lib/api.js                         │ │
│  │  Axios instance with JWT interceptor               │ │
│  └───────────────────────┬────────────────────────────┘ │
│                          │ HTTP/REST                     │
└──────────────────────────┼───────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│          Express.js Backend (Port 3000)                  │
│                                                          │
│  ┌────────────────────────────────────────────────────┐ │
│  │  middleware/auth.js                                 │ │
│  │  JWT verification + role checking                  │ │
│  └───────────────────────┬────────────────────────────┘ │
│                          │                               │
│  ┌───────────────────────▼────────────────────────────┐ │
│  │  16 Route Groups (/api/*)                          │ │
│  │  auth, users, courses, lectures, assignments,      │ │
│  │  announcements, events, attendance, timetable,     │ │
│  │  roadmap, analytics, grades, files, enrollments,   │ │
│  │  submissions, homepage                             │ │
│  └───────────────────────┬────────────────────────────┘ │
│                          │                               │
│  ┌───────────────────────▼────────────────────────────┐ │
│  │  SQLite Database (university.db)                   │ │
│  │  13 tables: users, courses, enrollments, lectures, │ │
│  │  assignments, submissions, attendance,             │ │
│  │  announcements, events, eventRegistrations,        │ │
│  │  roadmap, timetable, grades                        │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

## Features

### Authentication and Authorization
- JWT-based login with 24-hour token expiry
- Three roles: Admin, Teacher, Student
- Role-based route protection on both frontend and backend
- Session persistence across page refreshes via localStorage

### Admin Capabilities
- Dashboard with system-wide analytics (charts for activity, enrollment, departments)
- Manage all users (create, edit, delete, filter by role/department)
- Manage all courses (CRUD + enrollment management)
- Manage events, timetable entries, learning roadmaps, and announcements
- Analytics page with custom report generation

### Teacher Capabilities
- Dashboard with personal course stats, attendance charts, submission breakdowns
- Upload and manage lecture materials for assigned courses
- Create assignments, view submissions, grade student work
- Mark and manage attendance for enrolled students
- Attendance percentage calculator

### Student Capabilities
- Dashboard with attendance percentage (radial chart), pending assignments, recent lectures
- Browse lecture materials for enrolled courses
- View assignments with due dates, submit work, track grades
- View weekly timetable for enrolled courses
- Attendance summary with per-course breakdown
- CGPA calculator with grade details
- View semester learning roadmap for their department

### Shared
- Profile page (edit name, phone, change password) with role-specific stats
- Notification bell with filtered active announcements
- Public homepage with hero, stats, departments, events, gallery, and more

---

## Prerequisites

- **Node.js** v16 or higher
- **npm** (comes with Node.js)
- A modern web browser

SQLite is bundled as an npm dependency — no separate database installation is needed.

---

## Setup Instructions

### 1. Get the code

```bash
cd UST
```

### 2. Set up the backend

```bash
cd backend
npm install
npm run init-db    # creates the SQLite database and loads sample data
npm start          # starts the API server on http://localhost:3000
```

### 3. Set up the frontend (in a new terminal)

```bash
cd frontend
npm install
npm run dev        # starts the dev server on http://localhost:5173
```

### 4. Open the app

Navigate to **http://localhost:5173** and log in with one of the demo accounts.

---

## Running the Application

### Option 1: Startup Scripts (easiest)

| OS            | Command          |
| ------------- | ---------------- |
| Linux / Mac   | `./start-dev.sh` |
| Windows       | `start-dev.bat`  |

The scripts handle `npm install`, database initialization, and starting both servers.

### Option 2: Two Terminals

**Terminal 1 — Backend:**
```bash
cd backend && npm start
```

**Terminal 2 — Frontend:**
```bash
cd frontend && npm run dev
```

### Access Points

| Service          | URL                       |
| ---------------- | ------------------------- |
| Frontend         | http://localhost:5173      |
| Backend API      | http://localhost:3000/api  |
| API Discovery    | http://localhost:3000      |

---

## Demo Credentials

| Role    | Email                       | Password     | Access                                         |
| ------- | --------------------------- | ------------ | ---------------------------------------------- |
| Admin   | `admin@university.edu`      | `admin123`   | Full system control, analytics, user management |
| Teacher | `john.smith@university.edu` | `teacher123` | Course management, grading, attendance          |
| Student | `alice@student.edu`         | `student123` | Courses, assignments, attendance, CGPA          |

---

## Project Structure

```
UST/
├── README.md                   # This file — overview and getting started
├── start-dev.sh                # Linux/Mac startup script
├── start-dev.bat               # Windows startup script
├── MIGRATION_GUIDE.md          # Frontend-backend integration changelog
│
├── backend/                    # Express.js REST API
│   ├── main.js                 # Server entry point
│   ├── db/                     # SQLite connection + schema + seeding
│   ├── middleware/              # JWT auth + role middleware
│   ├── routes/                 # 16 API route files (one per resource)
│   ├── scripts/                # Database initialization script
│   ├── data/                   # JSON seed files
│   ├── tests/                  # Vitest + supertest integration tests
│   └── README.md               # Full backend documentation
│
├── frontend/                   # React + Vite SPA
│   ├── src/
│   │   ├── app/
│   │   │   ├── context/        # AuthContext + DataContext
│   │   │   ├── components/     # Layout, shared, UI primitives
│   │   │   └── pages/          # admin/ teacher/ student/ auth/ public/ shared/
│   │   ├── lib/api.js          # Axios API client
│   │   └── styles/             # TailwindCSS + theme
│   ├── e2e/                    # Playwright E2E tests
│   ├── src/test/               # Vitest unit tests
│   └── README.md               # Full frontend documentation
```

---

## Documentation

| Document                                              | Description                                  |
| ----------------------------------------------------- | -------------------------------------------- |
| [backend/README.md](backend/README.md)                | Backend architecture, full API reference, database schema, testing, environment variables |
| [frontend/README.md](frontend/README.md)              | Frontend architecture, routing, contexts, every page, styling, testing |
| [frontend/BACKEND_CONNECTION.md](frontend/BACKEND_CONNECTION.md) | Step-by-step guide for how the frontend connects to the backend |
| [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md)              | Changelog of changes made during frontend-backend integration |

---

## Troubleshooting

### Backend won't start

```bash
# Check if port 3000 is in use
lsof -i :3000                    # Mac/Linux
netstat -ano | findstr :3000     # Windows

# Re-initialize the database
cd backend
rm -f university.db
npm run init-db
npm start
```

### Frontend shows empty data or API errors

- Confirm the backend is running at `http://localhost:3000`.
- Check the frontend `.env` file has `VITE_API_URL=http://localhost:3000/api`.
- Restart the frontend dev server after changing `.env`.

### Login fails with demo credentials

```bash
# Re-seed the database
cd backend
rm -f university.db
npm run init-db
npm start
```

### Port conflicts

```bash
# Backend on a different port
cd backend
PORT=3001 npm start
# Then update frontend/.env: VITE_API_URL=http://localhost:3001/api

# Frontend on a different port
cd frontend
npx vite --port 5174
```

### Clear browser state

Open the browser console and run:

```js
localStorage.clear()
```

Then refresh the page.

---

## Running Tests

### Backend Tests

```bash
cd backend
npm test              # single run
npm run test:watch    # watch mode
```

Uses Vitest + supertest against a disposable SQLite database.

### Frontend Unit Tests

```bash
cd frontend
npm test              # single run
npm run test:watch    # watch mode
```

Uses Vitest + React Testing Library with jsdom.

### Frontend E2E Tests

```bash
cd frontend
npx playwright install    # first time only — installs browser binaries
npm run test:e2e
```

Uses Playwright with Chromium. Automatically starts both backend and frontend servers.

---

## Deployment

### 1. Configure environment

**Backend `.env`:**
```env
PORT=3000
NODE_ENV=production
JWT_SECRET=your-secure-random-secret
```

**Frontend `.env.production`:**
```env
VITE_API_URL=https://yourdomain.com/api
```

### 2. Build the frontend

```bash
cd frontend
npm run build    # outputs to dist/
```

### 3. Deploy

- Run the backend on your server with `npm start`.
- Serve `frontend/dist/` via a CDN, Nginx, or any static file server.
- Configure your reverse proxy to forward `/api/*` requests to the backend.

---

## License

ISC
