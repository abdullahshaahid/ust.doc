#!/bin/bash

# UniversityLearn Development Server Startup Script
# Starts both backend and frontend in parallel

echo "🎓 UniversityLearn - Full Stack Development Server"
echo "=================================================="
echo ""

# Check if backend folder exists
if [ ! -d "backend" ]; then
    echo "❌ Backend folder not found!"
    exit 1
fi

# Check if frontend folder exists
if [ ! -d "frontend" ]; then
    echo "❌ Frontend folder not found!"
    exit 1
fi

echo "📦 Starting services..."
echo ""

# Start backend in background
echo "🔧 Starting Backend (port 3000)..."
cd backend
npm install > /dev/null 2>&1
npm run init-db > /dev/null 2>&1
npm start &
BACKEND_PID=$!
cd ..

# Give backend time to start
sleep 3

# Start frontend in background
echo "⚡ Starting Frontend (port 5173)..."
cd frontend
npm install > /dev/null 2>&1
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "✅ Services started!"
echo ""
echo "📍 Backend:  http://localhost:3000"
echo "📍 Frontend: http://localhost:5173"
echo "🔍 API:      http://localhost:3000/api"
echo ""
echo "🔐 Demo Credentials:"
echo "   Admin:   admin@university.edu / admin123"
echo "   Teacher: john.smith@university.edu / teacher123"
echo "   Student: alice@student.edu / student123"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Wait for both processes
wait $BACKEND_PID $FRONTEND_PID
