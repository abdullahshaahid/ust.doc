import express from "express";
import cors from "cors";
import { initializeDatabase, closeDatabase } from "./db/database.js";
import { createTables, seedDatabase } from "./db/schema.js";

// Import routes
import authRoutes from "./routes/auth.js";
import usersRoutes from "./routes/users.js";
import coursesRoutes from "./routes/courses.js";
import lecturesRoutes from "./routes/lectures.js";
import assignmentsRoutes from "./routes/assignments.js";
import announcementsRoutes from "./routes/announcements.js";
import eventsRoutes from "./routes/events.js";
import attendanceRoutes from "./routes/attendance.js";
import timetableRoutes from "./routes/timetable.js";
import roadmapRoutes from "./routes/roadmap.js";
import analyticsRoutes from "./routes/analytics.js";
import gradesRoutes from "./routes/grades.js";
import filesRoutes from "./routes/files.js";
import enrollmentsRoutes from "./routes/enrollments.js";
import submissionsRoutes from "./routes/submissions.js";
import homepageRoutes from "./routes/homepage.js";

const app = express();
export { app };
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Root endpoint
app.get("/", (req, res) => {
  res.json({
    message: "🎓 UniversityLearn Backend API",
    version: "1.0.0",
    status: "active",
    endpoints: {
      auth: "/api/auth",
      users: "/api/users",
      courses: "/api/courses",
      lectures: "/api/lectures",
      assignments: "/api/assignments",
      announcements: "/api/announcements",
      events: "/api/events",
      attendance: "/api/attendance",
      timetable: "/api/timetable",
      roadmap: "/api/roadmap",
      analytics: "/api/analytics",
      grades: "/api/grades",
      files: "/api/files",
    },
  });
});

// Register routes
app.use("/api/auth", authRoutes);
app.use("/api/users", usersRoutes);
app.use("/api/courses", coursesRoutes);
app.use("/api/lectures", lecturesRoutes);
app.use("/api/assignments", assignmentsRoutes);
app.use("/api/announcements", announcementsRoutes);
app.use("/api/events", eventsRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/timetable", timetableRoutes);
app.use("/api/roadmap", roadmapRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/grades", gradesRoutes);
app.use("/api/files", filesRoutes);
app.use("/api/enrollments", enrollmentsRoutes);
app.use("/api/submissions", submissionsRoutes);
app.use("/api/homepage", homepageRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Error:", err);
  res
    .status(500)
    .json({ error: "Internal server error", message: err.message });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// Initialize database and start server
const startServer = async () => {
  try {
    console.log("🚀 Starting UniversityLearn Backend...");
    console.log("📦 Initializing database...");

    await initializeDatabase();
    await createTables();

    // Seed only if database is empty (first run)
    console.log("📊 Checking database...");
    await seedDatabase();

    app.listen(port, () => {
      console.log(`✅ Server running at http://localhost:${port}`);
      console.log(`📚 API Documentation at http://localhost:${port}/`);
    });
  } catch (error) {
    console.error("❌ Failed to start server:", error);
    process.exit(1);
  }
};

// Graceful shutdown
process.on("SIGINT", async () => {
  console.log("\n⛔ Shutting down...");
  await closeDatabase();
  process.exit(0);
});

// Only auto-start when run directly (not imported for testing)
const isMain = process.argv[1] && !process.argv[1].includes("vitest");
if (isMain) {
  startServer();
}

export { startServer };
