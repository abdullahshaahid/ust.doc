// Test setup: initializes the app with a temporary SQLite database for isolated testing.
// Set TEST_DB_PATH before importing the app so all routes use the test DB.

import { join } from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import { mkdtempSync, rmSync } from "fs";
import { tmpdir } from "os";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let tmpDir;
let closeDb;

export async function createTestApp() {
  // Use a temp file DB (in-memory doesn't work well across modules sharing the singleton)
  tmpDir = mkdtempSync(join(tmpdir(), "ust-test-"));
  const dbPath = join(tmpDir, "test.db");
  process.env.TEST_DB_PATH = dbPath;

  // Dynamically import after setting env so the DB module picks up the test path
  const { initializeDatabase, closeDatabase } =
    await import("../db/database.js");
  const { createTables, seedDatabase } = await import("../db/schema.js");
  const { app } = await import("../main.js");

  closeDb = closeDatabase;
  await initializeDatabase();
  await createTables();
  await seedDatabase();

  return app;
}

export async function cleanupTestApp() {
  if (closeDb) {
    try {
      await closeDb();
    } catch {}
  }
  if (tmpDir) {
    try {
      rmSync(tmpDir, { recursive: true, force: true });
    } catch {}
    tmpDir = null;
  }
}

// Helper to get an auth token via login
export async function getToken(request, app, email, password) {
  const res = await request(app)
    .post("/api/auth/login")
    .send({ email, password });
  return res.body.token;
}
