import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";
import { createTestApp, cleanupTestApp, getToken } from "./setup.js";

let app;

beforeAll(async () => {
  app = await createTestApp();
});

afterAll(async () => {
  await cleanupTestApp();
});

// ─── Auth Routes ────────────────────────────────────────────────────
describe("Auth API", () => {
  it("POST /api/auth/login - valid credentials", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "admin@university.edu", password: "admin123" });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("token");
    expect(res.body.user).toMatchObject({
      id: "admin1",
      email: "admin@university.edu",
      role: "admin",
    });
  });

  it("POST /api/auth/login - invalid credentials", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "admin@university.edu", password: "wrong" });
    expect(res.status).toBe(401);
    expect(res.body).toHaveProperty("error");
  });

  it("GET /api/auth/me - with valid token", async () => {
    const token = await getToken(
      request,
      app,
      "admin@university.edu",
      "admin123",
    );
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("id", "admin1");
    expect(res.body).toHaveProperty("email", "admin@university.edu");
  });

  it("GET /api/auth/me - without token", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });

  it("POST /api/auth/register - new user", async () => {
    const res = await request(app).post("/api/auth/register").send({
      id: "newuser1",
      name: "New User",
      email: "newuser@test.edu",
      password: "test123",
      role: "student",
      department: "CS",
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("message");
    expect(res.body).toHaveProperty("userId", "newuser1");
  });
});

// ─── Users Routes ───────────────────────────────────────────────────
describe("Users API", () => {
  it("GET /api/users - returns all users", async () => {
    const res = await request(app).get("/api/users");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThanOrEqual(34);
  });

  it("GET /api/users?role=teacher - filter by role", async () => {
    const res = await request(app).get("/api/users?role=teacher");
    expect(res.status).toBe(200);
    expect(res.body.every((u) => u.role === "teacher")).toBe(true);
  });

  it("GET /api/users?department=CS - filter by department", async () => {
    const res = await request(app).get("/api/users?department=CS");
    expect(res.status).toBe(200);
    expect(res.body.every((u) => u.department === "CS")).toBe(true);
  });

  it("GET /api/users/:id - returns specific user", async () => {
    const res = await request(app).get("/api/users/admin1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("id", "admin1");
    expect(res.body).toHaveProperty("name");
    expect(res.body).toHaveProperty("email");
  });

  it("GET /api/users/:id - 404 for non-existent user", async () => {
    const res = await request(app).get("/api/users/nonexistent");
    expect(res.status).toBe(404);
  });

  it("GET /api/users/role/:role - filter by role param", async () => {
    const res = await request(app).get("/api/users/role/student");
    expect(res.status).toBe(200);
    expect(res.body.every((u) => u.role === "student")).toBe(true);
  });

  it("POST /api/users - create user", async () => {
    const res = await request(app).post("/api/users").send({
      id: "testuser1",
      name: "Test User",
      email: "testuser1@test.edu",
      password: "test123",
      role: "student",
      department: "CS",
      phone: "+1-555-9999",
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("message");
  });

  it("PUT /api/users/:id - update user", async () => {
    const res = await request(app)
      .put("/api/users/testuser1")
      .send({ name: "Updated Test User", phone: "+1-555-0000" });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("message");

    // Verify update
    const check = await request(app).get("/api/users/testuser1");
    expect(check.body.name).toBe("Updated Test User");
  });

  it("DELETE /api/users/:id - delete user", async () => {
    const res = await request(app).delete("/api/users/testuser1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("message");

    const check = await request(app).get("/api/users/testuser1");
    expect(check.status).toBe(404);
  });
});

// ─── Courses Routes ─────────────────────────────────────────────────
describe("Courses API", () => {
  it("GET /api/courses - returns all courses", async () => {
    const res = await request(app).get("/api/courses");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThanOrEqual(33);
  });

  it("GET /api/courses/:id - returns a course", async () => {
    const res = await request(app).get("/api/courses/cs101");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("id", "cs101");
    expect(res.body).toHaveProperty("name");
    expect(res.body).toHaveProperty("code");
  });

  it("GET /api/courses/:id - 404 for missing course", async () => {
    const res = await request(app).get("/api/courses/nonexistent");
    expect(res.status).toBe(404);
  });

  it("GET /api/courses/teacher/:teacherId", async () => {
    const res = await request(app).get("/api/courses/teacher/teacher1");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("POST /api/courses - create course", async () => {
    const res = await request(app).post("/api/courses").send({
      id: "test_course_1",
      name: "Test Course",
      code: "TEST101",
      description: "A test course",
      department: "CS",
      teacherId: "teacher1",
      credits: 3,
      semester: 1,
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("courseId");
  });

  it("POST /api/courses/:courseId/enroll", async () => {
    const res = await request(app)
      .post("/api/courses/test_course_1/enroll")
      .send({ studentId: "student1" });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("message");
  });

  it("GET /api/courses/student/:studentId", async () => {
    const res = await request(app).get("/api/courses/student/student1");
    expect(res.status).toBe(200);
    expect(res.body.some((c) => c.id === "test_course_1")).toBe(true);
  });

  it("GET /api/courses/:courseId/students", async () => {
    const res = await request(app).get("/api/courses/test_course_1/students");
    expect(res.status).toBe(200);
    expect(res.body.some((s) => s.id === "student1")).toBe(true);
  });

  it("DELETE /api/courses/:courseId/unenroll", async () => {
    const res = await request(app)
      .delete("/api/courses/test_course_1/unenroll")
      .send({ studentId: "student1" });
    expect(res.status).toBe(200);
  });

  it("PUT /api/courses/:id - update course", async () => {
    const res = await request(app)
      .put("/api/courses/test_course_1")
      .send({ name: "Updated Test Course", credits: 4 });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/courses/:id - delete course", async () => {
    const res = await request(app).delete("/api/courses/test_course_1");
    expect(res.status).toBe(200);
  });
});

// ─── Lectures Routes ────────────────────────────────────────────────
describe("Lectures API", () => {
  it("GET /api/lectures - returns all lectures", async () => {
    const res = await request(app).get("/api/lectures");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(66);
  });

  it("GET /api/lectures/course/:courseId", async () => {
    const res = await request(app).get("/api/lectures/course/cs101");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("POST /api/lectures - create lecture", async () => {
    const res = await request(app).post("/api/lectures").send({
      id: "test_lec_1",
      courseId: "cs101",
      title: "Test Lecture",
      description: "A test lecture",
      fileUrl: "#",
      uploadedBy: "teacher1",
      videoUrl: null,
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("lectureId");
  });

  it("GET /api/lectures/:id - returns lecture", async () => {
    const res = await request(app).get("/api/lectures/test_lec_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title", "Test Lecture");
  });

  it("PUT /api/lectures/:id - update lecture", async () => {
    const res = await request(app)
      .put("/api/lectures/test_lec_1")
      .send({ title: "Updated Lecture" });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/lectures/:id - delete lecture", async () => {
    const res = await request(app).delete("/api/lectures/test_lec_1");
    expect(res.status).toBe(200);
  });
});

// ─── Assignments Routes ─────────────────────────────────────────────
describe("Assignments API", () => {
  it("GET /api/assignments - returns all assignments", async () => {
    const res = await request(app).get("/api/assignments");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(20);
  });

  it("POST /api/assignments - create assignment", async () => {
    const res = await request(app).post("/api/assignments").send({
      id: "test_asgn_1",
      courseId: "cs101",
      title: "Test Assignment",
      description: "Test desc",
      dueDate: "2026-12-31",
      totalMarks: 50,
      createdBy: "teacher1",
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("assignmentId");
  });

  it("GET /api/assignments/:id", async () => {
    const res = await request(app).get("/api/assignments/test_asgn_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title", "Test Assignment");
  });

  it("GET /api/assignments/course/:courseId", async () => {
    const res = await request(app).get("/api/assignments/course/cs101");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("POST /api/assignments/:assignmentId/submit", async () => {
    const res = await request(app)
      .post("/api/assignments/test_asgn_1/submit")
      .send({ studentId: "student1", content: "My submission" });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("message");
  });

  it("GET /api/assignments/:assignmentId/submissions", async () => {
    const res = await request(app).get(
      "/api/assignments/test_asgn_1/submissions",
    );
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0]).toHaveProperty("studentId", "student1");
  });

  it("GET /api/assignments/:assignmentId/submission/:studentId", async () => {
    const res = await request(app).get(
      "/api/assignments/test_asgn_1/submission/student1",
    );
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("content", "My submission");
  });

  it("PUT /api/assignments/:assignmentId/grade/:studentId", async () => {
    const res = await request(app)
      .put("/api/assignments/test_asgn_1/grade/student1")
      .send({ marks: 45, feedback: "Great work!", gradedBy: "teacher1" });
    expect(res.status).toBe(200);
  });

  it("PUT /api/assignments/:id - update assignment", async () => {
    const res = await request(app)
      .put("/api/assignments/test_asgn_1")
      .send({ title: "Updated Assignment" });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/assignments/:id - delete assignment", async () => {
    const res = await request(app).delete("/api/assignments/test_asgn_1");
    expect(res.status).toBe(200);
  });
});

// ─── Announcements Routes ───────────────────────────────────────────
describe("Announcements API", () => {
  it("GET /api/announcements - returns active announcements", async () => {
    const res = await request(app).get("/api/announcements");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(1);
  });

  it("POST /api/announcements - create announcement", async () => {
    const res = await request(app).post("/api/announcements").send({
      id: "test_ann_1",
      title: "Test Announcement",
      content: "Test content",
      targetRole: "all",
      priority: "high",
      createdBy: "admin1",
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("announcementId");
  });

  it("GET /api/announcements/:id", async () => {
    const res = await request(app).get("/api/announcements/test_ann_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title", "Test Announcement");
  });

  it("GET /api/announcements/role/:role", async () => {
    const res = await request(app).get("/api/announcements/role/student");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("PUT /api/announcements/:id/status - toggle status", async () => {
    const res = await request(app)
      .put("/api/announcements/test_ann_1/status")
      .send({ isActive: 0 });
    expect(res.status).toBe(200);
  });

  it("PUT /api/announcements/:id - update announcement", async () => {
    const res = await request(app)
      .put("/api/announcements/test_ann_1")
      .send({ title: "Updated Announcement", isActive: 1 });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/announcements/:id - delete announcement", async () => {
    const res = await request(app).delete("/api/announcements/test_ann_1");
    expect(res.status).toBe(200);
  });
});

// ─── Events Routes ──────────────────────────────────────────────────
describe("Events API", () => {
  it("GET /api/events - returns all events", async () => {
    const res = await request(app).get("/api/events");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(15);
  });

  it("POST /api/events - create event", async () => {
    const res = await request(app).post("/api/events").send({
      id: "test_evt_1",
      title: "Test Event",
      description: "Test desc",
      date: "2026-06-15",
      type: "academic",
      location: "Room 200",
      organizer: "CS Dept",
      createdBy: "admin1",
    });
    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("eventId");
  });

  it("GET /api/events/:id", async () => {
    const res = await request(app).get("/api/events/test_evt_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title", "Test Event");
  });

  it("GET /api/events/type/:type", async () => {
    const res = await request(app).get("/api/events/type/academic");
    expect(res.status).toBe(200);
    expect(res.body.every((e) => e.type === "academic")).toBe(true);
  });

  it("POST /api/events/:eventId/register - register student", async () => {
    const res = await request(app)
      .post("/api/events/test_evt_1/register")
      .send({ studentId: "student1" });
    expect(res.status).toBe(201);
  });

  it("POST /api/events/:eventId/register - duplicate registration", async () => {
    const res = await request(app)
      .post("/api/events/test_evt_1/register")
      .send({ studentId: "student1" });
    expect(res.status).toBe(400);
  });

  it("GET /api/events/:eventId/registrations", async () => {
    const res = await request(app).get("/api/events/test_evt_1/registrations");
    expect(res.status).toBe(200);
    expect(res.body.some((s) => s.id === "student1")).toBe(true);
  });

  it("DELETE /api/events/:eventId/unregister", async () => {
    const res = await request(app)
      .delete("/api/events/test_evt_1/unregister")
      .send({ studentId: "student1" });
    expect(res.status).toBe(200);
  });

  it("PUT /api/events/:id - update event", async () => {
    const res = await request(app)
      .put("/api/events/test_evt_1")
      .send({ title: "Updated Event" });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/events/:id - delete event", async () => {
    const res = await request(app).delete("/api/events/test_evt_1");
    expect(res.status).toBe(200);
  });
});

// ─── Attendance Routes ──────────────────────────────────────────────
describe("Attendance API", () => {
  it("GET /api/attendance - returns all records", async () => {
    const res = await request(app).get("/api/attendance");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("POST /api/attendance - add record", async () => {
    const res = await request(app).post("/api/attendance").send({
      courseId: "cs101",
      studentId: "student1",
      date: "2026-01-15",
      status: "present",
      markedBy: "teacher1",
    });
    expect(res.status).toBe(201);
  });

  it("POST /api/attendance - duplicate record returns 400", async () => {
    const res = await request(app).post("/api/attendance").send({
      courseId: "cs101",
      studentId: "student1",
      date: "2026-01-15",
      status: "present",
      markedBy: "teacher1",
    });
    expect(res.status).toBe(400);
  });

  it("GET /api/attendance/course/:courseId", async () => {
    const res = await request(app).get("/api/attendance/course/cs101");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("GET /api/attendance/student/:studentId", async () => {
    const res = await request(app).get("/api/attendance/student/student1");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("GET /api/attendance/student/:studentId/percentage", async () => {
    const res = await request(app).get(
      "/api/attendance/student/student1/percentage",
    );
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("percentage");
    expect(res.body).toHaveProperty("totalDays");
    expect(res.body).toHaveProperty("presentDays");
  });

  it("GET /api/attendance/course/:courseId/report", async () => {
    const res = await request(app).get("/api/attendance/course/cs101/report");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});

// ─── Timetable Routes ──────────────────────────────────────────────
describe("Timetable API", () => {
  it("GET /api/timetable - returns all entries", async () => {
    const res = await request(app).get("/api/timetable");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(43);
  });

  it("POST /api/timetable - create entry", async () => {
    const res = await request(app).post("/api/timetable").send({
      id: "test_tt_1",
      courseId: "cs101",
      day: "Friday",
      startTime: "14:00",
      endTime: "15:30",
      room: "CS-200",
      type: "lecture",
    });
    expect(res.status).toBe(201);
  });

  it("GET /api/timetable/:id", async () => {
    const res = await request(app).get("/api/timetable/test_tt_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("day", "Friday");
  });

  it("GET /api/timetable/course/:courseId", async () => {
    const res = await request(app).get("/api/timetable/course/cs101");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("GET /api/timetable/day/:day", async () => {
    const res = await request(app).get("/api/timetable/day/Monday");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("PUT /api/timetable/:id - update entry", async () => {
    const res = await request(app)
      .put("/api/timetable/test_tt_1")
      .send({ room: "CS-300" });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/timetable/:id - delete entry", async () => {
    const res = await request(app).delete("/api/timetable/test_tt_1");
    expect(res.status).toBe(200);
  });
});

// ─── Roadmap Routes ─────────────────────────────────────────────────
describe("Roadmap API", () => {
  it("GET /api/roadmap - returns all items", async () => {
    const res = await request(app).get("/api/roadmap");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThanOrEqual(38);
  });

  it("POST /api/roadmap - create item", async () => {
    const res = await request(app).post("/api/roadmap").send({
      id: "test_rm_1",
      title: "Test Roadmap",
      description: "Test desc",
      department: "CS",
      semester: 1,
      skills: "Coding, Logic",
      resources: "Book 1",
      projects: "Project A",
    });
    expect(res.status).toBe(201);
  });

  it("GET /api/roadmap/:id", async () => {
    const res = await request(app).get("/api/roadmap/test_rm_1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title", "Test Roadmap");
  });

  it("GET /api/roadmap/department/:department", async () => {
    const res = await request(app).get("/api/roadmap/department/CS");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("GET /api/roadmap/semester/:semester", async () => {
    const res = await request(app).get("/api/roadmap/semester/1");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("PUT /api/roadmap/:id - update item", async () => {
    const res = await request(app)
      .put("/api/roadmap/test_rm_1")
      .send({ title: "Updated Roadmap" });
    expect(res.status).toBe(200);
  });

  it("DELETE /api/roadmap/:id - delete item", async () => {
    const res = await request(app).delete("/api/roadmap/test_rm_1");
    expect(res.status).toBe(200);
  });
});

// ─── Analytics Routes ───────────────────────────────────────────────
describe("Analytics API", () => {
  it("GET /api/analytics/dashboard - returns stats", async () => {
    const res = await request(app).get("/api/analytics/dashboard");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("totalUsers");
    expect(res.body).toHaveProperty("totalCourses");
    expect(res.body).toHaveProperty("totalStudents");
    expect(res.body).toHaveProperty("totalTeachers");
    expect(res.body).toHaveProperty("totalEnrollments");
  });

  it("GET /api/analytics/users - user stats", async () => {
    const res = await request(app).get("/api/analytics/users");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("byRole");
    expect(res.body).toHaveProperty("byDepartment");
  });

  it("GET /api/analytics/courses - course stats", async () => {
    const res = await request(app).get("/api/analytics/courses");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("GET /api/analytics/attendance-summary", async () => {
    const res = await request(app).get("/api/analytics/attendance-summary");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("GET /api/analytics/performance", async () => {
    const res = await request(app).get("/api/analytics/performance");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it("POST /api/analytics/report - student-performance", async () => {
    const res = await request(app)
      .post("/api/analytics/report")
      .send({ reportType: "student-performance", filters: {} });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("reportType", "student-performance");
    expect(res.body).toHaveProperty("data");
  });

  it("POST /api/analytics/report - course-performance", async () => {
    const res = await request(app)
      .post("/api/analytics/report")
      .send({ reportType: "course-performance", filters: {} });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("reportType", "course-performance");
  });
});

// ─── Grades Routes ──────────────────────────────────────────────────
describe("Grades API", () => {
  it("POST /api/grades - add grade", async () => {
    const res = await request(app).post("/api/grades").send({
      studentId: "student1",
      courseId: "cs101",
      grade: "A",
      marks: 90,
      credits: 3,
    });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("message");
  });

  it("GET /api/grades/student/:studentId - with CGPA", async () => {
    const res = await request(app).get("/api/grades/student/student1");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("grades");
    expect(res.body).toHaveProperty("cgpa");
    expect(res.body).toHaveProperty("totalCredits");
    expect(res.body.grades.length).toBeGreaterThan(0);
  });

  it("GET /api/grades/course/:courseId", async () => {
    const res = await request(app).get("/api/grades/course/cs101");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("POST /api/grades - upsert existing grade", async () => {
    const res = await request(app).post("/api/grades").send({
      studentId: "student1",
      courseId: "cs101",
      grade: "B",
      marks: 80,
      credits: 3,
    });
    expect(res.status).toBe(200);

    // Verify the grade was updated
    const check = await request(app).get("/api/grades/student/student1");
    const csGrade = check.body.grades.find((g) => g.courseId === "cs101");
    expect(csGrade.grade).toBe("B");
  });
});

// ─── Homepage Routes ────────────────────────────────────────────────
describe("Homepage API", () => {
  it("GET /api/homepage - returns all homepage data", async () => {
    const res = await request(app).get("/api/homepage");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("hero");
    expect(res.body).toHaveProperty("stats");
    expect(res.body).toHaveProperty("departments");
  });

  it("GET /api/homepage/:section - returns specific section", async () => {
    const res = await request(app).get("/api/homepage/hero");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("title");
  });

  it("GET /api/homepage/:section - 404 for missing section", async () => {
    const res = await request(app).get("/api/homepage/nonexistent");
    expect(res.status).toBe(404);
  });
});

// ─── Enrollments & Submissions Routes ───────────────────────────────
describe("Enrollments API", () => {
  it("GET /api/enrollments - returns all enrollments", async () => {
    const res = await request(app).get("/api/enrollments");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });
});

describe("Submissions API", () => {
  it("GET /api/submissions - returns all submissions", async () => {
    const res = await request(app).get("/api/submissions");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});

// ─── Root & 404 ─────────────────────────────────────────────────────
describe("Root & Error Handling", () => {
  it("GET / - returns API info", async () => {
    const res = await request(app).get("/");
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("message");
    expect(res.body).toHaveProperty("endpoints");
  });

  it("GET /nonexistent - returns 404", async () => {
    const res = await request(app).get("/nonexistent");
    expect(res.status).toBe(404);
  });
});
