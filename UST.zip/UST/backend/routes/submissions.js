import express from "express";
import { all } from "../db/database.js";

const router = express.Router();

// Get all submissions
router.get("/", async (req, res) => {
  try {
    const submissions = await all(
      "SELECT * FROM submissions ORDER BY submittedAt DESC",
    );
    res.json(submissions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
