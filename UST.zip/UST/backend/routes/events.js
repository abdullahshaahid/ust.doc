import express from "express";
import { run, get, all } from "../db/database.js";

const router = express.Router();

// Get all events
router.get("/", async (req, res) => {
  try {
    const events = await all("SELECT * FROM events ORDER BY date");
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get event by ID
router.get("/:id", async (req, res) => {
  try {
    const event = await get("SELECT * FROM events WHERE id = ?", [
      req.params.id,
    ]);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.json(event);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get events by type
router.get("/type/:type", async (req, res) => {
  try {
    const events = await all(
      "SELECT * FROM events WHERE type = ? ORDER BY date",
      [req.params.type],
    );
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create event
router.post("/", async (req, res) => {
  try {
    const {
      id,
      title,
      description,
      date,
      type,
      location,
      organizer,
      image,
      createdBy,
    } = req.body;

    await run(
      "INSERT INTO events (id, title, description, date, type, location, organizer, image, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        id,
        title,
        description,
        date,
        type,
        location,
        organizer,
        image,
        createdBy,
      ],
    );

    res.status(201).json({ message: "Event created", eventId: id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update event
router.put("/:id", async (req, res) => {
  try {
    const {
      title,
      description,
      date,
      type,
      location,
      organizer,
      image,
      registrationOpen,
    } = req.body;

    const event = await get("SELECT * FROM events WHERE id = ?", [
      req.params.id,
    ]);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }

    await run(
      "UPDATE events SET title = ?, description = ?, date = ?, type = ?, location = ?, organizer = ?, image = ?, registrationOpen = ? WHERE id = ?",
      [
        title || event.title,
        description || event.description,
        date || event.date,
        type || event.type,
        location || event.location,
        organizer || event.organizer,
        image || event.image,
        registrationOpen !== undefined
          ? registrationOpen
          : event.registrationOpen,
        req.params.id,
      ],
    );

    res.json({ message: "Event updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete event
router.delete("/:id", async (req, res) => {
  try {
    const event = await get("SELECT * FROM events WHERE id = ?", [
      req.params.id,
    ]);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }

    await run("DELETE FROM eventRegistrations WHERE eventId = ?", [
      req.params.id,
    ]);
    await run("DELETE FROM events WHERE id = ?", [req.params.id]);

    res.json({ message: "Event deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Register for event
router.post("/:eventId/register", async (req, res) => {
  try {
    const { studentId } = req.body;

    const existing = await get(
      "SELECT * FROM eventRegistrations WHERE eventId = ? AND studentId = ?",
      [req.params.eventId, studentId],
    );
    if (existing) {
      return res.status(400).json({ error: "Already registered" });
    }

    await run(
      "INSERT INTO eventRegistrations (eventId, studentId) VALUES (?, ?)",
      [req.params.eventId, studentId],
    );
    res.status(201).json({ message: "Registered successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Unregister from event
router.delete("/:eventId/unregister", async (req, res) => {
  try {
    const { studentId } = req.body;

    await run(
      "DELETE FROM eventRegistrations WHERE eventId = ? AND studentId = ?",
      [req.params.eventId, studentId],
    );
    res.json({ message: "Unregistered successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get event registrations
router.get("/:eventId/registrations", async (req, res) => {
  try {
    const registrations = await all(
      "SELECT u.* FROM users u INNER JOIN eventRegistrations er ON u.id = er.studentId WHERE er.eventId = ?",
      [req.params.eventId],
    );
    res.json(registrations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
