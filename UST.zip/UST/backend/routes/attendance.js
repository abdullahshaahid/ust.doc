import express from 'express';
import { run, get, all } from '../db/database.js';

const router = express.Router();

// Get all attendance records
router.get('/', async (req, res) => {
    try {
        const attendance = await all('SELECT * FROM attendance ORDER BY date DESC');
        res.json(attendance);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get attendance for a course
router.get('/course/:courseId', async (req, res) => {
    try {
        const attendance = await all('SELECT * FROM attendance WHERE courseId = ? ORDER BY date DESC', [req.params.courseId]);
        res.json(attendance);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get attendance for a student
router.get('/student/:studentId', async (req, res) => {
    try {
        const attendance = await all('SELECT * FROM attendance WHERE studentId = ? ORDER BY date DESC', [req.params.studentId]);
        res.json(attendance);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get attendance percentage for student
router.get('/student/:studentId/percentage', async (req, res) => {
    try {
        const result = await get(`
      SELECT 
        COUNT(CASE WHEN status = 'present' THEN 1 END) as presentDays,
        COUNT(*) as totalDays
      FROM attendance 
      WHERE studentId = ?
    `, [req.params.studentId]);

        const percentage = result.totalDays > 0 ? ((result.presentDays / result.totalDays) * 100).toFixed(2) : 0;

        res.json({
            studentId: req.params.studentId,
            presentDays: result.presentDays,
            totalDays: result.totalDays,
            percentage: parseFloat(percentage)
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get attendance report for course
router.get('/course/:courseId/report', async (req, res) => {
    try {
        const report = await all(`
      SELECT 
        a.studentId,
        u.name,
        COUNT(CASE WHEN a.status = 'present' THEN 1 END) as presentDays,
        COUNT(*) as totalDays,
        ROUND((COUNT(CASE WHEN a.status = 'present' THEN 1 END) * 100.0 / COUNT(*)), 2) as percentage
      FROM attendance a
      INNER JOIN users u ON a.studentId = u.id
      WHERE a.courseId = ?
      GROUP BY a.studentId, u.name
      ORDER BY percentage DESC
    `, [req.params.courseId]);

        res.json(report);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Mark attendance
router.post('/', async (req, res) => {
    try {
        const { courseId, studentId, date, status, markedBy } = req.body;

        const existing = await get('SELECT * FROM attendance WHERE courseId = ? AND studentId = ? AND date = ?', [courseId, studentId, date]);
        if (existing) {
            return res.status(400).json({ error: 'Attendance already marked' });
        }

        await run(
            'INSERT INTO attendance (courseId, studentId, date, status, markedBy) VALUES (?, ?, ?, ?, ?)',
            [courseId, studentId, date, status, markedBy]
        );

        res.status(201).json({ message: 'Attendance marked' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update attendance
router.put('/:id', async (req, res) => {
    try {
        const { status } = req.body;

        const attendance = await get('SELECT * FROM attendance WHERE id = ?', [req.params.id]);
        if (!attendance) {
            return res.status(404).json({ error: 'Attendance record not found' });
        }

        await run('UPDATE attendance SET status = ? WHERE id = ?', [status || attendance.status, req.params.id]);
        res.json({ message: 'Attendance updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete attendance
router.delete('/:id', async (req, res) => {
    try {
        const attendance = await get('SELECT * FROM attendance WHERE id = ?', [req.params.id]);
        if (!attendance) {
            return res.status(404).json({ error: 'Attendance record not found' });
        }

        await run('DELETE FROM attendance WHERE id = ?', [req.params.id]);
        res.json({ message: 'Attendance deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
