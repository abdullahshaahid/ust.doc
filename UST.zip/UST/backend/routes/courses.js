import express from "express";
import { run, get, all } from "../db/database.js";

const router = express.Router();

// Get all courses
router.get("/", async (req, res) => {
  try {
    const courses = await all(`
      SELECT c.*, 
        (SELECT COUNT(*) FROM enrollments WHERE courseId = c.id) as enrolledCount
      FROM courses c
    `);
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get course by ID
router.get("/:id", async (req, res) => {
  try {
    const course = await get(
      `
      SELECT c.*, 
        (SELECT COUNT(*) FROM enrollments WHERE courseId = c.id) as enrolledCount
      FROM courses c 
      WHERE c.id = ?
    `,
      [req.params.id],
    );

    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }

    res.json(course);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get courses by teacher
router.get("/teacher/:teacherId", async (req, res) => {
  try {
    const courses = await all("SELECT * FROM courses WHERE teacherId = ?", [
      req.params.teacherId,
    ]);
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get courses for student
router.get("/student/:studentId", async (req, res) => {
  try {
    const courses = await all(
      `
      SELECT c.* FROM courses c
      INNER JOIN enrollments e ON c.id = e.courseId
      WHERE e.studentId = ?
    `,
      [req.params.studentId],
    );
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get students in course
router.get("/:courseId/students", async (req, res) => {
  try {
    const students = await all(
      `
      SELECT u.* FROM users u
      INNER JOIN enrollments e ON u.id = e.studentId
      WHERE e.courseId = ?
    `,
      [req.params.courseId],
    );
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create course
router.post("/", async (req, res) => {
  try {
    const {
      id,
      name,
      code,
      description,
      department,
      teacherId,
      credits,
      semester,
    } = req.body;

    const existingCourse = await get("SELECT id FROM courses WHERE code = ?", [
      code,
    ]);
    if (existingCourse) {
      return res.status(400).json({ error: "Course code already exists" });
    }

    await run(
      "INSERT INTO courses (id, name, code, description, department, teacherId, credits, semester) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [id, name, code, description, department, teacherId, credits, semester],
    );

    res.status(201).json({ message: "Course created", courseId: id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update course
router.put("/:id", async (req, res) => {
  try {
    const {
      name,
      description,
      credits,
      semester,
      department,
      teacherId,
      code,
    } = req.body;

    const course = await get("SELECT * FROM courses WHERE id = ?", [
      req.params.id,
    ]);
    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }

    await run(
      "UPDATE courses SET name = ?, description = ?, credits = ?, semester = ?, department = ?, teacherId = ?, code = ? WHERE id = ?",
      [
        name || course.name,
        description || course.description,
        credits || course.credits,
        semester || course.semester,
        department || course.department,
        teacherId || course.teacherId,
        code || course.code,
        req.params.id,
      ],
    );

    res.json({ message: "Course updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete course
router.delete("/:id", async (req, res) => {
  try {
    const course = await get("SELECT * FROM courses WHERE id = ?", [
      req.params.id,
    ]);
    if (!course) {
      return res.status(404).json({ error: "Course not found" });
    }

    await run("DELETE FROM enrollments WHERE courseId = ?", [req.params.id]);
    await run("DELETE FROM lectures WHERE courseId = ?", [req.params.id]);
    await run("DELETE FROM assignments WHERE courseId = ?", [req.params.id]);
    await run("DELETE FROM attendance WHERE courseId = ?", [req.params.id]);
    await run("DELETE FROM timetable WHERE courseId = ?", [req.params.id]);
    await run("DELETE FROM courses WHERE id = ?", [req.params.id]);

    res.json({ message: "Course deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enroll student in course
router.post("/:courseId/enroll", async (req, res) => {
  try {
    const { studentId } = req.body;

    const existing = await get(
      "SELECT * FROM enrollments WHERE courseId = ? AND studentId = ?",
      [req.params.courseId, studentId],
    );
    if (existing) {
      return res.status(400).json({ error: "Student already enrolled" });
    }

    await run("INSERT INTO enrollments (courseId, studentId) VALUES (?, ?)", [
      req.params.courseId,
      studentId,
    ]);
    res.status(201).json({ message: "Enrolled successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Unenroll student from course
router.delete("/:courseId/unenroll", async (req, res) => {
  try {
    const { studentId } = req.body;

    await run("DELETE FROM enrollments WHERE courseId = ? AND studentId = ?", [
      req.params.courseId,
      studentId,
    ]);
    res.json({ message: "Unenrolled successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
