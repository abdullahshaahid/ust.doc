import express from "express";
import { all } from "../db/database.js";

const router = express.Router();

// Get all enrollments
router.get("/", async (req, res) => {
  try {
    const enrollments = await all("SELECT * FROM enrollments");
    res.json(enrollments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
