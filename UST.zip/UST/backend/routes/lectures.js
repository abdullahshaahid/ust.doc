import express from "express";
import { run, get, all } from "../db/database.js";

const router = express.Router();

// Get all lectures
router.get("/", async (req, res) => {
  try {
    const lectures = await all(
      "SELECT * FROM lectures ORDER BY uploadedAt DESC",
    );
    res.json(lectures);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get lecture by ID
router.get("/:id", async (req, res) => {
  try {
    const lecture = await get("SELECT * FROM lectures WHERE id = ?", [
      req.params.id,
    ]);
    if (!lecture) {
      return res.status(404).json({ error: "Lecture not found" });
    }
    res.json(lecture);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get lectures for a course
router.get("/course/:courseId", async (req, res) => {
  try {
    const lectures = await all(
      "SELECT * FROM lectures WHERE courseId = ? ORDER BY uploadedAt DESC",
      [req.params.courseId],
    );
    res.json(lectures);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create lecture
router.post("/", async (req, res) => {
  try {
    const { id, courseId, title, description, fileUrl, uploadedBy, videoUrl } =
      req.body;

    await run(
      "INSERT INTO lectures (id, courseId, title, description, fileUrl, uploadedBy, videoUrl) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [id, courseId, title, description, fileUrl, uploadedBy, videoUrl || null],
    );

    res.status(201).json({ message: "Lecture created", lectureId: id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update lecture
router.put("/:id", async (req, res) => {
  try {
    const { title, description, videoUrl, fileUrl, courseId, type } = req.body;

    const lecture = await get("SELECT * FROM lectures WHERE id = ?", [
      req.params.id,
    ]);
    if (!lecture) {
      return res.status(404).json({ error: "Lecture not found" });
    }

    await run(
      "UPDATE lectures SET title = ?, description = ?, videoUrl = ?, fileUrl = ?, courseId = ?, type = ? WHERE id = ?",
      [
        title || lecture.title,
        description || lecture.description,
        videoUrl !== undefined ? videoUrl : lecture.videoUrl,
        fileUrl !== undefined ? fileUrl : lecture.fileUrl,
        courseId || lecture.courseId,
        type || lecture.type,
        req.params.id,
      ],
    );

    res.json({ message: "Lecture updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete lecture
router.delete("/:id", async (req, res) => {
  try {
    const lecture = await get("SELECT * FROM lectures WHERE id = ?", [
      req.params.id,
    ]);
    if (!lecture) {
      return res.status(404).json({ error: "Lecture not found" });
    }

    await run("DELETE FROM lectures WHERE id = ?", [req.params.id]);
    res.json({ message: "Lecture deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Track lecture download
router.post("/:id/download", async (req, res) => {
  try {
    const lecture = await get("SELECT * FROM lectures WHERE id = ?", [
      req.params.id,
    ]);
    if (!lecture) {
      return res.status(404).json({ error: "Lecture not found" });
    }

    res.json({ message: "Download tracked", fileUrl: lecture.fileUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
