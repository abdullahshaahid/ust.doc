import express from 'express';
import { run, get, all } from '../db/database.js';

const router = express.Router();

// Get all roadmap items
router.get('/', async (req, res) => {
    try {
        const roadmap = await all('SELECT * FROM roadmap ORDER BY semester');
        res.json(roadmap);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get roadmap item by ID
router.get('/:id', async (req, res) => {
    try {
        const item = await get('SELECT * FROM roadmap WHERE id = ?', [req.params.id]);
        if (!item) {
            return res.status(404).json({ error: 'Roadmap item not found' });
        }
        res.json(item);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get roadmap for a department
router.get('/department/:department', async (req, res) => {
    try {
        const roadmap = await all('SELECT * FROM roadmap WHERE department = ? ORDER BY semester', [req.params.department]);
        res.json(roadmap);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get roadmap for a semester
router.get('/semester/:semester', async (req, res) => {
    try {
        const roadmap = await all('SELECT * FROM roadmap WHERE semester = ?', [req.params.semester]);
        res.json(roadmap);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create roadmap item
router.post('/', async (req, res) => {
    try {
        const { id, title, description, department, semester, skills, resources, projects } = req.body;

        await run(
            'INSERT INTO roadmap (id, title, description, department, semester, skills, resources, projects) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [id, title, description, department, semester, skills, resources, projects]
        );

        res.status(201).json({ message: 'Roadmap item created', itemId: id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update roadmap item
router.put('/:id', async (req, res) => {
    try {
        const { title, description, skills, resources, projects } = req.body;

        const item = await get('SELECT * FROM roadmap WHERE id = ?', [req.params.id]);
        if (!item) {
            return res.status(404).json({ error: 'Roadmap item not found' });
        }

        await run(
            'UPDATE roadmap SET title = ?, description = ?, skills = ?, resources = ?, projects = ? WHERE id = ?',
            [title || item.title, description || item.description, skills || item.skills, resources || item.resources, projects || item.projects, req.params.id]
        );

        res.json({ message: 'Roadmap item updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete roadmap item
router.delete('/:id', async (req, res) => {
    try {
        const item = await get('SELECT * FROM roadmap WHERE id = ?', [req.params.id]);
        if (!item) {
            return res.status(404).json({ error: 'Roadmap item not found' });
        }

        await run('DELETE FROM roadmap WHERE id = ?', [req.params.id]);
        res.json({ message: 'Roadmap item deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
