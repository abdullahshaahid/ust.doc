import express from 'express';
import { get, all } from '../db/database.js';

const router = express.Router();

// Get dashboard statistics
router.get('/dashboard', async (req, res) => {
    try {
        const totalUsers = await get('SELECT COUNT(*) as count FROM users');
        const totalStudents = await get('SELECT COUNT(*) as count FROM users WHERE role = ?', ['student']);
        const totalTeachers = await get('SELECT COUNT(*) as count FROM users WHERE role = ?', ['teacher']);
        const totalCourses = await get('SELECT COUNT(*) as count FROM courses');
        const totalEnrollments = await get('SELECT COUNT(*) as count FROM enrollments');

        res.json({
            totalUsers: totalUsers.count,
            totalStudents: totalStudents.count,
            totalTeachers: totalTeachers.count,
            totalCourses: totalCourses.count,
            totalEnrollments: totalEnrollments.count
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get user statistics
router.get('/users', async (req, res) => {
    try {
        const byRole = await all(`
      SELECT role, COUNT(*) as count FROM users GROUP BY role
    `);

        const byDepartment = await all(`
      SELECT department, COUNT(*) as count FROM users WHERE department IS NOT NULL GROUP BY department
    `);

        res.json({ byRole, byDepartment });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get course enrollment statistics
router.get('/courses', async (req, res) => {
    try {
        const courseStats = await all(`
      SELECT 
        c.id,
        c.name,
        c.code,
        COUNT(e.studentId) as enrolledStudents
      FROM courses c
      LEFT JOIN enrollments e ON c.id = e.courseId
      GROUP BY c.id, c.name, c.code
      ORDER BY enrolledStudents DESC
    `);

        res.json(courseStats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get attendance summary
router.get('/attendance-summary', async (req, res) => {
    try {
        const summary = await all(`
      SELECT 
        courseId,
        COUNT(CASE WHEN status = 'present' THEN 1 END) as presentCount,
        COUNT(CASE WHEN status = 'absent' THEN 1 END) as absentCount,
        COUNT(CASE WHEN status = 'late' THEN 1 END) as lateCount,
        COUNT(*) as totalRecords
      FROM attendance
      GROUP BY courseId
    `);

        res.json(summary);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get performance metrics
router.get('/performance', async (req, res) => {
    try {
        const topPerformers = await all(`
      SELECT 
        u.id,
        u.name,
        AVG(g.marks) as averageMarks,
        COUNT(g.courseId) as coursesCompleted
      FROM users u
      LEFT JOIN grades g ON u.id = g.studentId
      WHERE u.role = 'student'
      GROUP BY u.id, u.name
      ORDER BY averageMarks DESC
      LIMIT 10
    `);

        res.json(topPerformers);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Generate custom report
router.post('/report', async (req, res) => {
    try {
        const { reportType, filters } = req.body;

        let query = '';
        const params = [];

        if (reportType === 'student-performance') {
            query = `
        SELECT 
          u.id, u.name, u.email,
          COUNT(e.courseId) as coursesEnrolled,
          ROUND(AVG(g.marks), 2) as averageGrade
        FROM users u
        LEFT JOIN enrollments e ON u.id = e.studentId
        LEFT JOIN grades g ON u.id = g.studentId
        WHERE u.role = 'student'
      `;

            if (filters?.department) {
                query += ' AND u.department = ?';
                params.push(filters.department);
            }

            query += ' GROUP BY u.id, u.name, u.email';
        } else if (reportType === 'course-performance') {
            query = `
        SELECT 
          c.id, c.name, c.code,
          COUNT(DISTINCT e.studentId) as enrolledStudents,
          ROUND(AVG(g.marks), 2) as averageGrade,
          COUNT(s.id) as totalSubmissions
        FROM courses c
        LEFT JOIN enrollments e ON c.id = e.courseId
        LEFT JOIN grades g ON c.id = g.courseId
        LEFT JOIN submissions s ON c.id = (SELECT courseId FROM assignments WHERE id = s.assignmentId)
      `;

            if (filters?.department) {
                query += ' WHERE c.department = ?';
                params.push(filters.department);
            }

            query += ' GROUP BY c.id, c.name, c.code';
        }

        const report = await all(query, params);
        res.json({ reportType, data: report });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
