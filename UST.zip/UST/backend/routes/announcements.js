import express from "express";
import { run, get, all } from "../db/database.js";

const router = express.Router();

// Get all announcements
router.get("/", async (req, res) => {
  try {
    const announcements = await all(
      "SELECT * FROM announcements WHERE isActive = 1 ORDER BY createdAt DESC",
    );
    res.json(announcements);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get announcement by ID
router.get("/:id", async (req, res) => {
  try {
    const announcement = await get("SELECT * FROM announcements WHERE id = ?", [
      req.params.id,
    ]);
    if (!announcement) {
      return res.status(404).json({ error: "Announcement not found" });
    }
    res.json(announcement);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get announcements by role
router.get("/role/:role", async (req, res) => {
  try {
    const announcements = await all(
      "SELECT * FROM announcements WHERE (targetRole = ? OR targetRole = ?) AND isActive = 1 ORDER BY priority DESC, createdAt DESC",
      [req.params.role, "all"],
    );
    res.json(announcements);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create announcement
router.post("/", async (req, res) => {
  try {
    const { id, title, content, targetRole, priority, createdBy } = req.body;

    await run(
      "INSERT INTO announcements (id, title, content, targetRole, priority, createdBy) VALUES (?, ?, ?, ?, ?, ?)",
      [id, title, content, targetRole, priority || "medium", createdBy],
    );

    res
      .status(201)
      .json({ message: "Announcement created", announcementId: id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update announcement
router.put("/:id", async (req, res) => {
  try {
    const { title, content, priority, targetRole, isActive } = req.body;

    const announcement = await get("SELECT * FROM announcements WHERE id = ?", [
      req.params.id,
    ]);
    if (!announcement) {
      return res.status(404).json({ error: "Announcement not found" });
    }

    await run(
      "UPDATE announcements SET title = ?, content = ?, priority = ?, targetRole = ?, isActive = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?",
      [
        title || announcement.title,
        content || announcement.content,
        priority || announcement.priority,
        targetRole || announcement.targetRole,
        isActive !== undefined ? isActive : announcement.isActive,
        req.params.id,
      ],
    );

    res.json({ message: "Announcement updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update announcement status
router.put("/:id/status", async (req, res) => {
  try {
    const { isActive } = req.body;

    const announcement = await get("SELECT * FROM announcements WHERE id = ?", [
      req.params.id,
    ]);
    if (!announcement) {
      return res.status(404).json({ error: "Announcement not found" });
    }

    await run("UPDATE announcements SET isActive = ? WHERE id = ?", [
      isActive,
      req.params.id,
    ]);
    res.json({ message: "Announcement status updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete announcement
router.delete("/:id", async (req, res) => {
  try {
    const announcement = await get("SELECT * FROM announcements WHERE id = ?", [
      req.params.id,
    ]);
    if (!announcement) {
      return res.status(404).json({ error: "Announcement not found" });
    }

    await run("DELETE FROM announcements WHERE id = ?", [req.params.id]);
    res.json({ message: "Announcement deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
