import express from "express";
import { run, get, all } from "../db/database.js";

const router = express.Router();

// Get all users with optional filters
router.get("/", async (req, res) => {
  try {
    const { role, department } = req.query;
    let query = "SELECT * FROM users";
    const params = [];

    if (role) {
      query += " WHERE role = ?";
      params.push(role);
    } else if (department) {
      query += " WHERE department = ?";
      params.push(department);
    }

    const users = await all(query, params);
    res.json(
      users.map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        department: u.department,
        phone: u.phone,
        joinDate: u.joinDate,
        teacherId: u.teacherId,
      })),
    );
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get user by ID
router.get("/:id", async (req, res) => {
  try {
    const user = await get("SELECT * FROM users WHERE id = ?", [req.params.id]);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      phone: user.phone,
      joinDate: user.joinDate,
      teacherId: user.teacherId,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get users by role
router.get("/role/:role", async (req, res) => {
  try {
    const users = await all("SELECT * FROM users WHERE role = ?", [
      req.params.role,
    ]);
    res.json(
      users.map((u) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        department: u.department,
      })),
    );
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get users by department
router.get("/department/:dept", async (req, res) => {
  try {
    const users = await all("SELECT * FROM users WHERE department = ?", [
      req.params.dept,
    ]);
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create user
router.post("/", async (req, res) => {
  try {
    const { id, name, email, password, role, department, phone, teacherId } =
      req.body;

    const existingUser = await get("SELECT id FROM users WHERE email = ?", [
      email,
    ]);
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    const joinDate = new Date().toISOString().split("T")[0];
    await run(
      "INSERT INTO users (id, name, email, password, role, department, phone, joinDate, teacherId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [id, name, email, password, role, department, phone, joinDate, teacherId],
    );

    res.status(201).json({ message: "User created", userId: id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update user
router.put("/:id", async (req, res) => {
  try {
    const {
      name,
      email,
      department,
      phone,
      role,
      password,
      teacherId,
      avatar,
    } = req.body;

    const user = await get("SELECT * FROM users WHERE id = ?", [req.params.id]);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    await run(
      "UPDATE users SET name = ?, email = ?, department = ?, phone = ?, role = ?, password = ?, teacherId = ?, avatar = ? WHERE id = ?",
      [
        name || user.name,
        email || user.email,
        department || user.department,
        phone || user.phone,
        role || user.role,
        password || user.password,
        teacherId !== undefined ? teacherId : user.teacherId,
        avatar !== undefined ? avatar : user.avatar,
        req.params.id,
      ],
    );

    res.json({ message: "User updated" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete user
router.delete("/:id", async (req, res) => {
  try {
    const user = await get("SELECT * FROM users WHERE id = ?", [req.params.id]);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Delete related data
    await run("DELETE FROM enrollments WHERE studentId = ?", [req.params.id]);
    await run("DELETE FROM submissions WHERE studentId = ?", [req.params.id]);
    await run("DELETE FROM attendance WHERE studentId = ?", [req.params.id]);
    await run("DELETE FROM eventRegistrations WHERE studentId = ?", [
      req.params.id,
    ]);
    await run("DELETE FROM users WHERE id = ?", [req.params.id]);

    res.json({ message: "User deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
