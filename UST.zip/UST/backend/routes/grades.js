import express from 'express';
import { run, get, all } from '../db/database.js';

const router = express.Router();

// Get grades for a student
router.get('/student/:studentId', async (req, res) => {
    try {
        const grades = await all(`
      SELECT 
        g.*,
        c.name as courseName,
        c.code as courseCode
      FROM grades g
      INNER JOIN courses c ON g.courseId = c.id
      WHERE g.studentId = ?
      ORDER BY c.code
    `, [req.params.studentId]);

        let totalCredits = 0;
        let totalPoints = 0;

        const gradeScale = {
            'A': 4.0, 'B': 3.0, 'C': 2.0, 'D': 1.0, 'F': 0.0
        };

        for (const grade of grades) {
            const points = gradeScale[grade.grade] || 0;
            totalPoints += points * grade.credits;
            totalCredits += grade.credits;
        }

        const cgpa = totalCredits > 0 ? (totalPoints / totalCredits).toFixed(2) : 0;

        res.json({
            studentId: req.params.studentId,
            grades,
            cgpa: parseFloat(cgpa),
            totalCredits
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get grades for a course
router.get('/course/:courseId', async (req, res) => {
    try {
        const grades = await all(`
      SELECT 
        g.*,
        u.name as studentName,
        u.email as studentEmail
      FROM grades g
      INNER JOIN users u ON g.studentId = u.id
      WHERE g.courseId = ?
      ORDER BY u.name
    `, [req.params.courseId]);

        res.json(grades);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Record grade
router.post('/', async (req, res) => {
    try {
        const { studentId, courseId, grade, marks, credits } = req.body;

        const existing = await get('SELECT * FROM grades WHERE studentId = ? AND courseId = ?', [studentId, courseId]);

        if (existing) {
            await run(
                'UPDATE grades SET grade = ?, marks = ? WHERE studentId = ? AND courseId = ?',
                [grade, marks, studentId, courseId]
            );
        } else {
            await run(
                'INSERT INTO grades (studentId, courseId, grade, marks, credits) VALUES (?, ?, ?, ?, ?)',
                [studentId, courseId, grade, marks, credits]
            );
        }

        res.json({ message: 'Grade recorded' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
