import express from 'express';
import { run, get, all } from '../db/database.js';
import { generateToken, verifyToken } from '../middleware/auth.js';

const router = express.Router();

// Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await get('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);

        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = generateToken(user);
        res.json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                department: user.department
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get current user
router.get('/me', async (req, res) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ error: 'No token provided' });
        }

        const decoded = verifyToken(token);
        if (!decoded) {
            return res.status(401).json({ error: 'Invalid token' });
        }

        const user = await get('SELECT * FROM users WHERE id = ?', [decoded.id]);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            department: user.department,
            phone: user.phone,
            joinDate: user.joinDate
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Logout (client-side token deletion handled by frontend)
router.post('/logout', (req, res) => {
    res.json({ message: 'Logged out successfully' });
});

// Register new user (admin only)
router.post('/register', async (req, res) => {
    try {
        const { id, name, email, password, role, department, phone, teacherId } = req.body;

        // Validate required fields
        if (!id || !name || !email || !password || !role) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        // Check if user already exists
        const existingUser = await get('SELECT id FROM users WHERE email = ?', [email]);
        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }

        const joinDate = new Date().toISOString().split('T')[0];
        await run(
            'INSERT INTO users (id, name, email, password, role, department, phone, joinDate, teacherId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [id, name, email, password, role, department || null, phone || null, joinDate, teacherId || null]
        );

        res.status(201).json({ message: 'User created successfully', userId: id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Refresh token
router.post('/refresh', (req, res) => {
    try {
        const { token } = req.body;
        const decoded = verifyToken(token);

        if (!decoded) {
            return res.status(401).json({ error: 'Invalid token' });
        }

        const newToken = generateToken(decoded);
        res.json({ token: newToken });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
