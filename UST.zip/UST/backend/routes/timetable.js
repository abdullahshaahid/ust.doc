import express from 'express';
import { run, get, all } from '../db/database.js';

const router = express.Router();

// Get all timetable entries
router.get('/', async (req, res) => {
    try {
        const timetable = await all('SELECT * FROM timetable ORDER BY day, startTime');
        res.json(timetable);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get timetable entry by ID
router.get('/:id', async (req, res) => {
    try {
        const entry = await get('SELECT * FROM timetable WHERE id = ?', [req.params.id]);
        if (!entry) {
            return res.status(404).json({ error: 'Timetable entry not found' });
        }
        res.json(entry);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get timetable for a course
router.get('/course/:courseId', async (req, res) => {
    try {
        const timetable = await all('SELECT * FROM timetable WHERE courseId = ? ORDER BY day, startTime', [req.params.courseId]);
        res.json(timetable);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get timetable for a day
router.get('/day/:day', async (req, res) => {
    try {
        const timetable = await all('SELECT * FROM timetable WHERE day = ? ORDER BY startTime', [req.params.day]);
        res.json(timetable);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get student's timetable
router.get('/student/:studentId', async (req, res) => {
    try {
        const timetable = await all(`
      SELECT t.* FROM timetable t
      INNER JOIN courses c ON t.courseId = c.id
      INNER JOIN enrollments e ON c.id = e.courseId
      WHERE e.studentId = ?
      ORDER BY t.day, t.startTime
    `, [req.params.studentId]);
        res.json(timetable);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create timetable entry
router.post('/', async (req, res) => {
    try {
        const { id, courseId, day, startTime, endTime, room, type } = req.body;

        await run(
            'INSERT INTO timetable (id, courseId, day, startTime, endTime, room, type) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, courseId, day, startTime, endTime, room, type]
        );

        res.status(201).json({ message: 'Timetable entry created', entryId: id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update timetable entry
router.put('/:id', async (req, res) => {
    try {
        const { day, startTime, endTime, room, type } = req.body;

        const entry = await get('SELECT * FROM timetable WHERE id = ?', [req.params.id]);
        if (!entry) {
            return res.status(404).json({ error: 'Timetable entry not found' });
        }

        await run(
            'UPDATE timetable SET day = ?, startTime = ?, endTime = ?, room = ?, type = ? WHERE id = ?',
            [day || entry.day, startTime || entry.startTime, endTime || entry.endTime, room || entry.room, type || entry.type, req.params.id]
        );

        res.json({ message: 'Timetable entry updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete timetable entry
router.delete('/:id', async (req, res) => {
    try {
        const entry = await get('SELECT * FROM timetable WHERE id = ?', [req.params.id]);
        if (!entry) {
            return res.status(404).json({ error: 'Timetable entry not found' });
        }

        await run('DELETE FROM timetable WHERE id = ?', [req.params.id]);
        res.json({ message: 'Timetable entry deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
