import express from "express";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "..", "data");

const router = express.Router();

let homepageData = null;

function getHomepageData() {
  if (!homepageData) {
    homepageData = JSON.parse(
      readFileSync(join(dataDir, "homepage.json"), "utf-8"),
    );
  }
  return homepageData;
}

// Get all homepage data
router.get("/", (req, res) => {
  try {
    res.json(getHomepageData());
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get a specific section
router.get("/:section", (req, res) => {
  try {
    const data = getHomepageData();
    const section = data[req.params.section];
    if (!section) {
      return res.status(404).json({ error: "Section not found" });
    }
    res.json(section);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
