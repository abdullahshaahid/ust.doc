import express from 'express';
import { run, get, all } from '../db/database.js';

const router = express.Router();

// Get all assignments
router.get('/', async (req, res) => {
    try {
        const assignments = await all('SELECT * FROM assignments ORDER BY dueDate');
        res.json(assignments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get assignment by ID
router.get('/:id', async (req, res) => {
    try {
        const assignment = await get('SELECT * FROM assignments WHERE id = ?', [req.params.id]);
        if (!assignment) {
            return res.status(404).json({ error: 'Assignment not found' });
        }
        res.json(assignment);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get assignments for a course
router.get('/course/:courseId', async (req, res) => {
    try {
        const assignments = await all('SELECT * FROM assignments WHERE courseId = ? ORDER BY dueDate', [req.params.courseId]);
        res.json(assignments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get assignments for a student
router.get('/student/:studentId', async (req, res) => {
    try {
        const assignments = await all(`
      SELECT a.* FROM assignments a
      INNER JOIN enrollments e ON a.courseId = e.courseId
      WHERE e.studentId = ?
      ORDER BY a.dueDate
    `, [req.params.studentId]);
        res.json(assignments);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create assignment
router.post('/', async (req, res) => {
    try {
        const { id, courseId, title, description, dueDate, totalMarks, createdBy } = req.body;

        await run(
            'INSERT INTO assignments (id, courseId, title, description, dueDate, totalMarks, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [id, courseId, title, description, dueDate, totalMarks, createdBy]
        );

        res.status(201).json({ message: 'Assignment created', assignmentId: id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update assignment
router.put('/:id', async (req, res) => {
    try {
        const { title, description, dueDate, totalMarks } = req.body;

        const assignment = await get('SELECT * FROM assignments WHERE id = ?', [req.params.id]);
        if (!assignment) {
            return res.status(404).json({ error: 'Assignment not found' });
        }

        await run(
            'UPDATE assignments SET title = ?, description = ?, dueDate = ?, totalMarks = ? WHERE id = ?',
            [title || assignment.title, description || assignment.description, dueDate || assignment.dueDate, totalMarks || assignment.totalMarks, req.params.id]
        );

        res.json({ message: 'Assignment updated' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete assignment
router.delete('/:id', async (req, res) => {
    try {
        const assignment = await get('SELECT * FROM assignments WHERE id = ?', [req.params.id]);
        if (!assignment) {
            return res.status(404).json({ error: 'Assignment not found' });
        }

        await run('DELETE FROM submissions WHERE assignmentId = ?', [req.params.id]);
        await run('DELETE FROM assignments WHERE id = ?', [req.params.id]);

        res.json({ message: 'Assignment deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Submit assignment
router.post('/:assignmentId/submit', async (req, res) => {
    try {
        const { studentId, content, fileUrl } = req.body;

        const existing = await get('SELECT * FROM submissions WHERE assignmentId = ? AND studentId = ?', [req.params.assignmentId, studentId]);

        if (existing) {
            await run(
                'UPDATE submissions SET content = ?, fileUrl = ?, submittedAt = CURRENT_TIMESTAMP, status = ? WHERE assignmentId = ? AND studentId = ?',
                [content, fileUrl, 'submitted', req.params.assignmentId, studentId]
            );
        } else {
            await run(
                'INSERT INTO submissions (assignmentId, studentId, content, fileUrl, status) VALUES (?, ?, ?, ?, ?)',
                [req.params.assignmentId, studentId, content, fileUrl, 'submitted']
            );
        }

        res.json({ message: 'Assignment submitted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all submissions for an assignment
router.get('/:assignmentId/submissions', async (req, res) => {
    try {
        const submissions = await all(
            'SELECT * FROM submissions WHERE assignmentId = ? ORDER BY submittedAt DESC',
            [req.params.assignmentId]
        );
        res.json(submissions);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get student's submission
router.get('/:assignmentId/submission/:studentId', async (req, res) => {
    try {
        const submission = await get(
            'SELECT * FROM submissions WHERE assignmentId = ? AND studentId = ?',
            [req.params.assignmentId, req.params.studentId]
        );

        if (!submission) {
            return res.status(404).json({ error: 'Submission not found' });
        }

        res.json(submission);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Grade submission
router.put('/:assignmentId/grade/:studentId', async (req, res) => {
    try {
        const { marks, feedback, gradedBy } = req.body;

        const submission = await get(
            'SELECT * FROM submissions WHERE assignmentId = ? AND studentId = ?',
            [req.params.assignmentId, req.params.studentId]
        );

        if (!submission) {
            return res.status(404).json({ error: 'Submission not found' });
        }

        await run(
            'UPDATE submissions SET marks = ?, feedback = ?, status = ?, gradedAt = CURRENT_TIMESTAMP, gradedBy = ? WHERE assignmentId = ? AND studentId = ?',
            [marks, feedback, 'graded', gradedBy, req.params.assignmentId, req.params.studentId]
        );

        res.json({ message: 'Submission graded' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
