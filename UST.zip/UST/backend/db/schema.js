import { run, all } from "../db/database.js";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "..", "data");

function loadJSON(filename) {
  return JSON.parse(readFileSync(join(dataDir, filename), "utf-8"));
}

export const createTables = async () => {
  try {
    // Users table
    await run(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'teacher', 'student')),
        department TEXT,
        phone TEXT,
        joinDate TEXT,
        avatar TEXT,
        teacherId TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Courses table
    await run(`
      CREATE TABLE IF NOT EXISTS courses (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT UNIQUE NOT NULL,
        description TEXT,
        department TEXT,
        teacherId TEXT NOT NULL,
        credits INTEGER,
        semester INTEGER,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (teacherId) REFERENCES users(id)
      )
    `);

    // Course Enrollments
    await run(`
      CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        courseId TEXT NOT NULL,
        studentId TEXT NOT NULL,
        enrolledAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (courseId) REFERENCES courses(id),
        FOREIGN KEY (studentId) REFERENCES users(id),
        UNIQUE(courseId, studentId)
      )
    `);

    // Lectures table
    await run(`
      CREATE TABLE IF NOT EXISTS lectures (
        id TEXT PRIMARY KEY,
        courseId TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        type TEXT,
        fileUrl TEXT,
        fileSize TEXT,
        uploadedBy TEXT NOT NULL,
        uploadedAt TEXT DEFAULT CURRENT_TIMESTAMP,
        videoUrl TEXT,
        duration INTEGER,
        FOREIGN KEY (courseId) REFERENCES courses(id),
        FOREIGN KEY (uploadedBy) REFERENCES users(id)
      )
    `);

    // Assignments table
    await run(`
      CREATE TABLE IF NOT EXISTS assignments (
        id TEXT PRIMARY KEY,
        courseId TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        dueDate TEXT NOT NULL,
        totalMarks INTEGER,
        createdBy TEXT NOT NULL,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (courseId) REFERENCES courses(id),
        FOREIGN KEY (createdBy) REFERENCES users(id)
      )
    `);

    // Assignment Submissions
    await run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        assignmentId TEXT NOT NULL,
        studentId TEXT NOT NULL,
        content TEXT,
        fileUrl TEXT,
        submittedAt TEXT DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'submitted' CHECK(status IN ('submitted', 'graded', 'late')),
        marks INTEGER,
        feedback TEXT,
        gradedAt TEXT,
        gradedBy TEXT,
        FOREIGN KEY (assignmentId) REFERENCES assignments(id),
        FOREIGN KEY (studentId) REFERENCES users(id),
        FOREIGN KEY (gradedBy) REFERENCES users(id),
        UNIQUE(assignmentId, studentId)
      )
    `);

    // Attendance table
    await run(`
      CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        courseId TEXT NOT NULL,
        studentId TEXT NOT NULL,
        date TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('present', 'absent', 'late')),
        markedBy TEXT NOT NULL,
        markedAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (courseId) REFERENCES courses(id),
        FOREIGN KEY (studentId) REFERENCES users(id),
        FOREIGN KEY (markedBy) REFERENCES users(id),
        UNIQUE(courseId, studentId, date)
      )
    `);

    // Announcements table
    await run(`
      CREATE TABLE IF NOT EXISTS announcements (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        targetRole TEXT NOT NULL CHECK(targetRole IN ('all', 'admin', 'teacher', 'student')),
        priority TEXT DEFAULT 'medium' CHECK(priority IN ('low', 'medium', 'high')),
        isActive BOOLEAN DEFAULT 1,
        createdBy TEXT NOT NULL,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        updatedAt TEXT,
        FOREIGN KEY (createdBy) REFERENCES users(id)
      )
    `);

    // Events table
    await run(`
      CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('academic', 'sports', 'trip', 'cultural', 'workshop', 'seminar', 'competition', 'fest', 'other')),
        location TEXT,
        organizer TEXT,
        image TEXT,
        registrationOpen BOOLEAN DEFAULT 1,
        createdBy TEXT NOT NULL,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (createdBy) REFERENCES users(id)
      )
    `);

    // Event Registrations
    await run(`
      CREATE TABLE IF NOT EXISTS eventRegistrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        eventId TEXT NOT NULL,
        studentId TEXT NOT NULL,
        registeredAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (eventId) REFERENCES events(id),
        FOREIGN KEY (studentId) REFERENCES users(id),
        UNIQUE(eventId, studentId)
      )
    `);

    // Roadmap table
    await run(`
      CREATE TABLE IF NOT EXISTS roadmap (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        department TEXT NOT NULL,
        semester INTEGER NOT NULL,
        courses TEXT,
        outcomes TEXT,
        skills TEXT,
        resources TEXT,
        projects TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Timetable entries
    await run(`
      CREATE TABLE IF NOT EXISTS timetable (
        id TEXT PRIMARY KEY,
        courseId TEXT NOT NULL,
        day TEXT NOT NULL CHECK(day IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')),
        startTime TEXT NOT NULL,
        endTime TEXT NOT NULL,
        room TEXT,
        type TEXT NOT NULL CHECK(type IN ('lecture', 'lab', 'tutorial')),
        FOREIGN KEY (courseId) REFERENCES courses(id)
      )
    `);

    // Grades table
    await run(`
      CREATE TABLE IF NOT EXISTS grades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        studentId TEXT NOT NULL,
        courseId TEXT NOT NULL,
        grade TEXT,
        marks REAL,
        credits INTEGER,
        recordedAt TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (studentId) REFERENCES users(id),
        FOREIGN KEY (courseId) REFERENCES courses(id),
        UNIQUE(studentId, courseId)
      )
    `);

    console.log("✅ All tables created successfully");
  } catch (error) {
    console.error("❌ Error creating tables:", error);
    throw error;
  }
};

export const seedDatabase = async () => {
  try {
    // Only seed if the database is empty (first run)
    const existingUsers = await all("SELECT COUNT(*) as count FROM users");
    if (existingUsers[0].count > 0) {
      console.log("✅ Database already has data, skipping seed");
      return;
    }

    // Load JSON data files
    const usersData = loadJSON("users.json");
    const coursesData = loadJSON("courses.json");
    const lecturesData = loadJSON("lectures.json");
    const assignmentsData = loadJSON("assignments.json");
    const attendanceData = loadJSON("attendance.json");
    const announcementsData = loadJSON("announcements.json");
    const eventsData = loadJSON("events.json");
    const roadmapData = loadJSON("roadmap.json");
    const timetableData = loadJSON("timetable.json");

    // Seed Users
    for (const user of usersData) {
      await run(
        "INSERT INTO users (id, name, email, password, role, department, phone, joinDate, avatar, teacherId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          user.id,
          user.name,
          user.email,
          user.password,
          user.role,
          user.department || null,
          user.phone || null,
          user.joinDate || null,
          user.avatar || null,
          user.teacherId || null,
        ],
      );
    }
    console.log(`  ✅ Seeded ${usersData.length} users`);

    // Seed Courses
    for (const course of coursesData) {
      await run(
        "INSERT INTO courses (id, name, code, description, department, teacherId, credits, semester) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          course.id,
          course.name,
          course.code,
          course.description,
          course.department,
          course.teacherId,
          course.credits,
          course.semester,
        ],
      );
    }
    console.log(`  ✅ Seeded ${coursesData.length} courses`);

    // Seed Enrollments from courses.enrolledStudents arrays
    let enrollmentCount = 0;
    for (const course of coursesData) {
      if (course.enrolledStudents) {
        for (const studentId of course.enrolledStudents) {
          const studentExists = usersData.some((u) => u.id === studentId);
          if (studentExists) {
            await run(
              "INSERT OR IGNORE INTO enrollments (courseId, studentId) VALUES (?, ?)",
              [course.id, studentId],
            );
            enrollmentCount++;
          }
        }
      }
    }
    console.log(`  ✅ Seeded ${enrollmentCount} enrollments`);

    // Seed Lectures
    for (const lec of lecturesData) {
      await run(
        "INSERT INTO lectures (id, courseId, title, description, type, fileUrl, fileSize, uploadedBy, uploadedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          lec.id,
          lec.courseId,
          lec.title,
          lec.description,
          lec.type || null,
          lec.url || lec.fileUrl || null,
          lec.size || null,
          lec.uploadedBy,
          lec.uploadedAt || null,
        ],
      );
    }
    console.log(`  ✅ Seeded ${lecturesData.length} lectures`);

    // Seed Assignments with their submissions
    let submissionCount = 0;
    for (const asgn of assignmentsData) {
      const course = coursesData.find((c) => c.id === asgn.courseId);
      const createdBy = course ? course.teacherId : "teacher1";

      await run(
        "INSERT INTO assignments (id, courseId, title, description, dueDate, totalMarks, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          asgn.id,
          asgn.courseId,
          asgn.title,
          asgn.description,
          asgn.dueDate,
          asgn.totalMarks,
          createdBy,
        ],
      );

      if (asgn.submissions && asgn.submissions.length > 0) {
        for (const sub of asgn.submissions) {
          await run(
            "INSERT INTO submissions (assignmentId, studentId, content, submittedAt, status, marks, feedback, gradedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
              asgn.id,
              sub.studentId,
              sub.content || null,
              sub.submittedAt || null,
              sub.status || "submitted",
              sub.marks || null,
              sub.feedback || null,
              sub.status === "graded" ? createdBy : null,
            ],
          );
          submissionCount++;
        }
      }
    }
    console.log(
      `  ✅ Seeded ${assignmentsData.length} assignments with ${submissionCount} submissions`,
    );

    // Seed Attendance
    let attendanceCount = 0;
    for (const att of attendanceData) {
      const course = coursesData.find((c) => c.id === att.courseId);
      const markedBy = course ? course.teacherId : "teacher1";

      for (const record of att.records) {
        await run(
          "INSERT INTO attendance (courseId, studentId, date, status, markedBy) VALUES (?, ?, ?, ?, ?)",
          [att.courseId, record.studentId, att.date, record.status, markedBy],
        );
        attendanceCount++;
      }
    }
    console.log(`  ✅ Seeded ${attendanceCount} attendance records`);

    // Seed Announcements
    for (const ann of announcementsData) {
      await run(
        "INSERT INTO announcements (id, title, content, targetRole, priority, isActive, createdBy, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
          ann.id,
          ann.title,
          ann.content,
          ann.targetRole,
          ann.priority || "medium",
          ann.isActive !== undefined ? (ann.isActive ? 1 : 0) : 1,
          ann.createdBy,
          ann.createdAt || null,
        ],
      );
    }
    console.log(`  ✅ Seeded ${announcementsData.length} announcements`);

    // Seed Events
    for (const evt of eventsData) {
      await run(
        "INSERT INTO events (id, title, description, date, type, location, organizer, image, registrationOpen, createdBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
          evt.id,
          evt.title,
          evt.description,
          evt.date,
          evt.type,
          evt.location || null,
          evt.organizer || null,
          evt.image || null,
          evt.registrationOpen !== undefined
            ? evt.registrationOpen
              ? 1
              : 0
            : 1,
          "admin1",
        ],
      );
    }
    console.log(`  ✅ Seeded ${eventsData.length} events`);

    // Seed Roadmap
    for (const rm of roadmapData) {
      await run(
        "INSERT INTO roadmap (id, title, description, department, semester, courses, outcomes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          rm.id,
          rm.title,
          rm.description,
          rm.department,
          rm.semester,
          Array.isArray(rm.courses)
            ? rm.courses.join(", ")
            : rm.courses || null,
          Array.isArray(rm.outcomes)
            ? rm.outcomes.join(", ")
            : rm.outcomes || null,
        ],
      );
    }
    console.log(`  ✅ Seeded ${roadmapData.length} roadmap items`);

    // Seed Timetable
    for (const tt of timetableData) {
      await run(
        "INSERT INTO timetable (id, courseId, day, startTime, endTime, room, type) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          tt.id,
          tt.courseId,
          tt.day,
          tt.startTime,
          tt.endTime,
          tt.room,
          tt.type,
        ],
      );
    }
    console.log(`  ✅ Seeded ${timetableData.length} timetable entries`);

    console.log("✅ Database seeded successfully with full dataset");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
};
