import { initializeDatabase, closeDatabase } from '../db/database.js';
import { createTables, seedDatabase } from '../db/schema.js';

const initDb = async () => {
    try {
        console.log('🗄️  Initializing database...');
        await initializeDatabase();
        console.log('📋 Creating tables...');
        await createTables();
        console.log('🌱 Seeding database with sample data...');
        await seedDatabase();
        console.log('✅ Database initialization complete!');
        await closeDatabase();
    } catch (error) {
        console.error('❌ Database initialization failed:', error);
        process.exit(1);
    }
};

initDb();
