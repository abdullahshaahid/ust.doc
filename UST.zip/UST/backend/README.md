# UniversityLearn Backend API

The Express.js REST API server for the UniversityLearn university management system. It uses SQLite as the database and JWT for authentication. Every piece of data the frontend displays — users, courses, assignments, grades, attendance, events, announcements, timetables, and learning roadmaps — is served and persisted by this backend.

## Table of Contents

- [How It Works](#how-it-works)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [NPM Scripts](#npm-scripts)
- [Server Entry Point — main.js](#server-entry-point--mainjs)
- [Database Layer](#database-layer)
- [Authentication and Authorization](#authentication-and-authorization)
- [API Routes — Complete Reference](#api-routes--complete-reference)
- [Seed Data](#seed-data)
- [Testing](#testing)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)

---

## How It Works

The backend follows a straightforward request lifecycle:

1. **`main.js`** creates an Express application, registers global middleware (CORS, JSON body parsing, URL-encoded body parsing), mounts 16 route groups under `/api/*`, adds error/404 handlers, then initializes the SQLite database and starts listening on port 3000.
2. On first startup (or when you run `npm run init-db`), the schema in **`db/schema.js`** creates 13 tables and seeds them with sample data read from the JSON files inside `data/`. If data already exists seeding is skipped, so the command is safe to run repeatedly.
3. Every request that needs to know _who_ is calling must include a JWT in the `Authorization` header. The **`middleware/auth.js`** module verifies the token and attaches the decoded user to `req.user`. A companion `roleMiddleware` function restricts endpoints to specific roles (admin, teacher, student).
4. Route handlers in `routes/` execute parameterized SQL via the promise-based helpers exported from **`db/database.js`** (`run`, `get`, `all`). All responses are JSON.
5. When the process receives `SIGINT` (Ctrl+C), a graceful shutdown hook closes the database connection before exiting.
6. When the file is imported by Vitest (for testing), automatic server startup is skipped so tests can control the lifecycle.

---

## Project Structure

```
backend/
├── main.js                    # Express server — registers middleware, mounts routes, starts the server
├── package.json               # Dependencies & npm scripts
├── vitest.config.js           # Vitest test-runner configuration
├── university.db              # SQLite database file (auto-created on first run)
│
├── db/
│   ├── database.js            # SQLite connection, promise wrappers (run, get, all), open/close
│   └── schema.js              # CREATE TABLE statements + seedDatabase() — reads data/ JSON files
│
├── middleware/
│   └── auth.js                # JWT helpers: generateToken, verifyToken, authMiddleware, roleMiddleware
│
├── routes/                    # One file per resource — each exports an Express Router
│   ├── auth.js                # Login, register, /me, logout, token refresh
│   ├── users.js               # CRUD users, filter by role/department
│   ├── courses.js             # CRUD courses, enroll/unenroll students
│   ├── enrollments.js         # List all enrollments
│   ├── lectures.js            # CRUD lectures, track downloads
│   ├── assignments.js         # CRUD assignments, submit, grade
│   ├── submissions.js         # List all submissions
│   ├── announcements.js       # CRUD announcements, activate/deactivate
│   ├── events.js              # CRUD events, register/unregister attendees
│   ├── attendance.js          # Mark/query attendance, percentage & reports
│   ├── timetable.js           # CRUD timetable entries, query by day/course/student
│   ├── roadmap.js             # CRUD learning roadmaps by department/semester
│   ├── grades.js              # Record grades, compute student CGPA
│   ├── analytics.js           # Dashboard stats, user/course/attendance/performance summaries
│   ├── files.js               # Upload, download, delete, batch-upload files
│   └── homepage.js            # Public homepage content
│
├── scripts/
│   └── initDatabase.js        # Standalone script — opens DB, creates tables, seeds data, then exits
│
├── data/                      # JSON seed files used by schema.js during first run
│   ├── users.json             # Admin, teacher, and student accounts
│   ├── courses.json           # Course catalog with enrolled students
│   ├── lectures.json          # Lecture materials per course
│   ├── assignments.json       # Assignments with nested submissions
│   ├── attendance.json        # Daily attendance records
│   ├── announcements.json     # System announcements
│   ├── events.json            # Campus events
│   ├── roadmap.json           # Semester learning paths
│   ├── timetable.json         # Weekly schedules
│   └── homepage.json          # Public homepage content
│
└── tests/
    ├── setup.js               # Creates a temp SQLite file, seeds it, exposes the Express app for supertest
    └── api.test.js            # Integration tests covering every route group
```

---

## Getting Started

```bash
cd backend
npm install          # install Express, sqlite3, bcryptjs, jsonwebtoken, cors, dotenv
npm run init-db      # create tables + seed sample data
npm start            # start the server on http://localhost:3000
```

For development with automatic restart on file changes:

```bash
npm run dev          # uses node --watch
```

---

## NPM Scripts

| Script       | Command                        | Purpose                                |
| ------------ | ------------------------------ | -------------------------------------- |
| `start`      | `node main.js`                 | Start the production server            |
| `dev`        | `node --watch main.js`         | Start with auto-reload on file changes |
| `init-db`    | `node scripts/initDatabase.js` | Create tables and seed sample data     |
| `test`       | `vitest run`                   | Run the integration test suite once    |
| `test:watch` | `vitest`                       | Run tests in watch mode                |

---

## Server Entry Point — main.js

`main.js` does the following in order:

1. **Creates the Express app** and exports it (so tests can import the app without starting a listener).
2. **Registers global middleware** — `cors()` for cross-origin requests, `express.json()` for JSON bodies, and `express.urlencoded({ extended: true })` for form data.
3. **Adds a root `GET /` endpoint** that returns a JSON summary of all available API endpoint groups — useful for quick discovery.
4. **Mounts 16 route groups** at `/api/<resource>`:
   - `/api/auth`, `/api/users`, `/api/courses`, `/api/lectures`, `/api/assignments`, `/api/announcements`, `/api/events`, `/api/attendance`, `/api/timetable`, `/api/roadmap`, `/api/analytics`, `/api/grades`, `/api/files`, `/api/enrollments`, `/api/submissions`, `/api/homepage`
5. **Registers error handlers** — a generic 500 handler that logs the error and returns JSON, and a 404 catch-all for unknown routes.
6. **`startServer()`** — Initializes the database connection, creates tables, seeds data if tables are empty, then calls `app.listen(port)`. Logs status messages at each step.
7. **Graceful shutdown** — Listens for `SIGINT` to close the database connection cleanly before exiting.
8. **Test-aware startup** — Auto-start is skipped when the file is imported by Vitest (`process.argv` check) so tests can control the lifecycle themselves.

---

## Database Layer

### db/database.js

Opens a single SQLite connection to `university.db` (or the path in `TEST_DB_PATH` during tests). Exports:

| Export                 | Description                                                         |
| ---------------------- | ------------------------------------------------------------------- |
| `initializeDatabase()` | Opens the SQLite file, returns a promise                            |
| `getDatabase()`        | Returns the raw `sqlite3.Database` instance                         |
| `run(sql, params)`     | Executes INSERT / UPDATE / DELETE — resolves with `{ id, changes }` |
| `get(sql, params)`     | Returns a single row                                                |
| `all(sql, params)`     | Returns an array of rows                                            |
| `closeDatabase()`      | Closes the connection                                               |

All functions are promise-based wrappers around the callback-driven `sqlite3` library, so route handlers can use `async/await` instead of callbacks.

### db/schema.js — Tables

`createTables()` runs `CREATE TABLE IF NOT EXISTS` for 13 tables:

| Table                  | Key Columns                                                                    | Purpose                             |
| ---------------------- | ------------------------------------------------------------------------------ | ----------------------------------- |
| **users**              | id, name, email, password, role (`admin`/`teacher`/`student`), department      | User accounts                       |
| **courses**            | id, name, code, teacherId, credits, semester                                   | Course catalog                      |
| **enrollments**        | courseId, studentId (unique pair)                                              | Which students are in which courses |
| **lectures**           | id, courseId, title, type, fileUrl, uploadedBy                                 | Course materials                    |
| **assignments**        | id, courseId, title, dueDate, totalMarks, createdBy                            | Homework / projects                 |
| **submissions**        | assignmentId, studentId (unique pair), status, marks, feedback                 | Student work                        |
| **attendance**         | courseId, studentId, date (unique triple), status (`present`/`absent`/`late`)  | Daily attendance                    |
| **announcements**      | id, title, content, targetRole, priority, isActive                             | Notices                             |
| **events**             | id, title, date, type, location, registrationOpen                              | Campus events                       |
| **eventRegistrations** | eventId, studentId (unique pair)                                               | Event RSVPs                         |
| **roadmap**            | id, department, semester, courses, outcomes, skills                            | Semester learning paths             |
| **timetable**          | id, courseId, day, startTime, endTime, room, type (`lecture`/`lab`/`tutorial`) | Weekly schedule                     |
| **grades**             | studentId, courseId (unique pair), grade, marks, credits                       | Final grades / CGPA                 |

### db/schema.js — Seeding

`seedDatabase()` checks if the `users` table is empty. If it is, it reads the JSON files from `data/` and inserts:

- **Users** — admins, teachers, students with hashed-compatible passwords
- **Courses** — inserted into `courses`; enrolled students inserted into `enrollments`
- **Lectures** — lecture materials linked to courses
- **Assignments** — including nested submissions into the submissions table
- **Attendance** — daily records per student per course
- **Announcements, events, roadmap items, timetable entries**

If data already exists the function returns immediately, so running it multiple times is safe.

---

## Authentication and Authorization

### middleware/auth.js

| Export                         | What It Does                                                                                               |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------- |
| `generateToken(user)`          | Signs a JWT containing `{ id, email, role }` with a 24-hour expiry                                         |
| `verifyToken(token)`           | Verifies and decodes a JWT, returns `null` on failure                                                      |
| `authMiddleware`               | Express middleware — reads `Authorization: Bearer <token>`, decodes it, attaches `req.user` or returns 401 |
| `roleMiddleware(allowedRoles)` | Returns middleware that checks `req.user.role` against the allowed list, returns 403 if not permitted      |

The JWT secret defaults to a built-in placeholder and should be overridden via the `JWT_SECRET` environment variable in production.

### How Login Works

1. Client sends `POST /api/auth/login` with `{ email, password }`.
2. The route handler looks up the user by email, then compares the supplied password against the stored hash using `bcryptjs.compare()`.
3. On success it calls `generateToken(user)` and returns `{ token, user }`.
4. The client stores the token in `localStorage` and sends it as `Authorization: Bearer <token>` on every subsequent request.
5. Protected routes run `authMiddleware` which decodes the token and sets `req.user`. Routes that require a specific role chain `roleMiddleware(['admin'])` (or other roles) after `authMiddleware`.

---

## API Routes — Complete Reference

### Authentication (`/api/auth`)

| Method | Endpoint    | Purpose                                    | Protected   |
| ------ | ----------- | ------------------------------------------ | ----------- |
| POST   | `/login`    | Authenticate and receive JWT + user data   | No          |
| GET    | `/me`       | Get the currently logged-in user's profile | Yes         |
| POST   | `/logout`   | Server-side logout acknowledgment          | Yes         |
| POST   | `/register` | Create a new user account                  | Yes (Admin) |
| POST   | `/refresh`  | Refresh an existing token                  | No          |

### Users (`/api/users`)

| Method | Endpoint            | Purpose                                                             |
| ------ | ------------------- | ------------------------------------------------------------------- |
| GET    | `/`                 | List all users (supports `?role=` and `?department=` query filters) |
| GET    | `/:id`              | Get a single user by ID                                             |
| GET    | `/role/:role`       | Get all users with a specific role                                  |
| GET    | `/department/:dept` | Get all users in a department                                       |
| POST   | `/`                 | Create a new user                                                   |
| PUT    | `/:id`              | Update an existing user                                             |
| DELETE | `/:id`              | Delete a user                                                       |

### Courses (`/api/courses`)

| Method | Endpoint              | Purpose                              |
| ------ | --------------------- | ------------------------------------ |
| GET    | `/`                   | List all courses                     |
| GET    | `/:id`                | Get course details                   |
| GET    | `/teacher/:teacherId` | Get courses taught by a teacher      |
| GET    | `/student/:studentId` | Get courses a student is enrolled in |
| GET    | `/:courseId/students` | Get students enrolled in a course    |
| POST   | `/`                   | Create a new course                  |
| PUT    | `/:id`                | Update a course                      |
| DELETE | `/:id`                | Delete a course                      |
| POST   | `/:courseId/enroll`   | Enroll a student in a course         |
| DELETE | `/:courseId/unenroll` | Remove a student from a course       |

### Lectures (`/api/lectures`)

| Method | Endpoint            | Purpose                   |
| ------ | ------------------- | ------------------------- |
| GET    | `/`                 | List all lectures         |
| GET    | `/:id`              | Get lecture details       |
| GET    | `/course/:courseId` | Get lectures for a course |
| POST   | `/`                 | Create/upload a lecture   |
| PUT    | `/:id`              | Update lecture metadata   |
| DELETE | `/:id`              | Delete a lecture          |
| POST   | `/:id/download`     | Track a download event    |

### Assignments (`/api/assignments`)

| Method | Endpoint                               | Purpose                                       |
| ------ | -------------------------------------- | --------------------------------------------- |
| GET    | `/`                                    | List all assignments                          |
| GET    | `/:id`                                 | Get assignment details                        |
| GET    | `/course/:courseId`                    | Get assignments for a course                  |
| GET    | `/student/:studentId`                  | Get a student's assignments (via enrollments) |
| POST   | `/`                                    | Create an assignment                          |
| PUT    | `/:id`                                 | Update an assignment                          |
| DELETE | `/:id`                                 | Delete an assignment                          |
| POST   | `/:assignmentId/submit`                | Submit student work                           |
| GET    | `/:assignmentId/submissions`           | Get all submissions for an assignment         |
| GET    | `/:assignmentId/submission/:studentId` | Get a specific student's submission           |
| PUT    | `/:assignmentId/grade/:studentId`      | Grade a submission                            |

### Announcements (`/api/announcements`)

| Method | Endpoint      | Purpose                            |
| ------ | ------------- | ---------------------------------- |
| GET    | `/`           | List all announcements             |
| GET    | `/:id`        | Get a single announcement          |
| GET    | `/role/:role` | Get announcements targeting a role |
| POST   | `/`           | Create an announcement             |
| PUT    | `/:id`        | Update an announcement             |
| PUT    | `/:id/status` | Toggle active/inactive status      |
| DELETE | `/:id`        | Delete an announcement             |

### Events (`/api/events`)

| Method | Endpoint                  | Purpose               |
| ------ | ------------------------- | --------------------- |
| GET    | `/`                       | Get all events        |
| GET    | `/:id`                    | Get event details     |
| GET    | `/type/:type`             | Get events by type    |
| POST   | `/`                       | Create event          |
| PUT    | `/:id`                    | Update event          |
| DELETE | `/:id`                    | Delete event          |
| POST   | `/:eventId/register`      | Register for event    |
| DELETE | `/:eventId/unregister`    | Unregister from event |
| GET    | `/:eventId/registrations` | Get registrations     |

### Attendance (`/api/attendance`)

| Method | Endpoint                         | Purpose                |
| ------ | -------------------------------- | ---------------------- |
| GET    | `/`                              | Get all attendance     |
| GET    | `/course/:courseId`              | Get course attendance  |
| GET    | `/student/:studentId`            | Get student attendance |
| GET    | `/student/:studentId/percentage` | Get attendance %       |
| GET    | `/course/:courseId/report`       | Get course report      |
| POST   | `/`                              | Mark attendance        |
| PUT    | `/:id`                           | Update attendance      |
| DELETE | `/:id`                           | Delete attendance      |

### Timetable (`/api/timetable`)

| Method | Endpoint              | Purpose                   |
| ------ | --------------------- | ------------------------- |
| GET    | `/`                   | Get all timetable entries |
| GET    | `/:id`                | Get entry details         |
| GET    | `/course/:courseId`   | Get course schedule       |
| GET    | `/day/:day`           | Get schedule by day       |
| GET    | `/student/:studentId` | Get student timetable     |
| POST   | `/`                   | Create timetable entry    |
| PUT    | `/:id`                | Update entry              |
| DELETE | `/:id`                | Delete entry              |

### Roadmap (`/api/roadmap`)

| Method | Endpoint                  | Purpose               |
| ------ | ------------------------- | --------------------- |
| GET    | `/`                       | Get all roadmap items |
| GET    | `/:id`                    | Get roadmap item      |
| GET    | `/department/:department` | Get by department     |
| GET    | `/semester/:semester`     | Get by semester       |
| POST   | `/`                       | Create roadmap item   |
| PUT    | `/:id`                    | Update item           |
| DELETE | `/:id`                    | Delete item           |

### Analytics (`/api/analytics`)

| Method | Endpoint              | Purpose                |
| ------ | --------------------- | ---------------------- |
| GET    | `/dashboard`          | Dashboard statistics   |
| GET    | `/users`              | User statistics        |
| GET    | `/courses`            | Course statistics      |
| GET    | `/attendance-summary` | Attendance overview    |
| GET    | `/performance`        | Student performance    |
| POST   | `/report`             | Generate custom report |

### Grades (`/api/grades`)

| Method | Endpoint              | Purpose                   |
| ------ | --------------------- | ------------------------- |
| GET    | `/student/:studentId` | Get student grades + CGPA |
| GET    | `/course/:courseId`   | Get course grades         |
| POST   | `/`                   | Record grade              |

### Files (`/api/files`)

| Method | Endpoint        | Purpose       |
| ------ | --------------- | ------------- |
| POST   | `/upload`       | Upload file   |
| GET    | `/:fileId`      | Download file |
| DELETE | `/:fileId`      | Delete file   |
| POST   | `/batch-upload` | Batch upload  |

### Enrollments (`/api/enrollments`)

| Method | Endpoint | Purpose              |
| ------ | -------- | -------------------- |
| GET    | `/`      | List all enrollments |

### Submissions (`/api/submissions`)

| Method | Endpoint | Purpose              |
| ------ | -------- | -------------------- |
| GET    | `/`      | List all submissions |

### Homepage (`/api/homepage`)

| Method | Endpoint | Purpose                     |
| ------ | -------- | --------------------------- |
| GET    | `/`      | Get public homepage content |

---

## Request and Response Examples

### Create an Assignment

```
POST /api/assignments
Authorization: Bearer <token>
Content-Type: application/json

{
  "id": "asgn3",
  "courseId": "cs101",
  "title": "File Processing Project",
  "description": "Build a student grade management system",
  "dueDate": "2026-04-20",
  "totalMarks": 25,
  "createdBy": "teacher1"
}
```

Response:

```json
{
  "message": "Assignment created",
  "assignmentId": "asgn3"
}
```

### Submit an Assignment

```
POST /api/assignments/asgn3/submit
Authorization: Bearer <token>
Content-Type: application/json

{
  "studentId": "student1",
  "content": "Submitted solution file",
  "fileUrl": "/submissions/asgn3_student1.py"
}
```

### Get Student CGPA

```
GET /api/grades/student/student1
Authorization: Bearer <token>
```

Response:

```json
{
  "studentId": "student1",
  "grades": [
    {
      "courseId": "cs101",
      "courseName": "Introduction to Programming",
      "courseCode": "CS101",
      "grade": "A",
      "marks": 92,
      "credits": 3
    }
  ],
  "cgpa": 3.92,
  "totalCredits": 9
}
```

---

## Seed Data

The `data/` directory contains JSON files that are loaded into the database on first run. Each file maps to one or more tables:

| File                 | Populates                                            |
| -------------------- | ---------------------------------------------------- |
| `users.json`         | `users` table — admin, teacher, and student accounts |
| `courses.json`       | `courses` + `enrollments` tables                     |
| `lectures.json`      | `lectures` table                                     |
| `assignments.json`   | `assignments` + `submissions` tables                 |
| `attendance.json`    | `attendance` table                                   |
| `announcements.json` | `announcements` table                                |
| `events.json`        | `events` table                                       |
| `roadmap.json`       | `roadmap` table                                      |
| `timetable.json`     | `timetable` table                                    |
| `homepage.json`      | Homepage content (returned by the homepage route)    |

To re-seed the database from scratch, delete `university.db` and run:

```bash
rm university.db
npm run init-db
```

---

## Testing

Tests use **Vitest** as the runner and **supertest** to send HTTP requests to the Express app without starting a real server.

### How the test setup works

1. `tests/setup.js` creates a temporary directory and sets `process.env.TEST_DB_PATH` so the database module opens a disposable SQLite file instead of the production `university.db`.
2. It dynamically imports the database, schema, and app modules (after the env var is set), then creates tables and seeds data.
3. Each test file calls `createTestApp()` in a `beforeAll` hook and `cleanupTestApp()` in `afterAll` to get a fresh, isolated database per suite.
4. A `loginAs(app, role)` helper logs in with the seed credentials for a given role and returns the JWT token.
5. `api.test.js` exercises every route group — authentication, CRUD operations, role restrictions, and edge cases.

### Running tests

```bash
npm test              # single run
npm run test:watch    # re-run on file changes
```

The Vitest config (`vitest.config.js`) sets a 15-second timeout per test and hook, and disables concurrent execution so SQLite is not accessed in parallel.

---

## Environment Variables

Create a `.env` file in the `backend/` directory (optional — sensible defaults are built in):

| Variable     | Default              | Description                                                 |
| ------------ | -------------------- | ----------------------------------------------------------- |
| `PORT`       | `3000`               | Port the server listens on                                  |
| `JWT_SECRET` | built-in placeholder | Secret key for signing JWTs — **change this in production** |
| `NODE_ENV`   | `development`        | Set to `production` for production use                      |

Example `.env`:

```env
PORT=3000
JWT_SECRET=your-secret-key-change-in-production
NODE_ENV=development
```

---

## Troubleshooting

### Port already in use

```bash
# Find the process using port 3000
lsof -i :3000                  # Mac/Linux
netstat -ano | findstr :3000   # Windows

# Or start on a different port
PORT=3001 npm start
```

### Database lock errors

SQLite can show lock errors if multiple processes access the same file:

- Make sure only one server instance is running.
- Check for zombie node processes: `ps aux | grep node`

### CORS errors from the frontend

CORS is enabled globally in `main.js` via the `cors()` middleware. If the frontend still fails to connect, verify:

- The backend is actually running on the expected port.
- The frontend's `VITE_API_URL` environment variable points to `http://localhost:3000/api`.

### Database is empty or outdated

```bash
rm university.db
npm run init-db
```

### Login fails with correct credentials

Re-initialize the database — the password hashes may have been corrupted or the schema may be outdated:

```bash
rm university.db
npm run init-db
npm start
```

---

## Demo Credentials

| Role    | Email                       | Password     |
| ------- | --------------------------- | ------------ |
| Admin   | `admin@university.edu`      | `admin123`   |
| Teacher | `john.smith@university.edu` | `teacher123` |
| Student | `alice@student.edu`         | `student123` |
