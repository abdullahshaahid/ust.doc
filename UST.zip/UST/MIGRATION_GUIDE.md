# 🔄 Frontend-Backend Integration Migration Guide

## Overview of Changes

This document outlines all the changes made to connect the React frontend to the Express.js backend with SQLite database.

## 📦 Dependency Changes

### Frontend `package.json`

**Added**:
```json
"axios": "^1.6.0"
```

**Purpose**: HTTP client for making API requests to backend

**Installation**: Automatically installed via `npm install`

## 🔧 New Files Created

### 1. API Client (`src/lib/api.ts`)
- Centralized axios instance with interceptors
- Pre-built functions for all API endpoints
- Automatic JWT token attachment to requests
- 401 error handling (auto-logout on token expiry)

**Functions organized by entity:**
- `authApi.*` - 5 endpoints
- `userApi.*` - 7 endpoints
- `courseApi.*` - 10 endpoints
- `lectureApi.*` - 7 endpoints
- `assignmentApi.*` - 11 endpoints
- `announcementApi.*` - 7 endpoints
- `eventApi.*` - 7 endpoints
- `attendanceApi.*` - 8 endpoints
- `timetableApi.*` - 8 endpoints
- `roadmapApi.*` - 7 endpoints
- `analyticsApi.*` - 6 endpoints
- `gradesApi.*` - 3 endpoints
- `filesApi.*` - 4 endpoints

### 2. Environment Configuration
- `.env` - Default development config
- `.env.local` - Local overrides
- `.env.development` - Development-specific settings
- `.env.production` - Production config template

### 3. Documentation
- `BACKEND_CONNECTION.md` - Integration guide
- Updated `README.md` with full system info

### 4. Startup Scripts
- `start-dev.bat` - Windows startup script
- `start-dev.sh` - Mac/Linux startup script

## 📝 Modified Files

### 1. `src/app/context/AuthContext.tsx`

**Before**:
```typescript
// Used localStorage with JSON data
const login = (email: string, password: string) => {
  const storedUsers = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  const user = storedUsers.find(u => u.email === email && u.password === password);
  if (user) {
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    return { success: true, message: 'Login successful' };
  }
  return { success: false, message: 'Invalid email or password' };
};
```

**After**:
```typescript
// Uses backend API with JWT tokens
const login = async (email: string, password: string) => {
  try {
    const response = await authApi.login(email, password);
    if (response.data.token && response.data.user) {
      localStorage.setItem(TOKEN_KEY, response.data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(response.data.user));
      setCurrentUser(response.data.user);
      return { success: true, message: 'Login successful' };
    }
    return { success: false, message: 'Login failed' };
  } catch (error: any) {
    return { success: false, message: error.response?.data?.error };
  }
};
```

**Key Changes**:
- ✅ `login()` is now async
- ✅ Calls `authApi.login()` instead of checking localStorage
- ✅ Stores JWT token instead of user password
- ✅ Only stores non-sensitive user data
- ✅ Better error handling from API

### 2. `src/app/context/DataContext.tsx`

**Before** (300+ lines):
```typescript
// Loaded JSON files at import time
import coursesData from '../../data/courses.json';
import lecturesData from '../../data/lectures.json';
// ... 8 more JSON imports

// Used localStorage as persistent storage
const loadOrInit = (key: string, initial: any[]) => {
  const stored = localStorage.getItem(key);
  if (stored) return JSON.parse(stored);
  localStorage.setItem(key, JSON.stringify(initial));
  return initial;
};

// CRUD operations updated localStorage
const addCourse = (course: Course) => {
  const n = [...courses, course];
  setCourses(n);
  save('lms_courses', n);
};
```

**After**:
```typescript
// Fetches from backend API on mount
useEffect(() => {
  refetchAll(); // Fetches from all endpoints
}, []);

const refetchAll = async () => {
  const [coursesRes, lecturesRes, ...] = await Promise.all([
    courseApi.getAllCourses(),
    lectureApi.getAllLectures(),
    ...
  ]);
  setCourses(coursesRes.data);
  setLectures(lecturesRes.data);
  // ...
};

// CRUD operations call backend API
const addCourse = async (course: any) => {
  await courseApi.createCourse(course);
  await refetchAll(); // Sync after operation
};

const updateCourse = async (id: string, course: any) => {
  await courseApi.updateCourse(id, course);
  await refetchAll();
};

// All operations now async
const deleteUser = async (id: string) => {
  await userApi.deleteUser(id);
  await refetchAll();
};
```

**Key Changes**:
- ✅ Removed JSON file imports
- ✅ All data fetched from backend on app load
- ✅ All CRUD operations async
- ✅ Automatic data refresh after updates
- ✅ Added `isLoading` and `isSyncing` states
- ✅ Error handling with try/catch
- ✅ Real-time data synchronization

### 3. `src/app/pages/auth/LoginPage.tsx`

**Before**:
```typescript
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setError('');
  setLoading(true);
  await new Promise(r => setTimeout(r, 700)); // Fake delay
  const result = login(email, password); // Synchronous
  setLoading(false);
  if (result.success) {
    const user = JSON.parse(localStorage.getItem('lms_current_user') || '{}');
    // ... navigate
  }
};
```

**After**:
```typescript
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setError('');
  setLoading(true);
  try {
    const result = await login(email, password); // Async with real API call
    if (result.success) {
      const user = JSON.parse(localStorage.getItem('current_user') || '{}');
      // ... navigate
    } else {
      setError(result.message);
    }
  } catch (err: any) {
    setError(err.message || 'Login failed');
  } finally {
    setLoading(false);
  }
};
```

**Key Changes**:
- ✅ Proper async/await handling
- ✅ Error handling with try/catch/finally
- ✅ Removed fake delay
- ✅ Better error messages

## 🔐 Security Changes

### Before
- ❌ Passwords stored in localStorage
- ❌ All user data in frontend
- ❌ No server-side validation
- ❌ No token-based auth

### After
- ✅ JWT tokens stored (passwords never sent to frontend)
- ✅ Only user metadata stored locally
- ✅ Server-side validation on backend
- ✅ Token-based authentication with 24h expiry
- ✅ Automatic token refresh handling
- ✅ CORS-protected API endpoints
- ✅ Role-based access control (RBAC)

## 📊 Data Flow Changes

### Before (Client-Side Storage)
```
User Action → localStorage → State Update → UI Render
```

### After (Server-Side with Backend)
```
User Action → API Call (with JWT)
                    ↓
            Backend Validation → SQLite DB
                    ↓
            Response to Frontend
                    ↓
            refetchAll() → State Update → UI Render
```

## 🔑 Storage Keys

### Changed From:
```javascript
'lms_users'
'lms_courses'
'lms_lectures'
'lms_assignments'
'lms_attendance'
'lms_events'
'lms_roadmap'
'lms_timetable'
'lms_announcements'
'lms_current_user'
'lms_data_version'
```

### Changed To:
```javascript
'auth_token'          // JWT token
'current_user'        // User metadata only
```

## 🚀 Performance Implications

### Data Loading
- **Before**: Instant (from localStorage)
- **After**: ~500ms-2s (API call to backend)
- **Mitigation**: Loading spinner, `isLoading` state

### Operations
- **Before**: Instant (memory update only)
- **After**: ~500ms-2s (API call + database)
- **Benefit**: Real data persistence & multi-user sync

### Network Usage
- **Before**: Zero network (single browser)
- **After**: API requests for every operation
- **Benefit**: Real backend, scalable to multiple users

## 🔄 Data Synchronization

### Automatic Sync Triggers
```typescript
// After any data-modifying operation:
addCourse() → API call → refetchAll() → State updates

// Manual sync:
const { refetchAll } = useData();
await refetchAll();

// On app load:
DataProvider useEffect → refetchAll()
```

## 🔵 Loading States

### New States Available
```typescript
const { isLoading, isSyncing } = useData();

// isLoading: true during initial data fetch
// isSyncing: true during any operation (create/update/delete)
```

### Usage in Components
```typescript
if (isLoading) return <LoadingSpinner />;
if (isSyncing) return <div>Saving...</div>;
```

## 🔗 API Endpoint Mapping

### Example: Course Creation

**Before**:
```typescript
addCourse(course) → setAssignments([...assignments, course])
```

**After**:
```typescript
addCourse(course) 
→ courseApi.createCourse(course)
→ POST http://localhost:3000/api/courses
→ Backend validates & saves to SQLite
→ Backend returns 201 Created
→ Frontend calls refetchAll()
→ Frontend re-fetches all courses from backend
→ Frontend updates state
→ UI re-renders
```

## 🧪 Testing Checklist

- [ ] Backend starts and database initializes
- [ ] Frontend connects to backend API
- [ ] Login works with correct credentials
- [ ] Token is stored in localStorage
- [ ] Data loads from backend on app init
- [ ] Can create new course
- [ ] Can update existing course  
- [ ] Can delete course
- [ ] Can enroll student in course
- [ ] Logout clears token and user data
- [ ] Redirects to login on 401
- [ ] Error messages display correctly

## 📱 Browser DevTools Debugging

### Check Token
```javascript
console.log(localStorage.getItem('auth_token'));
```

### Check API Calls
```
DevTools → Network Tab → XHR/Fetch
Shows all API requests with headers and responses
```

### Check API Client
```javascript
import { courseApi } from './src/lib/api';
const courses = await courseApi.getAllCourses();
console.log(courses);
```

## 🚨 Common Issues & Fixes

### "Unauthorized" Errors
- Token expired: Log in again
- Token missing: Check localStorage
- Backend down: Restart backend

### "API Connection Failed"
- Backend not running: `npm start` in backend folder
- Wrong API URL: Check `.env` file
- CORS issue: Verify backend has CORS enabled

### "Data not updating"
- Click refresh or wait for auto-sync
- Check browser network tab for errors
- Check backend console for validation errors

## ✅ Post-Migration Verification

1. **Backend Working**
   ```bash
   curl http://localhost:3000/
   ```

2. **Frontend Connected**
   - Open DevTools Network tab
   - Perform login
   - See POST request to `/api/auth/login`

3. **Data Syncing**
   - Create new course
   - Check backend database updated
   - Frontend shows new course

4. **Error Handling**
   - Try invalid login
   - See error message
   - Should not break app

## 📚 References

- **Backend API Docs**: [backend/README.md](backend/README.md)
- **Connection Guide**: [frontend/BACKEND_CONNECTION.md](frontend/BACKEND_CONNECTION.md)
- **Axios Documentation**: https://axios-http.com/
- **JWT Authentication**: https://jwt.io/

---

**Migration Complete!** ✅ Your frontend is now fully connected to the backend.
